import './styles/main.css'
import { Assets } from './engine/assets'
import { Audio } from './engine/audio'
import { Input } from './engine/input'
import { GameLoop } from './engine/loop'
import { SAVE_KEY, SaveStore, type SaveData } from './engine/save'
import { CHAPTERS, UNLOCK_STARS, gradeFor } from './game/data'
import type { Game } from './game/game'
import type { Shift, ShiftMode } from './game/sim'
import type { View } from './game/view'
import { Ui } from './ui/ui'

async function boot(): Promise<void> {
  const canvas = document.querySelector<HTMLCanvasElement>('#game')!
  const firstRun = safeGet(SAVE_KEY) === null
  const save = new SaveStore()
  const input = new Input(canvas)
  const audio = new Audio()
  const assets = new Assets()
  let game: Game | undefined
  let view: View | undefined
  let last: { chapter: number; mode: ShiftMode } = { chapter: 0, mode: 'campaign' }
  let endShown = false

  const apply = (d: SaveData) => {
    audio.setVolumes(d.musicVolume, d.sfxVolume, d.muted)
    if (view) { view.shakeEnabled = !d.noShake; view.reducedMotion = d.reducedMotion; view.fx.density = d.reducedMotion ? 0.4 : 1 }
  }
  const titleRoom = () => Math.max(0, CHAPTERS.findLastIndex((_, i) => save.totalStars >= UNLOCK_STARS[i]))
  const startShift = (chapter: number, mode: ShiftMode) => {
    if (!game) return
    audio.unlock()
    audio.startMusic()
    last = { chapter, mode }
    endShown = false
    const tutorial = mode === 'campaign' && chapter === 0 && !save.data.tutorialDone
    ui.clearTransient()
    game.start(chapter, mode, tutorial)
    ui.show('hud')
    loop.resetAccumulator()
  }
  const pause = () => {
    if (game?.mode !== 'playing') return
    game.pause()
    ui.show('pause')
  }
  const resume = () => {
    if (game?.mode !== 'paused') return
    game.resume()
    ui.show('hud')
    loop.resetAccumulator()
  }
  const toTitle = () => {
    ui.clearTransient()
    game?.showTitle(titleRoom())
  }
  const ui = new Ui(save, audio, input, {
    startShift,
    resume,
    pause,
    crewChanged: () => { if (game?.shift) game.shift.setStaff(game.mods().staff) },
    restart: () => startShift(last.chapter, last.mode),
    quit: () => { toTitle(); ui.show('title') },
    settings: patch => {
      const q = patch.quality !== undefined && patch.quality !== save.data.quality
      save.update(patch)
      apply(save.data)
      if (q) renderer?.applyQuality(save.data.quality)
    },
  })
  ui.show('boot')
  apply(save.data)
  ui.setBoot(0.05, 'Opening Atlantis Bar…')

  const [{ Game: GameCls }, { View: ViewCls }, { Renderer, suggestQuality }] = await Promise.all([
    import('./game/game'), import('./game/view'), import('./engine/renderer'),
  ])
  if (firstRun) save.update({ quality: suggestQuality() })
  const renderer = new Renderer(canvas, save.data.quality)
  view = new ViewCls(renderer, assets)
  apply(save.data)
  const { CORE_MODELS } = await import('./game/view')
  let n = 0
  const total = CORE_MODELS.length + 1
  const tick = (msg?: string) => ui.setBoot(0.1 + (++n / total) * 0.9, msg)
  try {
    await Promise.all([view.loadCore(() => tick(n > total / 2 ? 'Polishing the brass…' : undefined)), audio.preload().then(() => tick('Tuning the Kerala soundtrack…'))])
  } catch (err) {
    ui.setBoot(1, 'Could not load the shop. Check your connection and reload.')
    throw err
  }
  void view.loadLate()
  void audio.loadMusic()

  game = new GameCls(view, input, audio, {
    popup: (text, x, y, z, kind) => ui.popupAt(text, x, y, z, kind, view!),
    toast: text => ui.toast(text),
    ended: shift => {
      if (endShown) return
      endShown = true
      window.setTimeout(() => ui.showResults(shift, reward(shift)), 1700)
    },
  }, () => save.data)

  const reward = (s: Shift) => {
    const d = save.data
    const st = s.stats
    const before = save.totalStars
    let wallet = 0
    let newBest = false
    let unlocked = ''
    if (s.mode === 'campaign') {
      const g = gradeFor(st.revenue, s.ch.target, s.satisfaction)
      wallet = Math.round(st.tips + st.revenue * 0.12)
      const stars = [...d.stars]
      const best = [...d.best]
      stars[s.ch.id] = Math.max(stars[s.ch.id], g.stars)
      newBest = st.revenue > best[s.ch.id]
      best[s.ch.id] = Math.max(best[s.ch.id], st.revenue)
      save.update({ stars, best })
      const after = save.totalStars
      const opened = CHAPTERS.find((_, i) => before < UNLOCK_STARS[i] && after >= UNLOCK_STARS[i])
      if (opened) unlocked = opened.name
    } else {
      wallet = Math.round(st.tips * 0.5)
      const id = s.mode
      newBest = st.revenue > (d.challengeBest[id] ?? 0)
      save.update({ challengeBest: { ...d.challengeBest, [id]: Math.max(d.challengeBest[id] ?? 0, st.revenue) } })
    }
    save.update({ wallet: save.data.wallet + wallet, lifetime: save.data.lifetime + st.revenue, shifts: save.data.shifts + 1, tutorialDone: true })
    return { wallet, newBest, unlocked }
  }

  const g = game
  const v = view
  g.showTitle(titleRoom())
  const loop = new GameLoop({
    beforeFrame: () => input.update(),
    step: dt => g.step(dt),
    render: (_alpha, frame) => {
      if (input.consume('pause')) {
        if (g.mode === 'playing') pause()
        else if (g.mode === 'paused' && ui.screen === 'pause') resume()
      }
      if (input.consume('recipes') && g.mode === 'playing') { pause(); ui.show('recipes', true) }
      if (g.mode === 'playing' && g.shift.tutorial && g.shift.tutorial.step >= 7 && !save.data.tutorialDone) save.update({ tutorialDone: true })
      ui.frame(frame)
      loop.paused = g.mode === 'paused'
      g.frame(frame)
      v.render(frame)
      if (g.mode !== 'title') ui.updateHud(g.shift, g, v)
      input.endFrame()
    },
  })
  loop.start()
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause() })
  window.addEventListener('resize', () => v.resize())
  window.addEventListener('pointerdown', () => audio.unlock(), { capture: true })
  window.addEventListener('keydown', () => audio.unlock(), { capture: true })
  ui.setBoot(1, 'Shutters up!')
  window.setTimeout(() => { ui.show('title'); audio.startMusic() }, 200)
  // Debug/test hook (read-only use): smoke tests inspect state through it.
  ;(window as unknown as { __game: unknown }).__game = { game: g, ui, input, save, view: v }
}

function safeGet(key: string): string | null {
  try { return localStorage.getItem(key) } catch { return null }
}

boot().catch(err => {
  console.error(err)
  const el = document.getElementById('ui')
  if (el && !el.querySelector('.boot-msg')?.textContent?.includes('Could not')) el.insertAdjacentHTML('beforeend', `<div class="fatal">Failed to start: ${String((err as Error)?.message ?? err).replace(/[<>&]/g, '')} <button onclick="location.reload()">Retry</button></div>`)
})
