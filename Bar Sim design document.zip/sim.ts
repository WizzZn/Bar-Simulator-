/**
 * Deterministic toddy-shop service simulation. No rendering, no DOM: the view reads this state and the
 * controller feeds commands. Headless tests and the autoplay bot drive it directly.
 */
import {
  CHAPTERS, DISHES, GUESTS, STATIONS, type ChapterDef, type Dir, type DishId, type GuestTypeId,
  type StaffJob, type StationId, type UpgradeId,
} from './data'

export type Vec = { x: number; z: number }
export type Item = { id: number; dish: DishId; step: number; q: number; qn: number; ticket: number | null; spicy: boolean; crispy: boolean; ready: boolean; burnt?: boolean }
export type TicketState = 'queued' | 'cooking' | 'served' | 'void'
export type Ticket = { id: number; party: number; dish: DishId; spicy: boolean; crispy: boolean; state: TicketState; at: number }
export type PartyState = 'queue' | 'walking' | 'menu' | 'ordering' | 'waiting' | 'eating' | 'leaving' | 'gone'
export type Party = {
  id: number; type: GuestTypeId; size: number; dishes: DishId[]; state: PartyState; patience: number; max: number
  table: number; timer: number; qSum: number; served: number; stylish: number; x: number; z: number; from: Vec; angry: boolean
  look: number; sat: number; trouble: number; calmUntil: number; disruptAt: number; intoxication: number; fighting: boolean
}
export type Table = { id: number; x: number; z: number; seats: 2 | 4; party: number; dirty: boolean; bar: boolean }
export type Station = { id: StationId; x: number; z: number; face: Vec; r: number; item: Item | null; t: number; burnt: number; taps: number; flame: number }
export type TargetRef = { kind: 'station'; id: StationId } | { kind: 'table'; id: number } | { kind: 'door' } | { kind: 'bin' }
export type Work = { kind: 'tap'; station: StationId } | { kind: 'plate'; station: 'pass'; seq: Dir[]; idx: number; miss: number }
export type Flight = { item: Item; from: Vec; to: Vec; table: number; t: number; dur: number; outcome: 'perfect' | 'good' | 'miss'; spin: number }
export type StaffState = { role: string; job: StaffJob; name: string; x: number; z: number; tx: number; tz: number; task: string; carry: Item | null; timer: number; target: number; face: number }
export type SimEvent =
  | { t: 'pop'; text: string; x: number; z: number; kind: 'good' | 'bad' | 'gold' | 'info' | 'money' }
  | { t: 'sfx'; name: string }
  | { t: 'shake'; amt: number }
  | { t: 'fx'; kind: 'steam' | 'sparks' | 'smoke' | 'confetti' | 'splash' | 'chop' | 'coins' | 'shards'; x: number; z: number; y?: number }
  | { t: 'msg'; text: string }
  | { t: 'anim'; who: 'mei'; name: 'throw' | 'chop' | 'cheer' }

export type Mods = {
  upgrades: Partial<Record<UpgradeId, boolean>>
  staff: { role: string; job: StaffJob; name: string }[]
  assist: boolean
}

export type ShiftMode = 'campaign' | 'endless' | 'throw'
export type Phase = 'tutorial' | 'intro' | 'service' | 'peak' | 'lastcall' | 'overtime' | 'done'

export type Stats = {
  revenue: number; tips: number; served: number; dishes: number; walkouts: number; perfectCooks: number; burns: number
  stylish: number; throws: number; smashes: number; maxCombo: number; saves: number; doubles: number; satSum: number; satN: number
  rep: number
}

export const ROOM = { minX: -7.0, maxX: 7.0, minZ: -4.1, maxZ: 4.5 }
export const DOOR: Vec = { x: 6.3, z: 3.85 }
export const BIN: Vec = { x: -2.3, z: 3.7 }
export const SINK: Vec = { x: -6.3, z: 2.6 }
/** The bar counter seat sits on the dining side of the bar station. */
export const BAR_SEAT_OFFSET = 0.95
export const QUEUE_SPOTS: Vec[] = [{ x: 6.3, z: 4.15 }, { x: 5.6, z: 4.2 }, { x: 4.9, z: 4.25 }, { x: 4.2, z: 4.3 }]

const STATION_POS: Record<StationId, { x: number; z: number; face: Vec }> = {
  steamer: { x: -5.6, z: -3.35, face: { x: 0, z: 1 } },
  grill: { x: -4.0, z: -3.35, face: { x: 0, z: 1 } },
  kadai: { x: -2.4, z: -3.35, face: { x: 0, z: 1 } },
  tawa: { x: -0.8, z: -3.35, face: { x: 0, z: 1 } },
  prep: { x: -6.25, z: -1.3, face: { x: 1, z: 0 } },
  uruli: { x: -6.25, z: 0.6, face: { x: 1, z: 0 } },
  pass: { x: 0.2, z: -1.0, face: { x: -1, z: 0 } },
  bar: { x: 0.2, z: 1.7, face: { x: -1, z: 0 } },
}

export const READY = 0.82
export const BURN = 1.9
export const MEI_SPEED = 4.3
const INTERACT_PAD = 0.85

export function cookWindows(window: number, crispy: boolean, pans: boolean): { pLo: number; pHi: number; gHi: number } {
  const w = 0.085 * window * (pans ? 1.35 : 1)
  const c = crispy ? 1.24 : 1.04
  return { pLo: c - w, pHi: c + w, gHi: Math.min(BURN - 0.04, c + w + 0.28 * window) }
}

/** Mulberry32 seeded RNG. */
export function rng(seed: number): () => number {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = a
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export type Commands = {
  move: Vec
  interact: boolean
  goto: TargetRef | null
  aimHeld: boolean
  aimPoint: Vec | null
  aimDir: Vec | null
  dir: Dir | null
}
export const emptyCommands = (): Commands => ({ move: { x: 0, z: 0 }, interact: false, goto: null, aimHeld: false, aimPoint: null, aimDir: null, dir: null })

export class Shift {
  readonly ch: ChapterDef
  readonly mode: ShiftMode
  readonly mods: Mods
  readonly rand: () => number
  time = 0
  clock = 0
  phase: Phase = 'intro'
  duration: number
  parties: Party[] = []
  tables: Table[] = []
  stations: Station[] = []
  tickets: Ticket[] = []
  flights: Flight[] = []
  staff: StaffState[] = []
  passShelf: Item[] = []
  barShelf: Item[] = []
  stock: Record<string, number> = { kallu: 8, beer: 8, brandy: 8, whisky: 8, vodka: 8, scotch: 6, gingerBeer: 8, lime: 12, sugar: 12, bitters: 12, orange: 12, glass: 12, ice: 24 }
  dirtyGlassware = 0
  events: SimEvent[] = []
  stats: Stats = { revenue: 0, tips: 0, served: 0, dishes: 0, walkouts: 0, perfectCooks: 0, burns: 0, stylish: 0, throws: 0, smashes: 0, maxCombo: 0, saves: 0, doubles: 0, satSum: 0, satN: 0, rep: 0 }
  combo = 0
  comboTimer = 0
  lastServeAt = -99
  mei = { x: -1.6, z: 0.2, face: 0, speed: 0, hands: null as Item | null, work: null as Work | null, goto: null as TargetRef | null, gotoAct: false, stuck: 0, lastD: 0, steer: 0, aim: null as null | { table: number; phase: number }, act: '' as '' | 'chop' | 'throw' | 'cheer', actT: 0 }
  tutorial: { step: number; t: number; moved: number } | null = null
  private nextId = 1
  private spawnAt = 2
  private hintsShown = new Set<string>()
  private overtime = 0
  doorsClosed = false
  ended = false

  constructor(chapter: number, mode: ShiftMode, mods: Mods, opts: { tutorial?: boolean; seed?: number } = {}) {
    this.ch = CHAPTERS[chapter]
    this.mode = mode
    this.mods = mods
    this.rand = rng(opts.seed ?? 1234 + chapter * 77)
    this.duration = mode === 'endless' ? Infinity : mode === 'throw' ? 120 : this.ch.duration
    for (const id of this.ch.stations) {
      const p = STATION_POS[id]
      this.stations.push({ id, x: p.x, z: p.z, face: p.face, r: id === 'pass' || id === 'bar' ? 0.62 : 0.55, item: null, t: 0, burnt: 0, taps: 0, flame: 0 })
    }
    this.ch.tables.forEach((t, i) => this.tables.push({ id: i, x: t.x, z: t.z, seats: t.seats, party: -1, dirty: false, bar: false }))
    const barSt = this.station('bar')
    if (barSt && mods.upgrades.stools) this.tables.push({ id: this.tables.length, x: barSt.x + BAR_SEAT_OFFSET, z: barSt.z, seats: 2, party: -1, dirty: false, bar: true })
    this.setStaff(mods.staff)
    if (opts.tutorial) {
      this.tutorial = { step: 0, t: 0, moved: 0 }
      this.phase = 'tutorial'
      this.spawnParty('regular', ['kallu'], 1, false, false)
    }
  }

  // ─── queries ────────────────────────────────────────────────────────────
  station(id: StationId): Station | undefined { return this.stations.find(s => s.id === id) }
  party(id: number): Party | undefined { return this.parties.find(p => p.id === id) }
  get queue(): Party[] { return this.parties.filter(p => p.state === 'queue') }
  get comboMult(): number { return Math.min(3, 1 + this.combo * 0.08) }
  get satisfaction(): number { return this.stats.satN ? this.stats.satSum / this.stats.satN : 1 }
  get windowScale(): number { return this.ch.window * (this.mods.assist ? 1.3 : 1) }
  get timeLeft(): number { return Math.max(0, this.duration - this.clock) }
  windows(item: Item) { return cookWindows(this.windowScale, item.crispy, !!this.mods.upgrades.pans) }
  hasJob(job: StaffJob): boolean { return this.staff.some(s => s.job === job) }
  needs(p: Party): DishId[] {
    if (p.state !== 'waiting') return []
    return this.tickets.filter(t => t.party === p.id && t.state !== 'served' && t.state !== 'void').map(t => t.dish)
  }
  targetPos(t: TargetRef): { x: number; z: number; r: number } {
    if (t.kind === 'station') { const s = this.station(t.id)!; return { x: s.x, z: s.z, r: s.r } }
    if (t.kind === 'table') { const tb = this.tables[t.id]; return { x: tb.x, z: tb.z, r: 0.6 } }
    if (t.kind === 'door') return { x: DOOR.x, z: DOOR.z, r: 0.35 }
    return { x: BIN.x, z: BIN.z, r: 0.3 }
  }
  allTargets(): TargetRef[] {
    const out: TargetRef[] = this.stations.map(s => ({ kind: 'station', id: s.id }) as TargetRef)
    this.tables.forEach(t => out.push({ kind: 'table', id: t.id }))
    out.push({ kind: 'door' }, { kind: 'bin' })
    return out
  }
  /** Nearest target Mei can reach without walking. */
  focus(): TargetRef | null {
    let best: TargetRef | null = null
    let bd = Infinity
    for (const t of this.allTargets()) {
      const p = this.targetPos(t)
      const d = Math.hypot(p.x - this.mei.x, p.z - this.mei.z) - p.r
      if (d < INTERACT_PAD && d < bd) { bd = d; best = t }
    }
    return best
  }
  obstacles(): { x: number; z: number; r: number }[] {
    const o = this.stations.map(s => ({ x: s.x, z: s.z, r: s.r }))
    // The bar counter seat is just stools beside the bar: walkable.
    for (const t of this.tables) if (!t.bar) o.push({ x: t.x, z: t.z, r: 0.62 })
    for (const d of this.ch.decor) o.push({ x: d.x, z: d.z, r: d.r ?? 0.32 })
    o.push({ x: BIN.x, z: BIN.z, r: 0.28 })
    return o
  }

  // ─── step ───────────────────────────────────────────────────────────────
  step(dt: number, cmd: Commands): void {
    if (this.ended) return
    this.time += dt
    const tut = this.tutorial
    if (!tut || tut.step >= 7) this.clock += dt
    this.updatePhase(dt)
    this.updateMei(dt, cmd)
    this.updateStations(dt)
    this.updateFlights(dt)
    this.updateParties(dt)
    this.updateStaff(dt)
    this.updateSpawns()
    if (this.comboTimer > 0) {
      this.comboTimer -= dt
      if (this.comboTimer <= 0 && this.combo > 0) {
        this.combo = 0
        this.events.push({ t: 'pop', text: 'Combo cooled', x: this.mei.x, z: this.mei.z, kind: 'info' })
      }
    }
    if (this.mei.actT > 0) { this.mei.actT -= dt; if (this.mei.actT <= 0) this.mei.act = '' }
    if (tut) this.updateTutorial(dt)
  }

  private updatePhase(dt: number): void {
    if (this.phase === 'tutorial') {
      if (this.tutorial && this.tutorial.step >= 7) this.phase = 'intro'
      return
    }
    if (this.mode === 'endless') {
      this.phase = this.clock < 25 ? 'intro' : this.clock < 90 ? 'service' : 'peak'
      if (this.stats.walkouts >= 3) this.finish()
      return
    }
    const f = this.clock / this.duration
    const prev = this.phase
    if (f < 0.2) this.phase = 'intro'
    else if (f < 0.42) this.phase = 'service'
    else if (f < 0.78) this.phase = 'peak'
    else if (f < 1) this.phase = 'lastcall'
    else this.phase = 'overtime'
    if (prev !== this.phase) {
      if (this.phase === 'peak') { this.events.push({ t: 'msg', text: 'Dinner rush!' }); this.events.push({ t: 'sfx', name: 'bell' }) }
      if (this.phase === 'lastcall') this.events.push({ t: 'msg', text: 'Last orders soon' })
      if (this.phase === 'overtime') { this.doorsClosed = true; this.events.push({ t: 'msg', text: 'Doors closed! Finish the room' }) }
    }
    if (this.phase === 'overtime') {
      this.overtime += dt
      const active = this.parties.some(p => p.state !== 'gone' && p.state !== 'leaving')
      if (!active && this.flights.length === 0) this.finish()
      else if (this.overtime > 50) {
        for (const p of this.parties) if (p.state !== 'gone' && p.state !== 'leaving') this.leave(p, false)
        this.finish()
      }
    }
  }

  finish(): void {
    if (this.ended) return
    this.ended = true
    this.phase = 'done'
    this.events.push({ t: 'sfx', name: 'applause' })
  }

  // ─── Mei ────────────────────────────────────────────────────────────────
  private updateMei(dt: number, cmd: Commands): void {
    const m = this.mei
    const speed = MEI_SPEED * (this.mods.upgrades.sneakers ? 1.15 : 1)
    // Aim and throw.
    if (m.aim) {
      const cands = this.throwCandidates()
      if (!cmd.aimHeld) {
        this.release()
      } else if (!cands.length || !m.hands) {
        m.aim = null
      } else {
        m.aim.phase += dt * 1.05
        m.aim.table = this.pickAimTable(cands, cmd)
        const tb = this.tables[m.aim.table]
        m.face = Math.atan2(tb.x - m.x, tb.z - m.z)
        m.speed = 0
        return
      }
    } else if (cmd.aimHeld && m.hands?.ready && !m.work) {
      const cands = this.throwCandidates()
      if (cands.length) {
        m.aim = { table: this.pickAimTable(cands, cmd), phase: 0.25 }
        m.goto = null
        m.speed = 0
        return
      } else if (!this.hintsShown.has('nothrow' + Math.floor(this.time / 3))) {
        this.hintsShown.add('nothrow' + Math.floor(this.time / 3))
        this.events.push({ t: 'pop', text: 'No table is waiting for this', x: m.x, z: m.z, kind: 'info' })
      }
    }
    // Work modes.
    if (m.work) {
      if (m.work.kind === 'plate') {
        if (cmd.dir) this.plateInput(cmd.dir)
        m.speed = 0
        return
      }
      if (Math.hypot(cmd.move.x, cmd.move.z) > 0.3 || cmd.goto) {
        m.work = null
      } else if (!this.station(m.work.station)?.item) {
        m.work = null
      } else {
        if (cmd.interact) this.tap()
        m.speed = 0
        return
      }
    }
    if (cmd.goto) {
      const tp = this.targetPos(cmd.goto)
      if (Math.hypot(tp.x - m.x, tp.z - m.z) - tp.r < INTERACT_PAD) { this.interact(cmd.goto); m.goto = null }
      else { m.goto = cmd.goto; m.stuck = 0; m.lastD = Infinity }
    }
    let mx = cmd.move.x
    let mz = cmd.move.z
    const manual = Math.hypot(mx, mz) > 0.15
    if (manual) m.goto = null
    if (!manual && m.goto) {
      const tp = this.targetPos(m.goto)
      const ap = this.approach(m.goto)
      const d = Math.hypot(ap.x - m.x, ap.z - m.z)
      const edge = Math.hypot(tp.x - m.x, tp.z - m.z) - tp.r
      if (edge < INTERACT_PAD * 0.75 || d < 0.12) {
        const g = m.goto
        m.goto = null
        this.interact(g)
      } else {
        mx = (ap.x - m.x) / d
        mz = (ap.z - m.z) / d
        // Unstick: steer sideways if progress stalls against an obstacle.
        m.stuck += dt
        if (m.stuck > 0.35) {
          if (m.lastD - d < 0.08) m.steer = 0.5
          m.lastD = d
          m.stuck = 0
        }
        if (m.steer > 0) {
          m.steer -= dt
          const sx = -mz, sz = mx
          mx = mx * 0.35 + sx * 0.9
          mz = mz * 0.35 + sz * 0.9
        }
        const l = Math.hypot(mx, mz) || 1
        mx /= l; mz /= l
      }
    }
    const len = Math.hypot(mx, mz)
    if (len > 0.05) {
      const k = Math.min(1, len)
      m.x += (mx / len) * speed * k * dt
      m.z += (mz / len) * speed * k * dt
      m.face = Math.atan2(mx, mz)
      m.speed = speed * k
      if (this.tutorial) this.tutorial.moved += speed * k * dt
    } else m.speed = 0
    this.collide(m, 0.3)
    if (cmd.interact && !m.goto) {
      const f = this.focus()
      if (f) this.interact(f)
    }
  }

  private collide(e: { x: number; z: number }, r: number): void {
    for (let pass = 0; pass < 2; pass++) {
      for (const o of this.obstacles()) {
        const dx = e.x - o.x, dz = e.z - o.z
        const d = Math.hypot(dx, dz)
        const min = o.r + r
        if (d < min && d > 1e-5) { e.x = o.x + (dx / d) * min; e.z = o.z + (dz / d) * min }
        else if (d <= 1e-5) e.x += min
      }
    }
    e.x = Math.min(ROOM.maxX - r, Math.max(ROOM.minX + r, e.x))
    e.z = Math.min(ROOM.maxZ - r, Math.max(ROOM.minZ + r, e.z))
  }

  approach(t: TargetRef): Vec {
    const p = this.targetPos(t)
    const off = p.r + 0.42
    if (t.kind === 'station') {
      const s = this.station(t.id)!
      if (t.id === 'pass' || t.id === 'bar') {
        const side = this.mei.x < s.x ? -1 : 1
        return { x: s.x + side * off, z: s.z }
      }
      return { x: s.x + s.face.x * off, z: s.z + s.face.z * off }
    }
    if (t.kind === 'door') return { x: DOOR.x - 0.5, z: DOOR.z - 0.35 }
    const dx = this.mei.x - p.x, dz = this.mei.z - p.z
    const d = Math.hypot(dx, dz) || 1
    return { x: p.x + (dx / d) * off, z: p.z + (dz / d) * off }
  }

  private say(text: string, kind: 'good' | 'bad' | 'gold' | 'info' | 'money' = 'info', at?: Vec): void {
    const p = at ?? this.mei
    this.events.push({ t: 'pop', text, x: p.x, z: p.z, kind })
  }

  // ─── interactions ───────────────────────────────────────────────────────
  interact(t: TargetRef): void {
    const m = this.mei
    if (m.aim) return
    if (t.kind === 'door') return this.seatFront()
    if (t.kind === 'bin') {
      if (!m.hands) return this.say('Nothing to bin')
      this.discard(m.hands)
      m.hands = null
      this.events.push({ t: 'sfx', name: 'land' })
      return this.say('Binned', 'info')
    }
    if (t.kind === 'table') return this.tableAction(this.tables[t.id], 'mei')
    const s = this.station(t.id)!
    if (s.id === 'uruli') {
      if (this.dirtyGlassware <= 0) return this.say('No dirty glassware to wash', 'info', s)
      this.dirtyGlassware--
      this.stock.glass = (this.stock.glass ?? 0) + 1
      return this.say('Clean glass back on the rack', 'good', s)
    }
    if (s.id === 'steamer') {
      this.stats.revenue = Math.max(0, this.stats.revenue - 60)
      for (const key of ['kallu', 'beer', 'brandy', 'whisky', 'vodka', 'scotch', 'gingerBeer', 'lime', 'sugar', 'bitters', 'orange']) this.stock[key] = Math.min(12, (this.stock[key] ?? 0) + 3)
      this.stock.ice = Math.min(24, (this.stock.ice ?? 0) + 6)
      this.say('Bar stock replenished · ₹60', 'money', s)
      return
    }
    const def = STATIONS[s.id]
    if (def.kind === 'plate') return this.passAction(s)
    if (def.kind === 'tap') return this.tapStationAction(s)
    return this.timedAction(s)
  }

  nextStep(item: Item | null): StationId | null {
    if (!item || item.ready) return null
    return DISHES[item.dish].steps[item.step] ?? null
  }

  private startFromTicket(first: StationId): Item | null {
    const t = this.tickets.filter(t => t.state === 'queued' && DISHES[t.dish].steps[0] === first).sort((a, b) => this.urgency(a) - this.urgency(b))[0]
    if (!t) return null
    if (!this.consumeRecipe(t.dish)) return null
    t.state = 'cooking'
    return { id: this.nextId++, dish: t.dish, step: 0, q: 0, qn: 0, ticket: t.id, spicy: t.spicy, crispy: t.crispy, ready: false }
  }
  private consumeRecipe(dish: DishId): boolean {
    const recipe = DISHES[dish]
    const needs: Record<string, number> = {}
    for (const ingredient of recipe.ingredients) needs[ingredient.itemId] = (needs[ingredient.itemId] ?? 0) + 1
    needs.glass = 1
    if (recipe.ice !== 'none') needs.ice = 1
    if (Object.entries(needs).some(([key, count]) => (this.stock[key] ?? 0) < count)) return this.sayStock(`Out of ${recipe.short} stock. Restock at Storage.`)
    for (const [key, count] of Object.entries(needs)) this.stock[key] = (this.stock[key] ?? 0) - count
    return true
  }
  private sayStock(text: string): false { this.say(text, 'bad', this.station('steamer') ?? DOOR); return false }

  /** Lower = more urgent (less patience left). */
  urgency(t: Ticket): number {
    const p = this.party(t.party)
    return p ? p.patience / p.max : 9
  }

  private timedAction(s: Station): void {
    const m = this.mei
    const def = STATIONS[s.id]
    if (s.burnt > 0) {
      s.burnt = 0
      s.item = null
      this.events.push({ t: 'fx', kind: 'smoke', x: s.x, z: s.z })
      return this.say('Pan scraped clean')
    }
    if (s.item) {
      const f = s.t / this.cookTime(s)
      if (f < READY) return this.say(`${def.verb}ing… not yet`, 'info', s)
      // Swap: holding the next ingredient for this station → pull the cooked dish and drop the new one in.
      const swap = m.hands && !m.hands.ready && this.nextStep(m.hands) === s.id ? m.hands : null
      if (m.hands && !swap) return this.say('Hands full! Park it on the Pass (8)', 'bad')
      const w = this.windows(s.item)
      let q: number, label: string, kind: 'gold' | 'good'
      if (f >= w.pLo && f <= w.pHi) { q = 1; label = 'PERFECT!'; kind = 'gold' }
      else if (f < w.pLo) { q = 0.72; label = s.item.crispy ? 'Not crispy enough' : 'A bit early'; kind = 'good' }
      else { q = f <= w.gHi ? 0.78 : 0.55; label = f <= w.gHi ? 'Good' : 'Overdone'; kind = 'good' }
      const item = s.item
      item.q += q; item.qn += 1; item.step += 1
      s.item = null; s.t = 0
      if (swap) { s.item = swap; this.say('Swap!', 'good', { x: s.x, z: s.z + 0.6 }) }
      m.hands = item
      if (q === 1) { this.stats.perfectCooks++; this.addCombo(1, s) }
      this.events.push({ t: 'sfx', name: q === 1 ? 'tip' : 'land' })
      this.events.push({ t: 'fx', kind: s.id === 'steamer' ? 'steam' : 'sparks', x: s.x, z: s.z })
      this.say(label, kind, s)
      this.checkDrinkReady(item)
      return
    }
    if (m.hands) {
      if (this.nextStep(m.hands) !== s.id) return this.say(this.wrongStation(m.hands), 'bad')
      s.item = m.hands; m.hands = null; s.t = 0
    } else {
      const item = this.startFromTicket(s.id)
      if (!item) return this.say(this.noWorkHint(s.id), 'info', s)
      s.item = item; s.t = 0
    }
    this.events.push({ t: 'sfx', name: s.id === 'steamer' ? 'steam' : 'sizzle' })
    this.events.push({ t: 'fx', kind: s.id === 'steamer' ? 'steam' : 'sparks', x: s.x, z: s.z })
  }

  cookTime(s: Station): number {
    return STATIONS[s.id].cook * (this.hasJob('scrub') ? 0.9 : 1)
  }

  private tapsNeeded(s: Station): number {
    if (s.id === 'prep' && this.hasJob('prep')) return 1
    if (s.id === 'bar' && s.item) {
      const pours = DISHES[s.item.dish].pours ?? STATIONS.bar.taps
      return this.mods.upgrades.shaker ? Math.max(1, pours - 1) : pours
    }
    return STATIONS[s.id].taps
  }

  private tapStationAction(s: Station): void {
    const m = this.mei
    if (s.id === 'bar' && !m.hands && !s.item && this.barShelf.length) {
      m.hands = this.barShelf.shift()!
      return this.say(`${DISHES[m.hands.dish].short} grabbed`, 'good', s)
    }
    if (s.item) {
      if (m.hands) return this.say('Hands full!', 'bad')
      m.work = { kind: 'tap', station: s.id }
      return this.tap()
    }
    if (m.hands) {
      if (this.nextStep(m.hands) !== s.id) return this.say(this.wrongStation(m.hands), 'bad')
      s.item = m.hands; m.hands = null; s.taps = 0
    } else {
      const item = this.startFromTicket(s.id)
      if (!item) return this.say(this.noWorkHint(s.id), 'info', s)
      s.item = item; s.taps = 0
    }
    m.work = { kind: 'tap', station: s.id }
    this.tap()
  }

  private tap(): void {
    const m = this.mei
    if (!m.work || m.work.kind !== 'tap') return
    const s = this.station(m.work.station)!
    if (!s.item) { m.work = null; return }
    s.taps += 1
    m.act = 'chop'; m.actT = 0.3
    this.events.push({ t: 'sfx', name: s.id === 'bar' ? 'shake' : 'chop' })
    this.events.push({ t: 'fx', kind: s.id === 'bar' ? 'splash' : 'chop', x: s.x, z: s.z })
    m.face = Math.atan2(s.x - m.x, s.z - m.z)
    if (s.taps >= this.tapsNeeded(s)) {
      const item = s.item
      item.q += 1; item.qn += 1; item.step += 1
      s.item = null; s.taps = 0
      m.hands = item
      m.work = null
      this.say(s.id === 'bar' ? 'Shaken!' : 'Prepped!', 'good', s)
      this.checkDrinkReady(item)
    }
  }

  private checkDrinkReady(item: Item): void {
    if (item.step >= DISHES[item.dish].steps.length) {
      item.ready = true
      this.say(`${DISHES[item.dish].short} ready!`, 'gold')
      this.hint('ready', 'Dish ready! Walk it to the table, or hold THROW to aim and release in the gold.')
    }
  }

  private passAction(s: Station): void {
    const m = this.mei
    if (!m.hands) {
      if (this.passShelf.length) { m.hands = this.passShelf.shift()!; return this.say('Plate picked up', 'good', s) }
      return this.say('Bring a cooked dish here to plate it', 'info', s)
    }
    if (m.hands.ready && !this.throwCandidatesFor(m.hands).length) return this.say('Nobody needs this: bin it', 'info')
    if (m.hands.ready || this.nextStep(m.hands) !== 'pass') {
      if (this.passShelf.length >= 3) return this.say('The pass is full', 'bad', s)
      this.passShelf.push(m.hands)
      m.hands = null
      this.events.push({ t: 'sfx', name: 'land' })
      return this.say('Parked on the pass', 'info', s)
    }
    const seq = [...DISHES[m.hands.dish].plating]
    if (m.hands.spicy) seq.push('down')
    m.work = { kind: 'plate', station: 'pass', seq, idx: 0, miss: 0 }
    m.face = Math.atan2(s.x - m.x, s.z - m.z)
    this.events.push({ t: 'sfx', name: 'land' })
  }

  plateInput(d: Dir): void {
    const m = this.mei
    if (!m.work || m.work.kind !== 'plate' || !m.hands) return
    const w = m.work
    if (w.seq[w.idx] === d) {
      w.idx++
      this.events.push({ t: 'sfx', name: 'land' })
      this.events.push({ t: 'fx', kind: 'chop', x: STATION_POS.pass.x, z: STATION_POS.pass.z })
    } else {
      w.miss++
      this.events.push({ t: 'sfx', name: 'huff' })
      this.events.push({ t: 'shake', amt: 0.15 })
      this.say('Messy!', 'bad', STATION_POS.pass)
    }
    if (w.idx >= w.seq.length) {
      const item = m.hands
      const q = Math.max(0.45, 1 - 0.18 * w.miss)
      item.q += q; item.qn += 1; item.step += 1; item.ready = true
      m.work = null
      this.events.push({ t: 'sfx', name: 'bell' })
      this.say(w.miss === 0 ? 'Beautiful plate!' : 'Plated', w.miss === 0 ? 'gold' : 'good', STATION_POS.pass)
      if (w.miss === 0) this.addCombo(1, STATION_POS.pass)
      if (this.hasJob('runner') && this.passShelf.length < 3 && this.throwCandidatesFor(item).length) {
        this.passShelf.push(item)
        m.hands = null
        this.say('On the pass for Ravi', 'info', STATION_POS.pass)
      } else this.hint('ready', 'Dish ready! Walk it to the table, or hold THROW to aim and release in the gold.')
    }
  }

  private wrongStation(item: Item): string {
    if (item.ready) return `Serve the ${DISHES[item.dish].short}!`
    const n = this.nextStep(item)
    return n ? `${DISHES[item.dish].short} needs the ${STATIONS[n].name}` : 'Wrong station'
  }

  private noWorkHint(id: StationId): string {
    const any = this.tickets.some(t => t.state === 'queued')
    if (!any) return 'No orders waiting. Take an order first'
    return `No order starts at the ${STATIONS[id].name}`
  }

  discard(item: Item): void {
    const t = this.tickets.find(t => t.id === item.ticket)
    if (t && t.state === 'cooking') t.state = 'queued'
  }

  private updateStations(dt: number): void {
    for (const s of this.stations) {
      s.flame = Math.max(0, s.flame - dt)
      if (STATIONS[s.id].kind !== 'timed') continue
      if (s.burnt > 0) {
        s.burnt += dt
        if (this.hasJob('scrub') && s.burnt > 0.6) { s.burnt = 0; s.item = null }
        continue
      }
      if (!s.item) continue
      s.t += dt
      const f = s.t / this.cookTime(s)
      if (f >= BURN) {
        this.events.push({ t: 'fx', kind: 'smoke', x: s.x, z: s.z })
        this.events.push({ t: 'sfx', name: 'huff' })
        this.events.push({ t: 'shake', amt: 0.25 })
        this.say('Burnt!', 'bad', s)
        this.discard(s.item)
        s.item = null
        s.t = 0
        s.burnt = 0.001
        this.stats.burns++
        this.breakCombo()
        this.hint('burnt', 'Burnt pans must be scraped: press interact at the station.')
      }
    }
  }

  // ─── tables and guests ──────────────────────────────────────────────────
  private seatFront(): void {
    const p = this.queue[0]
    if (!p) return this.say('Nobody waiting at the door')
    const table = this.bestTable(p)
    if (!table) {
      const dirty = this.tables.some(t => t.dirty && t.party < 0)
      return this.say(dirty ? 'Clear a dirty table first!' : 'No free table that fits', 'bad', DOOR)
    }
    this.seat(p, table)
  }

  bestTable(p: Party): Table | null {
    const barCrowd = !!GUESTS[p.type].drinksOnly
    return this.tables
      .filter(t => t.party < 0 && !t.dirty && t.seats >= p.size && (!t.bar || barCrowd))
      .sort((a, b) => Number(b.bar) - Number(a.bar) || a.seats - b.seats || Math.hypot(a.x - DOOR.x, a.z - DOOR.z) - Math.hypot(b.x - DOOR.x, b.z - DOOR.z))[0] ?? null
  }

  private seat(p: Party, t: Table): void {
    t.party = p.id
    p.table = t.id
    p.state = 'walking'
    p.timer = 0
    p.from = { x: p.x, z: p.z }
    p.patience = Math.min(p.max, p.patience + p.max * 0.25)
    this.events.push({ t: 'sfx', name: 'bell' })
    this.say('Right this way!', 'good', DOOR)
    this.addCombo(0, DOOR)
  }

  tableAction(t: Table, by: 'mei' | 'staff'): void {
    const m = this.mei
    const p = t.party >= 0 ? this.party(t.party) : undefined
    if (!p && t.dirty) {
      t.dirty = false
      this.events.push({ t: 'fx', kind: 'splash', x: t.x, z: t.z })
      this.events.push({ t: 'sfx', name: 'land' })
      if (by === 'mei') this.say('Table reset', 'good', t)
      return
    }
    if (!p) return by === 'mei' ? this.say('Empty table: seat guests from the door') : undefined
    if (p.fighting) {
      this.resolveFight(p, by)
      return
    }
    if (p.state === 'ordering') {
      this.takeOrder(p)
      return
    }
    if (by === 'staff') return
    if (p.state === 'waiting' && m.hands?.ready) {
      if (!this.needs(p).includes(m.hands.dish)) return this.say(`They didn't order ${DISHES[m.hands.dish].short}`, 'bad', t)
      const item = m.hands
      m.hands = null
      this.serve(p, item, 'walk')
      return
    }
    if (p.state === 'waiting') return this.say(`Waiting for ${this.needs(p).map(d => DISHES[d].short).join(', ')}`, 'info', t)
    if (p.state === 'menu') return this.say('Still reading the menu', 'info', t)
    if (p.state === 'eating') return this.say('Enjoying their drinks', 'info', t)
  }
  private resolveFight(p: Party, by: 'mei' | 'staff'): void {
    p.fighting = false
    p.trouble = 0
    p.calmUntil = this.time + 24
    p.disruptAt = this.time + 24
    this.stats.saves++
    this.events.push({ t: 'msg', text: by === 'staff' ? 'Bouncer broke up a fight.' : 'You broke up the fight.' })
    this.events.push({ t: 'pop', text: 'Floor safe', x: p.x, z: p.z, kind: 'good' })
    this.events.push({ t: 'sfx', name: 'bell' })
  }

  private takeOrder(p: Party): void {
    p.state = 'waiting'
    p.patience = Math.min(p.max, p.patience + p.max * 0.35)
    for (const d of p.dishes) {
      const def = DISHES[d]
      const hasPass = def.steps.includes('pass')
      const hasTimed = def.steps.some(s => STATIONS[s].kind === 'timed')
      const spicy = hasPass && this.rand() < this.ch.specials * 0.6
      const crispy = !spicy && hasTimed && this.rand() < this.ch.specials * 0.6
      this.tickets.push({ id: this.nextId++, party: p.id, dish: d, spicy, crispy, state: 'queued', at: this.time })
    }
    this.events.push({ t: 'sfx', name: 'chop' })
    this.say('Order up!', 'good', this.tables[p.table])
    this.addCombo(0, this.tables[p.table])
    this.hint('ticket', 'Tickets appear on the rail. Each shows its station route.')
  }

  serve(p: Party, item: Item, how: 'walk' | 'throw' | 'staff', stylish = false): void {
    const mine = this.tickets.filter(t => t.party === p.id && t.dish === item.dish && (t.state === 'queued' || t.state === 'cooking'))
    const chosen = mine.find(t => t.id === item.ticket) ?? mine.find(t => t.state === 'queued') ?? mine[0]
    if (!chosen) return
    if (chosen.id !== item.ticket) {
      const other = this.allItems().find(i => i.ticket === chosen.id)
      const orig = this.tickets.find(t => t.id === item.ticket)
      if (other) other.ticket = item.ticket
      else if (orig && orig.state === 'cooking') orig.state = 'queued'
    }
    chosen.state = 'served'
    const q = item.qn ? item.q / item.qn : 0.7
    p.qSum += q
    p.served += 1
    if (stylish) p.stylish += 1
    const frac = p.patience / p.max
    const tb = this.tables[p.table]
    if (GUESTS[p.type].rowdy && DISHES[item.dish].alcohol) p.trouble = Math.min(1.2, p.trouble + 0.28)
    p.intoxication = Math.min(1, p.intoxication + 0.22)
    this.dirtyGlassware++
    this.stats.dishes++
    this.events.push({ t: 'sfx', name: 'land' })
    this.events.push({ t: 'fx', kind: 'steam', x: tb.x, z: tb.z })
    let bonus = 1
    if (frac < 0.25) { this.stats.saves++; this.say('Clutch save!', 'gold', tb); bonus++ }
    if (this.time - this.lastServeAt < 5) { this.stats.doubles++; this.say('Double service!', 'gold', tb); bonus++ }
    this.lastServeAt = this.time
    this.addCombo(bonus, tb)
    if (this.mode === 'throw' && how !== 'throw') this.say('Walk-ups score nothing tonight', 'info', tb)
    p.patience = Math.min(p.max, p.patience + p.max * 0.25)
    if (this.needs(p).length === 0) {
      p.state = 'eating'
      p.timer = 0
    }
  }

  allItems(): Item[] {
    const out: Item[] = []
    if (this.mei.hands) out.push(this.mei.hands)
    for (const s of this.stations) if (s.item) out.push(s.item)
    for (const f of this.flights) out.push(f.item)
    for (const st of this.staff) if (st.carry) out.push(st.carry)
    out.push(...this.passShelf, ...this.barShelf)
    return out
  }

  private pay(p: Party): void {
    const q = p.served ? p.qSum / p.served : 0
    const pf = p.patience / p.max
    const type = GUESTS[p.type]
    let sat = 0.55 * q + 0.45 * Math.min(1, pf * 1.6)
    if (type.picky && q < 0.9) sat *= 0.7
    sat = Math.max(0, Math.min(1, sat))
    p.sat = sat
    const neon = !!this.mods.upgrades.neon
    const bill = p.dishes.reduce((n, d) => n + DISHES[d].price * (neon && DISHES[d].drink ? 1.25 : 1), 0)
    const decor = (this.mods.upgrades.decor ? 1.12 : 1) * (neon && type.drinksOnly ? 1.2 : 1)
    let tip = bill * (0.06 + 0.34 * sat) * type.tip * this.comboMult * decor
    const stylishShare = p.stylish / Math.max(1, p.dishes.length)
    tip += bill * 0.18 * stylishShare * (this.mode === 'throw' ? 3 : 1)
    let earned = bill + tip
    if (this.mode === 'throw') earned *= stylishShare > 0 ? (0.4 + 0.6 * stylishShare) : 0
    tip = Math.round(tip)
    earned = Math.round(earned)
    this.stats.revenue += earned
    this.stats.tips += this.mode === 'throw' && earned === 0 ? 0 : tip
    this.stats.served++
    this.stats.satSum += sat
    this.stats.satN++
    this.stats.rep += type.rep * (sat - 0.45) * 2
    const tb = this.tables[p.table]
    this.events.push({ t: 'pop', text: `+₹${earned}`, x: tb.x, z: tb.z, kind: 'money' })
    this.events.push({ t: 'fx', kind: 'coins', x: tb.x, z: tb.z })
    this.events.push({ t: 'sfx', name: 'tip' })
    if (sat > 0.85) this.events.push({ t: 'pop', text: type.picky ? 'The critic smiles!' : 'Delighted!', x: tb.x, z: tb.z + 0.4, kind: 'gold' })
    this.leave(p, true)
  }

  private leave(p: Party, happy: boolean): void {
    const tb = p.table >= 0 ? this.tables[p.table] : null
    if (!happy) {
      p.angry = true
      this.stats.walkouts++
      this.stats.satN++
      this.stats.rep -= GUESTS[p.type].rep * 1.2
      const at = tb ?? DOOR
      this.events.push({ t: 'pop', text: 'Walked out!', x: at.x, z: at.z, kind: 'bad' })
      this.events.push({ t: 'sfx', name: 'huff' })
      this.events.push({ t: 'shake', amt: 0.3 })
      this.breakCombo()
      for (const t of this.tickets) if (t.party === p.id && t.state !== 'served') t.state = 'void'
      this.reassignOrphans()
    }
    if (tb) {
      tb.party = -1
      tb.dirty = happy || p.served > 0
      if (tb.dirty) this.hint('dirty', 'Dirty table! Press interact there to clear it before seating.')
    }
    p.state = 'leaving'
    p.timer = 0
    p.from = { x: p.x, z: p.z }
  }

  private reassignOrphans(): void {
    for (const it of this.allItems()) {
      const t = this.tickets.find(t => t.id === it.ticket)
      if (t && t.state !== 'void') continue
      const alt = this.tickets.find(t => t.state === 'queued' && t.dish === it.dish)
      if (alt) { alt.state = 'cooking'; it.ticket = alt.id } else it.ticket = null
    }
  }

  private updateParties(dt: number): void {
    const drain = (this.mods.upgrades.bell ? 0.85 : 1) * (this.mods.assist ? 0.7 : 1) * (this.tutorial && this.tutorial.step < 7 ? 0 : 1)
    const qs = this.queue
    for (const p of this.parties) {
      p.timer += dt
      if (GUESTS[p.type].rowdy && p.state !== 'leaving' && p.state !== 'gone' && this.time >= p.calmUntil) {
        p.trouble = Math.min(1.2, p.trouble + dt * 0.055)
        if (p.trouble >= 1 && this.time >= p.disruptAt) {
          p.trouble = 0.35
          p.disruptAt = this.time + 16
          if (p.intoxication > 0.35 && !p.fighting && this.rand() < 0.42) {
            p.fighting = true
            this.events.push({ t: 'msg', text: 'A fight broke out. Only you or the bouncer can intervene!' })
            this.events.push({ t: 'shake', amt: 0.22 })
          }
          for (const other of this.parties) {
            if (other.id === p.id || other.state === 'gone' || other.state === 'leaving' || other.table < 0) continue
            const ot = this.tables[other.table], pt = p.table >= 0 ? this.tables[p.table] : null
            if (pt && Math.hypot(ot.x - pt.x, ot.z - pt.z) < 2.7) other.patience = Math.max(0, other.patience - 5)
          }
          this.events.push({ t: 'msg', text: 'A rowdy guest is disturbing nearby tables — a bouncer can help.' })
          this.events.push({ t: 'pop', text: 'Keep the shop calm', x: p.x, z: p.z, kind: 'bad' })
        }
      }
      switch (p.state) {
        case 'queue': {
          const i = qs.indexOf(p)
          const spot = QUEUE_SPOTS[Math.min(i, QUEUE_SPOTS.length - 1)]
          p.x += (spot.x - p.x) * Math.min(1, dt * 4)
          p.z += (spot.z - p.z) * Math.min(1, dt * 4)
          p.patience -= dt * drain * 0.9 * (this.hasJob('flair') ? 0.6 : 1)
          if (this.hasJob('host')) { /* host handles seating */ }
          break
        }
        case 'walking': {
          const tb = this.tables[p.table]
          const k = Math.min(1, p.timer / 1.3)
          p.x = p.from.x + (tb.x - p.from.x) * k
          p.z = p.from.z + (tb.z + 0.2 - p.from.z) * k
          if (k >= 1) { p.state = 'menu'; p.timer = 0 }
          break
        }
        case 'menu':
          if (p.timer > 2.4) { p.state = 'ordering'; p.timer = 0; this.events.push({ t: 'sfx', name: 'bell' }) }
          break
        case 'ordering':
          p.patience -= dt * drain
          break
        case 'waiting':
          p.patience -= dt * drain * 0.8
          break
        case 'eating':
          if (p.timer > 4.5) this.pay(p)
          break
        case 'leaving': {
          const k = Math.min(1, p.timer / 1.6)
          p.x = p.from.x + (DOOR.x + 0.8 - p.from.x) * k
          p.z = p.from.z + (DOOR.z + 0.6 - p.from.z) * k
          if (k >= 1) p.state = 'gone'
          break
        }
      }
      if ((p.state === 'queue' || p.state === 'ordering' || p.state === 'waiting') && p.patience <= 0) {
        p.patience = 0
        this.leave(p, false)
      }
    }
    if (this.parties.length > 40) this.parties = this.parties.filter(p => p.state !== 'gone')
  }

  // ─── throwing ───────────────────────────────────────────────────────────
  throwCandidatesFor(item: Item): Table[] {
    return this.tables.filter(t => {
      const p = t.party >= 0 ? this.party(t.party) : undefined
      return !!p && this.needs(p).includes(item.dish) && !this.flights.some(f => f.table === t.id && f.item.dish === item.dish && this.needs(p).filter(d => d === item.dish).length <= 1)
    })
  }
  throwCandidates(): Table[] {
    return this.mei.hands?.ready ? this.throwCandidatesFor(this.mei.hands) : []
  }

  private pickAimTable(cands: Table[], cmd: Commands): number {
    const m = this.mei
    if (cmd.aimPoint) {
      const ap = cmd.aimPoint
      return cands.slice().sort((a, b) => Math.hypot(a.x - ap.x, a.z - ap.z) - Math.hypot(b.x - ap.x, b.z - ap.z))[0].id
    }
    if (cmd.aimDir && Math.hypot(cmd.aimDir.x, cmd.aimDir.z) > 0.5) {
      const ang = Math.atan2(cmd.aimDir.x, cmd.aimDir.z)
      const score = (t: Table) => {
        let d = Math.abs(Math.atan2(t.x - m.x, t.z - m.z) - ang)
        if (d > Math.PI) d = Math.PI * 2 - d
        return d
      }
      return cands.slice().sort((a, b) => score(a) - score(b))[0].id
    }
    if (m.aim && cands.some(c => c.id === m.aim!.table)) return m.aim.table
    const own = this.tickets.find(t => t.id === m.hands?.ticket)
    const ownP = own ? this.party(own.party) : undefined
    const ownT = ownP ? cands.find(c => c.id === ownP.table) : undefined
    if (ownT) return ownT.id
    return cands.slice().sort((a, b) => Math.hypot(a.x - m.x, a.z - m.z) - Math.hypot(b.x - m.x, b.z - m.z))[0].id
  }

  /** Needle position in [-1, 1]; 0 is dead centre (stylish). */
  needle(): number {
    return this.mei.aim ? Math.sin(this.mei.aim.phase * Math.PI * 2) : 0
  }
  throwWindows(dist: number): { perfect: number; good: number } {
    const g = this.mods.upgrades.gloves
    const far = dist > 6 ? 0.85 : 1
    const a = this.mods.assist ? 1.25 : 1
    return { perfect: 0.15 * (g ? 1.5 : 1) * far * a, good: Math.min(0.92, 0.58 * (g ? 1.2 : 1) * far * a) }
  }

  private release(): void {
    const m = this.mei
    const aim = m.aim
    m.aim = null
    if (!aim || !m.hands) return
    const tb = this.tables[aim.table]
    const dist = Math.hypot(tb.x - m.x, tb.z - m.z)
    const v = Math.abs(this.needle_(aim.phase))
    const w = this.throwWindows(dist)
    const outcome = v <= w.perfect ? 'perfect' : v <= w.good ? 'good' : 'miss'
    const item = m.hands
    m.hands = null
    this.flights.push({ item, from: { x: m.x, z: m.z }, to: { x: tb.x, z: tb.z }, table: tb.id, t: 0, dur: 0.38 + dist * 0.055, outcome, spin: (this.rand() - 0.5) * 20 })
    this.stats.throws++
    m.act = 'throw'; m.actT = 0.5
    this.events.push({ t: 'anim', who: 'mei', name: 'throw' })
    this.events.push({ t: 'sfx', name: 'throw' })
  }
  private needle_(phase: number): number { return Math.sin(phase * Math.PI * 2) }

  private updateFlights(dt: number): void {
    for (const f of this.flights) f.t += dt
    const landed = this.flights.filter(f => f.t >= f.dur)
    this.flights = this.flights.filter(f => f.t < f.dur)
    for (const f of landed) {
      const tb = this.tables[f.table]
      const p = tb.party >= 0 ? this.party(tb.party) : undefined
      const ok = p && this.needs(p).includes(f.item.dish)
      if (f.outcome === 'miss' || !ok) {
        this.stats.smashes++
        this.discard(f.item)
        this.events.push({ t: 'fx', kind: 'shards', x: f.to.x + 0.5, z: f.to.z + 0.4 })
        this.events.push({ t: 'sfx', name: 'smash' })
        this.events.push({ t: 'shake', amt: 0.45 })
        this.say('SMASH!', 'bad', tb)
        this.breakCombo()
        continue
      }
      this.events.push({ t: 'shake', amt: f.outcome === 'perfect' ? 0.22 : 0.1 })
      if (f.outcome === 'perfect') {
        this.stats.stylish++
        this.events.push({ t: 'fx', kind: 'confetti', x: tb.x, z: tb.z })
        this.events.push({ t: 'sfx', name: 'applause' })
        this.say('STYLISH!', 'gold', { x: tb.x, z: tb.z - 0.5 })
        this.addCombo(1, tb)
      } else this.say('Caught it!', 'good', { x: tb.x, z: tb.z - 0.5 })
      this.serve(p!, f.item, 'throw', f.outcome === 'perfect')
    }
  }

  // ─── combo ──────────────────────────────────────────────────────────────
  addCombo(n: number, at: Vec): void {
    if (n <= 0) { if (this.combo > 0) this.comboTimer = Math.max(this.comboTimer, 6); return }
    const before = Math.floor(this.comboMult * 4)
    this.combo += n
    this.comboTimer = this.hasJob('flair') ? 15 : 12
    this.stats.maxCombo = Math.max(this.stats.maxCombo, this.combo)
    if (Math.floor(this.comboMult * 4) > before && this.combo >= 5) this.events.push({ t: 'pop', text: `Tips ×${this.comboMult.toFixed(2)}`, x: at.x, z: at.z, kind: 'gold' })
  }
  breakCombo(): void {
    if (this.combo >= 3) this.events.push({ t: 'msg', text: `Combo broken (${this.combo})` })
    this.combo = 0
    this.comboTimer = 0
  }

  // ─── spawning ───────────────────────────────────────────────────────────
  private curve(): number {
    if (this.mode === 'endless') return Math.min(1.6, 0.55 + this.clock / 150)
    const f = this.clock / this.duration
    return f < 0.2 ? 0.5 : f < 0.42 ? 0.8 : f < 0.78 ? 1.15 : 0.75
  }

  private updateSpawns(): void {
    if (this.tutorial && this.tutorial.step < 7) return
    if (this.doorsClosed || this.clock >= this.duration) return
    if (this.clock < this.spawnAt) return
    if (this.queue.length >= QUEUE_SPOTS.length) { this.spawnAt = this.clock + 1.5; return }
    const types = this.ch.guests
    const weights = types.map(t => (t === 'critic' ? 0.5 : t === 'family' ? 0.7 : t === 'barfly' ? (this.mods.upgrades.neon ? 1.1 : 0.75) : 1))
    let r = this.rand() * weights.reduce((a, b) => a + b, 0)
    let type = types[0]
    for (let i = 0; i < types.length; i++) { r -= weights[i]; if (r <= 0) { type = types[i]; break } }
    const def = GUESTS[type]
    const maxSeats = Math.max(...this.tables.map(t => t.seats))
    const size = Math.min(maxSeats, def.size[0] + Math.floor(this.rand() * (def.size[1] - def.size[0] + 1)))
    const n = def.dishes[0] + Math.floor(this.rand() * (def.dishes[1] - def.dishes[0] + 1))
    const dishes: DishId[] = []
    const pool = def.drinksOnly ? this.ch.dishes.filter(d => DISHES[d].drink) : this.ch.dishes
    for (let i = 0; i < n; i++) dishes.push(pool[Math.floor(this.rand() * pool.length)])
    this.spawnParty(type, dishes, size)
    const rate = this.ch.rate * this.curve()
    this.spawnAt = this.clock + (60 / rate) * (0.75 + this.rand() * 0.5)
  }

  spawnParty(type: GuestTypeId, dishes: DishId[], size: number, _a = false, _b = false): Party {
    const def = GUESTS[type]
    const max = def.patience
    const p: Party = {
      id: this.nextId++, type, size, dishes, state: 'queue', patience: max, max, table: -1, timer: 0, qSum: 0, served: 0, stylish: 0,
      x: DOOR.x + 1.2, z: DOOR.z + 0.6, from: { x: 0, z: 0 }, angry: false, look: Math.floor(this.rand() * 1000), sat: 0,
      trouble: GUESTS[type].rowdy ? 0.32 : 0, calmUntil: 0, disruptAt: this.time + 12, intoxication: 0, fighting: false,
    }
    this.parties.push(p)
    this.events.push({ t: 'sfx', name: 'bell' })
    this.hint('arrive', 'Guests at the door! Press interact at the door (or press Q) to seat them.')
    return p
  }

  // ─── staff ──────────────────────────────────────────────────────────────
  /** Replace the crew (used at start and when hiring or reassigning mid-shift). Existing members keep their place. */
  setStaff(list: Mods['staff']): void {
    const next: StaffState[] = []
    for (const s of list) {
      const old = this.staff.find(o => o.role === s.role)
      if (old && old.job === s.job) { next.push(old); continue }
      if (old?.carry) { this.passShelf.push(old.carry); old.carry = null }
      const home = this.staffHome(s.job)
      const at = old ?? { x: home.x, z: home.z }
      next.push({ ...s, x: at.x, z: at.z, tx: home.x, tz: home.z, task: 'idle', carry: null, timer: 0, target: -1, face: 0 })
    }
    for (const o of this.staff) if (!next.includes(o) && o.carry) { this.passShelf.push(o.carry); o.carry = null }
    this.staff = next
    ;(this.mods as { staff: Mods['staff'] }).staff = list
  }

  staffHome(job: StaffJob): Vec {
    switch (job) {
      case 'host': return { x: 5.3, z: 3.4 }
      case 'runner': return { x: 1.2, z: -0.4 }
      case 'prep': return { x: -5.4, z: -1.3 }
      case 'bar': return { x: -0.8, z: 1.7 }
      case 'mixer': return { x: -0.7, z: this.hasJob('bar') ? 2.45 : 1.7 }
      case 'flair': return { x: -0.7, z: 2.45 }
      case 'bus': return { x: SINK.x + 0.6, z: SINK.z }
      case 'scrub': return { x: SINK.x + 0.6, z: SINK.z - 0.2 }
      case 'bouncer': return { x: 5.8, z: 2.8 }
    }
  }

  private moveStaff(s: StaffState, dt: number, speed = 2.9): boolean {
    const dx = s.tx - s.x, dz = s.tz - s.z
    const d = Math.hypot(dx, dz)
    if (d < 0.08) return true
    const k = Math.min(d, speed * dt)
    s.x += (dx / d) * k
    s.z += (dz / d) * k
    s.face = Math.atan2(dx, dz)
    return false
  }

  private updateStaff(dt: number): void {
    for (const s of this.staff) {
      s.timer += dt
      if (s.job === 'host') this.hostAI(s, dt)
      else if (s.job === 'runner') this.runnerAI(s, dt)
      else if (s.job === 'bus') this.busAI(s, dt)
      else if (s.job === 'bar') this.barAI(s, dt)
      else if (s.job === 'mixer') this.barAI(s, dt, true)
      else if (s.job === 'bouncer') this.bouncerAI(s, dt)
      else { const h = this.staffHome(s.job); s.tx = h.x; s.tz = h.z; this.moveStaff(s, dt) }
    }
  }

  private goTo(s: StaffState, p: Vec, offset = 0.85): void {
    const dx = s.x - p.x, dz = s.z - p.z
    const d = Math.hypot(dx, dz) || 1
    s.tx = p.x + (dx / d) * offset
    s.tz = p.z + (dz / d) * offset
  }

  private hostAI(s: StaffState, dt: number): void {
    if (s.task === 'idle') {
      const ordering = this.parties.find(p => p.state === 'ordering' && !this.staff.some(o => o !== s && o.target === p.table && o.task === 'order'))
      if (ordering) { s.task = 'order'; s.target = ordering.table; this.goTo(s, this.tables[ordering.table]) }
      else if (this.queue.length && this.bestTable(this.queue[0])) { s.task = 'seat'; s.tx = DOOR.x - 0.6; s.tz = DOOR.z - 0.4 }
      else { const h = this.staffHome('host'); s.tx = h.x; s.tz = h.z }
    }
    const arrived = this.moveStaff(s, dt)
    if (!arrived) return
    if (s.task === 'seat') {
      const p = this.queue[0]
      const t = p && this.bestTable(p)
      if (p && t) this.seat(p, t)
      s.task = 'idle'
    } else if (s.task === 'order') {
      const t = this.tables[s.target]
      const p = t.party >= 0 ? this.party(t.party) : undefined
      if (p && p.state === 'ordering') this.takeOrder(p)
      s.task = 'idle'
    }
  }

  private runnerAI(s: StaffState, dt: number): void {
    if (s.task === 'idle') {
      const readyPass = this.passShelf.find(i => i.ready && this.throwCandidatesFor(i).length)
      const src = readyPass ? 'pass' : this.barShelf.length ? 'bar' : null
      if (src) {
        const item = src === 'pass' ? readyPass! : this.barShelf[0]
        if (this.throwCandidatesFor(item).length) {
          s.task = 'fetch'
          s.target = src === 'pass' ? 0 : 1
          const st = this.station(src as StationId)!
          s.tx = st.x + 0.9; s.tz = st.z
        }
      } else { const h = this.staffHome('runner'); s.tx = h.x; s.tz = h.z }
    }
    const arrived = this.moveStaff(s, dt, 3.1)
    if (!arrived) return
    if (s.task === 'fetch') {
      const shelf = s.target === 0 ? this.passShelf : this.barShelf
      const idx = shelf.findIndex(i => i.ready)
      const item = idx >= 0 ? shelf.splice(idx, 1)[0] : undefined
      if (!item) { s.task = 'idle'; return }
      const t = this.throwCandidatesFor(item)[0]
      if (!t) { shelf.unshift(item); s.task = 'idle'; return }
      s.carry = item
      s.task = 'deliver'
      s.target = t.id
      this.goTo(s, t)
    } else if (s.task === 'deliver') {
      const t = this.tables[s.target]
      const p = t.party >= 0 ? this.party(t.party) : undefined
      const item = s.carry!
      if (p && this.needs(p).includes(item.dish)) { s.carry = null; this.serve(p, item, 'staff') }
      else {
        const alt = this.throwCandidatesFor(item)[0]
        if (alt) { s.target = alt.id; this.goTo(s, alt); return }
        this.passShelf.push(item); s.carry = null
      }
      s.task = 'idle'
    }
  }

  private busAI(s: StaffState, dt: number): void {
    if (s.task === 'idle') {
      const t = this.tables.find(t => t.dirty && t.party < 0 && !this.staff.some(o => o !== s && o.target === t.id && o.task === 'bus'))
      if (t) { s.task = 'bus'; s.target = t.id; this.goTo(s, t) }
      else { const h = this.staffHome('bus'); s.tx = h.x; s.tz = h.z }
    }
    const arrived = this.moveStaff(s, dt, 2.7)
    if (arrived && s.task === 'bus') {
      const t = this.tables[s.target]
      if (t.dirty && t.party < 0) this.tableAction(t, 'staff')
      s.task = 'idle'
    }
  }

  private bouncerAI(s: StaffState, dt: number): void {
    if (s.task === 'calm') {
      const p = this.party(s.target)
      if (!p || p.state === 'leaving' || p.state === 'gone') { s.task = 'idle'; return }
      if (!this.moveStaff(s, dt, 3.6)) return
      this.resolveFight(p, 'staff')
      s.task = 'idle'
      return
    }
    const target = this.parties
      .filter(p => GUESTS[p.type].rowdy && p.trouble >= 0.28 && this.time >= p.calmUntil && p.state !== 'leaving' && p.state !== 'gone')
      .filter(p => !this.staff.some(o => o !== s && o.job === 'bouncer' && o.task === 'calm' && o.target === p.id))
      .sort((a, b) => b.trouble - a.trouble)[0]
    if (target) {
      s.task = 'calm'
      s.target = target.id
      this.goTo(s, { x: target.x, z: target.z }, 0.55)
      return
    }
    const h = this.staffHome('bouncer')
    s.tx = h.x; s.tz = h.z
    this.moveStaff(s, dt)
  }

  private barAI(s: StaffState, dt: number, mixer = false): void {
    const h = this.staffHome(s.job); s.tx = h.x; s.tz = h.z
    this.moveStaff(s, dt)
    if (s.timer < (mixer ? 2.4 : 3.2)) return
    // The bar back only handles one-step drinks; the mixologist makes everything and serves the counter.
    const t = this.tickets
      .filter(t => t.state === 'queued' && DISHES[t.dish].drink && (mixer || DISHES[t.dish].steps.length === 1))
      .filter(t => mixer && this.tables[this.party(t.party)?.table ?? -1]?.bar ? true : this.barShelf.length < 2)
      .sort((a, b) => this.urgency(a) - this.urgency(b))[0]
    if (!t) return
    s.timer = 0
    t.state = 'cooking'
    const item: Item = { id: this.nextId++, dish: t.dish, step: DISHES[t.dish].steps.length, q: 1, qn: 1, ticket: t.id, spicy: false, crispy: false, ready: true }
    this.events.push({ t: 'sfx', name: 'shake' })
    this.events.push({ t: 'fx', kind: 'splash', x: s.x + 0.6, z: s.z })
    const p = this.party(t.party)
    if (mixer && p && p.table >= 0 && this.tables[p.table].bar && p.state === 'waiting') {
      this.serve(p, item, 'staff')
      this.say(`${s.name} slides a ${DISHES[t.dish].short}`, 'good', this.tables[p.table])
      return
    }
    this.barShelf.push(item)
    this.say(`${DISHES[t.dish].short} on the bar`, 'info', this.station('bar') ?? DOOR)
  }

  // ─── tutorial ───────────────────────────────────────────────────────────
  hint(key: string, text: string): void {
    if (this.tutorial && this.tutorial.step < 7) return
    if (this.hintsShown.has(key)) return
    this.hintsShown.add(key)
    this.events.push({ t: 'msg', text })
  }

  private updateTutorial(dt: number): void {
    const tut = this.tutorial!
    tut.t += dt
    const p = this.parties[0]
    const item = this.allItems()[0]
    const adv = () => { tut.step++; tut.t = 0; this.events.push({ t: 'sfx', name: 'tip' }) }
    switch (tut.step) {
      case 0: if (tut.moved > 1.6) adv(); break
      case 1: if (p && p.state !== 'queue') adv(); break
      case 2: if (this.tickets.length) adv(); break
      case 3: if (item && item.step >= 1) adv(); break
      case 4: if (item && item.step >= 2) adv(); break
      case 5: if (item && item.ready) adv(); break
      case 6: if (p && (p.served > 0 || p.state === 'eating' || p.state === 'leaving')) adv(); else if (!item && this.tickets[0]?.state === 'queued') tut.step = 3; break
      case 7: if (tut.t > 6) tut.step = 8; break
    }
  }
}
