import type { Audio, Sfx } from '../engine/audio'
import type { Input } from '../engine/input'
import type { SaveData } from '../engine/save'
import { DISHES, STAFF, STATIONS, STATION_ORDER, type StaffJob } from './data'
import { emptyCommands, Shift, type Commands, type Mods, type ShiftMode, type TargetRef } from './sim'
import type { View } from './view'

export type GameHooks = {
  popup(text: string, x: number, y: number, z: number, kind: string): void
  toast(text: string): void
  ended(shift: Shift): void
}
export type GameMode = 'title' | 'playing' | 'paused' | 'ended'

/** Owns the current shift: turns input into sim commands and sim events into sound, FX and UI. */
export class Game {
  mode: GameMode = 'title'
  shift!: Shift
  chapter = 0
  shiftMode: ShiftMode = 'campaign'
  hover: TargetRef | null = null
  private throwToggle = false
  private cycle = -1
  private endTimer = 0
  private titleCmd = emptyCommands()

  constructor(private readonly view: View, private readonly input: Input, private readonly audio: Audio, private readonly hooks: GameHooks, private readonly save: () => SaveData) {}

  mods(): Mods {
    const d = this.save()
    const staff: Mods['staff'] = []
    for (const def of STAFF) {
      const job = d.staff[def.role]
      if (job) staff.push({ role: def.role, job: job as StaffJob, name: def.name })
    }
    return { upgrades: d.upgrades, staff, assist: d.assist }
  }

  /** Ambient title backdrop: the last unlocked room with a bot-free idle service. */
  showTitle(chapter: number): void {
    this.mode = 'title'
    this.shift = new Shift(chapter, 'campaign', { upgrades: {}, staff: [], assist: false }, { seed: 5 })
    this.view.build(this.shift, true)
  }

  start(chapter: number, mode: ShiftMode, tutorial: boolean): void {
    this.chapter = chapter
    this.shiftMode = mode
    this.shift = new Shift(chapter, mode, this.mods(), { tutorial, seed: (Date.now() & 0xffff) + chapter })
    this.view.build(this.shift)
    this.mode = 'playing'
    this.endTimer = 0
    this.throwToggle = false
  }
  pause(): void { if (this.mode === 'playing') this.mode = 'paused' }
  resume(): void { if (this.mode === 'paused') this.mode = 'playing' }

  private commands(): Commands {
    const c = emptyCommands()
    const inp = this.input
    const s = this.shift
    c.move = { x: inp.move.x, z: -inp.move.y }
    const plating = s.mei.work?.kind === 'plate'
    if (plating) {
      for (const d of ['up', 'down', 'left', 'right'] as const) if (inp.consume(d)) { c.dir = d; break }
      // Interact repeats the expected step for players who cannot do directional input.
      if (this.save().assist && inp.consume('interact')) c.dir = s.mei.work!.kind === 'plate' ? s.mei.work!.seq[s.mei.work!.idx] : null
      c.move = { x: 0, z: 0 }
    }
    if (!plating) c.interact = inp.consume('interact')
    // Throw: hold (default) or toggle.
    const held = inp.held('throw')
    if (this.save().toggleThrow) {
      if (inp.consume('throw')) this.throwToggle = !this.throwToggle
      if (!s.mei.hands?.ready) this.throwToggle = false
      c.aimHeld = this.throwToggle
    } else c.aimHeld = held
    if (s.mei.aim) {
      if (inp.mouse.inside && inp.method === 'keyboard') c.aimPoint = this.view.groundPoint(inp.mouse.x, inp.mouse.y)
      const st = Math.hypot(inp.aimStick.x, inp.aimStick.y) > 0.4 ? inp.aimStick : Math.hypot(inp.move.x, inp.move.y) > 0.5 ? inp.move : null
      if (st) { c.aimDir = { x: st.x, z: -st.y }; c.aimPoint = null }
      // Tapping/clicking a table while aiming retargets it.
      for (const k of inp.clicks) {
        const ref = this.view.pick(k.x, k.y)
        if (ref?.kind === 'table') { const t = s.tables[ref.id]; c.aimPoint = { x: t.x, z: t.z } }
      }
      inp.clicks.length = 0
      if (this.input.method !== 'keyboard') this.view.setRing('hover', null, s)
    }
    // Direct selection: click/tap a target, number keys, door/bin keys, bumpers.
    if (!plating) {
      for (const k of inp.clicks) {
        const ref = this.view.pick(k.x, k.y)
        if (ref) c.goto = ref
      }
      STATION_ORDER.forEach((id, i) => { if (inp.consume(`s${i + 1}` as 's1') && s.station(id)) c.goto = { kind: 'station', id } })
      if (inp.consume('door')) c.goto = { kind: 'door' }
      if (inp.consume('bin')) c.goto = { kind: 'bin' }
      const dirB = inp.consume('next') ? 1 : inp.consume('prev') ? -1 : 0
      if (dirB) {
        const list = s.stations.map(x => x.id)
        this.cycle = (this.cycle + dirB + list.length) % list.length
        c.goto = { kind: 'station', id: list[this.cycle] }
      }
    } else if (inp.consume('bin')) {
      s.mei.work = null
    }
    return c
  }

  step(dt: number): void {
    if (this.mode === 'title') {
      this.shift.step(dt, this.titleCmd)
      this.shift.events.length = 0
      return
    }
    if (this.mode !== 'playing' && this.mode !== 'ended') return
    const s = this.shift
    if (this.mode === 'ended') {
      s.step(dt, emptyCommands())
      this.flush()
      return
    }
    s.step(dt, this.commands())
    this.flush()
    if (s.ended) {
      this.endTimer += dt
      this.mode = 'ended'
      this.hooks.ended(s)
    }
  }

  private flush(): void {
    const s = this.shift
    for (const e of s.events) {
      switch (e.t) {
        case 'pop': this.hooks.popup(e.text, e.x, 1.9, e.z, e.kind); break
        case 'sfx': this.audio.play(e.name as Sfx); break
        case 'shake': this.view.addShake(e.amt); break
        case 'fx': this.view.fxEvent(e.kind, e.x, e.z, e.y ?? (e.kind === 'steam' ? 1.1 : 1)); break
        case 'msg': this.hooks.toast(e.text); break
      }
    }
    s.events.length = 0
  }

  /** Frame-rate work: hover ring, focus ring, view sync. */
  frame(dt: number): void {
    const s = this.shift
    if (!s) return
    const live = this.mode === 'playing'
    if (live && this.input.mouse.inside && this.input.method === 'keyboard' && !s.mei.aim) {
      this.hover = this.view.pick(this.input.mouse.x, this.input.mouse.y)
      this.view.setRing('hover', this.hover, s)
    } else if (!s.mei.aim) { this.hover = null; this.view.setRing('hover', null, s) }
    this.view.setRing('focus', live && !s.mei.aim ? (s.mei.goto ?? s.focus()) : null, s)
    if (this.mode !== 'paused') this.view.sync(s, dt)
    this.audio.setSizzle(this.mode === 'playing' ? this.view.hotLevel : 0)
  }

  /** One-line contextual instruction for the focused target. */
  prompt(): { key: string; text: string } | null {
    const s = this.shift
    if (!s || this.mode !== 'playing') return null
    const m = s.mei
    if (m.aim) return { key: 'release', text: 'Serve safely at the matching table' }
    if (m.work?.kind === 'plate') return { key: 'dirs', text: 'Garnish it: press the arrows in order' }
    if (m.work?.kind === 'tap') return { key: 'interact', text: `Tap to ${STATIONS[m.work.station].verb.toLowerCase()}!` }
    const f = s.focus()
    if (m.hands?.ready && s.throwCandidates().length) {
      if (f?.kind === 'table') return { key: 'interact', text: `Serve ${DISHES[m.hands.dish].short}` }
      return { key: 'throw', text: `Walk to serve the ${DISHES[m.hands.dish].short}` }
    }
    if (!f) {
      if (m.hands) {
        const next = DISHES[m.hands.dish].steps[m.hands.step]
        return next ? { key: 'go', text: `Take the ${DISHES[m.hands.dish].short} to the ${STATIONS[next].name} (${STATIONS[next].key})` } : { key: 'bin', text: 'Nobody needs this now: bin it (X)' }
      }
      return null
    }
    if (f.kind === 'door') return s.queue.length ? { key: 'interact', text: `Seat party of ${s.queue[0].size}` } : null
    if (f.kind === 'bin') return m.hands ? { key: 'interact', text: 'Bin what you are holding' } : null
    if (f.kind === 'table') {
      const t = s.tables[f.id]
      const p = t.party >= 0 ? s.party(t.party) : undefined
      if (!p && t.dirty) return { key: 'interact', text: 'Clear the table' }
      if (p?.state === 'ordering') return { key: 'interact', text: 'Take their order' }
      return null
    }
    const st = s.station(f.id)!
    const def = STATIONS[st.id]
    if (st.burnt > 0) return { key: 'interact', text: 'Clean the station' }
    if (def.kind === 'timed' && st.item) {
      const k = st.t / s.cookTime(st)
      return k >= 0.82 ? { key: 'interact', text: `Finish the ${DISHES[st.item.dish].short}` } : { key: 'wait', text: `${def.verb}ing ${DISHES[st.item.dish].short}… wait for gold` }
    }
    if (m.hands && !m.hands.ready && DISHES[m.hands.dish].steps[m.hands.step] === st.id) return { key: 'interact', text: `${def.verb} the ${DISHES[m.hands.dish].short}` }
    if (st.id === 'pass' && m.hands) return { key: 'interact', text: 'Park it on the pass' }
    if (st.id === 'pass' && s.passShelf.length) return { key: 'interact', text: 'Pick up from the pass' }
    if (!m.hands) {
      const t = s.tickets.find(t => t.state === 'queued' && DISHES[t.dish].steps[0] === st.id)
      if (t) return { key: 'interact', text: `Start ${DISHES[t.dish].short}` }
    }
    return null
  }
}
