import * as THREE from 'three'
import type { GLTF } from 'three/examples/jsm/loaders/GLTFLoader.js'
import { clone as skClone } from 'three/examples/jsm/utils/SkeletonUtils.js'
import type { Assets } from '../engine/assets'
import type { Renderer } from '../engine/renderer'
import { assetUrl } from './assetTable'
import { DISHES, DISH_ORDER, GUESTS, STATIONS, type ChapterDef, type DishId, type StationId } from './data'
import { Particles } from './particles'
import { BIN, DOOR, SINK, READY, type Item, type Party, type Shift, type TargetRef } from './sim'

/** Asset tables by segment. Boot waits for CORE only; dishes and decor stream in behind the title. */
export const CORE_MODELS = ['chars/mei_anim', 'chars/guest_woman_anim', 'chars/guest_man_anim', 'chars/staff_anim']
export const LATE_MODELS = ['decor/lamp', 'decor/plant', 'decor/stool']
const url = (m: string) => assetUrl(`models/${m}.glb`)

/** Rotation that turns each T-posed character from its authored facing to +Z. */
export const CHAR_YAW = -Math.PI / 2

class Actor {
  readonly root = new THREE.Group()
  readonly mixer: THREE.AnimationMixer
  private actions = new Map<string, THREE.AnimationAction>()
  current = ''
  constructor(gltf: GLTF, height: number, tint?: THREE.Color) {
    const model = skClone(gltf.scene)
    fit(model, { height })
    model.rotation.y = CHAR_YAW
    model.traverse(o => {
      const m = o as THREE.Mesh
      if (m.isMesh) {
        m.castShadow = true
        m.frustumCulled = false
        if (tint) {
          const mat = (m.material as THREE.MeshStandardMaterial).clone()
          mat.color = mat.color.clone().multiply(tint)
          m.material = mat
        }
      }
    })
    this.root.add(model)
    this.mixer = new THREE.AnimationMixer(model)
    for (const clip of gltf.animations) this.actions.set(clip.name, this.mixer.clipAction(clip))
  }
  has(name: string): boolean { return this.actions.has(name) }
  play(name: string, opts: { once?: boolean; fade?: number; speed?: number } = {}): void {
    if (!this.actions.has(name)) name = this.actions.has('idle') ? 'idle' : [...this.actions.keys()][0]
    if (this.current === name && !opts.once) return
    const next = this.actions.get(name)!
    const prev = this.actions.get(this.current)
    next.reset()
    next.setLoop(opts.once ? THREE.LoopOnce : THREE.LoopRepeat, Infinity)
    next.clampWhenFinished = !!opts.once
    next.timeScale = opts.speed ?? 1
    next.play()
    if (prev && prev !== next) prev.crossFadeTo(next, opts.fade ?? 0.18, false)
    this.current = name
  }
  speed(s: number): void { const a = this.actions.get(this.current); if (a) a.timeScale = s }
  finished(): boolean {
    const a = this.actions.get(this.current)
    return !a || (a.loop === THREE.LoopOnce && a.time >= a.getClip().duration - 0.05)
  }
}

function fit(obj: THREE.Object3D, o: { height?: number; width?: number }): void {
  obj.updateMatrixWorld(true)
  const box = new THREE.Box3().setFromObject(obj)
  const size = box.getSize(new THREE.Vector3())
  const s = o.height ? o.height / Math.max(1e-4, size.y) : (o.width ?? 1) / Math.max(1e-4, size.x, size.z)
  obj.scale.multiplyScalar(s)
  obj.updateMatrixWorld(true)
  const b2 = new THREE.Box3().setFromObject(obj)
  const c = b2.getCenter(new THREE.Vector3())
  obj.position.x -= c.x
  obj.position.z -= c.z
  obj.position.y -= b2.min.y
}

function canvasTex(w: number, h: number, draw: (g: CanvasRenderingContext2D) => void, repeat?: [number, number]): THREE.CanvasTexture {
  const c = document.createElement('canvas')
  c.width = w; c.height = h
  draw(c.getContext('2d')!)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  t.anisotropy = 4
  if (repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...repeat) }
  return t
}

type GuestVis = { group: THREE.Group; members: Actor[]; ring: THREE.Mesh; state: string; dishes: THREE.Object3D[] }
type StationVis = { group: THREE.Group; light: THREE.PointLight; ring: THREE.Mesh; item: THREE.Object3D | null; itemKey: string; base: number; hit: THREE.Mesh }

export class View {
  readonly scene = new THREE.Scene()
  readonly camera = new THREE.PerspectiveCamera(40, 16 / 9, 0.1, 100)
  readonly fx = new Particles()
  private models = new Map<string, GLTF>()
  private room = new THREE.Group()
  private dyn = new THREE.Group()
  private mei?: Actor
  private meiHeld: THREE.Object3D | null = null
  private meiHeldKey = ''
  private guests = new Map<number, GuestVis>()
  private staff: Actor[] = []
  private stations = new Map<StationId, StationVis>()
  private tables: { group: THREE.Group; dirt: THREE.Group; hit: THREE.Mesh; lamp?: THREE.PointLight }[] = []
  private flights = new Map<object, THREE.Object3D>()
  private shelf: THREE.Object3D[] = []
  private hover: THREE.Mesh
  private focusRing: THREE.Mesh
  private aimRing: THREE.Mesh
  private aimArc: THREE.Line
  private hits: { mesh: THREE.Mesh; ref: TargetRef }[] = []
  private raycaster = new THREE.Raycaster()
  private ground = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0)
  private shake = 0
  private time = 0
  private hemi = new THREE.HemisphereLight('#ffffff', '#443322', 1)
  private key = new THREE.DirectionalLight('#ffffff', 2.2)
  private windowMat?: THREE.MeshBasicMaterial
  shakeEnabled = true
  reducedMotion = false
  private shift?: Shift
  private lastMeiAct = ''
  private titleMode = false

  constructor(private readonly renderer: Renderer, private readonly assets: Assets) {
    this.scene.add(this.room, this.dyn, this.fx.group, this.hemi, this.key, this.key.target)
    this.key.position.set(-3, 12, 6)
    this.key.castShadow = true
    const sc = this.key.shadow.camera
    sc.left = -9; sc.right = 9; sc.top = 7; sc.bottom = -7; sc.near = 1; sc.far = 30
    this.key.shadow.mapSize.set(renderer.shadowMapSize, renderer.shadowMapSize)
    this.key.shadow.bias = -0.0008
    const ringGeo = new THREE.RingGeometry(0.72, 0.86, 40)
    ringGeo.rotateX(-Math.PI / 2)
    this.hover = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.7, depthWrite: false }))
    this.focusRing = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: '#7ef9ff', transparent: true, opacity: 0.85, depthWrite: false }))
    this.aimRing = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: '#ffd35c', transparent: true, opacity: 0.95, depthWrite: false }))
    for (const r of [this.hover, this.focusRing, this.aimRing]) { r.position.y = 0.03; r.visible = false; r.renderOrder = 3; this.scene.add(r) }
    const arcGeo = new THREE.BufferGeometry().setFromPoints(Array.from({ length: 32 }, () => new THREE.Vector3()))
    this.aimArc = new THREE.Line(arcGeo, new THREE.LineDashedMaterial({ color: '#ffd35c', dashSize: 0.18, gapSize: 0.12, transparent: true, opacity: 0.95 }))
    this.aimArc.visible = false
    this.aimArc.frustumCulled = false
    this.scene.add(this.aimArc)
  }

  // ─── loading ────────────────────────────────────────────────────────────
  async loadCore(onEach?: () => void): Promise<void> {
    await Promise.all(CORE_MODELS.map(m => this.assets.gltf(url(m)).then(g => { this.models.set(m, g); onEach?.() })))
  }
  /** Background stream; resolves when late models are ready (rendering falls back until then). */
  loadLate(): Promise<void> {
    let chain = Promise.resolve()
    const out: Promise<void>[] = []
    for (const m of LATE_MODELS) {
      // Bounded: two at a time keeps decode/upload off the critical frame budget.
      const p = chain.then(() => this.assets.gltf(url(m)).then(g => { this.models.set(m, g) }).catch(() => undefined))
      out.push(p)
      if (out.length % 2 === 0) chain = p
    }
    return Promise.all(out).then(() => { if (this.shift) this.decorate(this.shift.ch) })
  }
  private model(name: string, o: { width?: number; height?: number }): THREE.Object3D | null {
    const g = this.models.get(name)
    if (!g) return null
    const m = g.scene.clone(true)
    fit(m, o)
    m.traverse(x => { const mesh = x as THREE.Mesh; if (mesh.isMesh) { mesh.castShadow = true; mesh.receiveShadow = true } })
    const wrap = new THREE.Group()
    wrap.add(m)
    return wrap
  }
  private barStation(id: StationId): THREE.Group {
    const g = new THREE.Group()
    const def = STATIONS[id]
    const base = new THREE.Mesh(new THREE.BoxGeometry(id === 'pass' || id === 'bar' ? 1.35 : 1.1, 0.72, 0.7), new THREE.MeshStandardMaterial({ color: '#241c2b', roughness: 0.34, metalness: 0.18 }))
    base.position.y = 0.36
    base.castShadow = true
    g.add(base)
    const top = new THREE.Mesh(new THREE.BoxGeometry(id === 'pass' || id === 'bar' ? 1.45 : 1.2, 0.08, 0.78), new THREE.MeshStandardMaterial({ color: def.color, roughness: 0.26, metalness: 0.42 }))
    top.position.y = 0.76
    g.add(top)
    if (id === 'bar' || id === 'steamer') {
      const bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 0.42, 12), new THREE.MeshStandardMaterial({ color: id === 'bar' ? '#79d0c4' : '#c7a7ff', roughness: 0.22, metalness: 0.15 }))
      bottle.position.set(-0.28, 1.02, 0)
      g.add(bottle)
      const bottle2 = bottle.clone()
      bottle2.position.x = 0.02
      g.add(bottle2)
    }
    const label = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.2), new THREE.MeshBasicMaterial({ map: canvasTex(320, 72, c => { c.fillStyle = '#140f1d'; c.fillRect(0, 0, 320, 72); c.fillStyle = '#fff1d0'; c.font = 'bold 26px sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(def.name.toUpperCase(), 160, 36) }), transparent: true }))
    label.position.set(0, 0.47, 0.36)
    label.rotation.x = -0.18
    g.add(label)
    return g
  }

  // ─── build ──────────────────────────────────────────────────────────────
  build(shift: Shift, title = false): void {
    this.shift = shift
    this.titleMode = title
    this.clearDyn()
    this.room.clear()
    this.hits = []
    this.stations.clear()
    this.tables = []
    const ch = shift.ch
    this.scene.background = new THREE.Color(ch.light.fog)
    this.scene.fog = new THREE.Fog(ch.light.fog, 18, 34)
    this.hemi.color.set(ch.light.key)
    this.hemi.groundColor.set(ch.light.ambient)
    this.hemi.intensity = 1.25
    this.key.color.set(ch.light.key)
    this.buildRoom(ch)
    for (const s of shift.stations) {
      const g = new THREE.Group()
      g.position.set(s.x, 0, s.z)
      const m = this.barStation(s.id)
      m.rotation.y = Math.atan2(s.face.x, s.face.z)
      g.add(m)
      const glowGeo = new THREE.CircleGeometry(0.85, 36)
      glowGeo.rotateX(-Math.PI / 2)
      const ring = new THREE.Mesh(glowGeo, new THREE.MeshBasicMaterial({ color: STATIONS[s.id].color, transparent: true, opacity: 0.22, depthWrite: false, blending: THREE.AdditiveBlending }))
      ring.position.y = 0.02
      g.add(ring)
      const light = new THREE.PointLight(STATIONS[s.id].color, 0.0, 3.2, 1.8)
      light.position.set(0, 1.4, 0)
      g.add(light)
      const box = new THREE.Box3().setFromObject(m)
      const hit = this.hitCyl(s.r + 0.15, 1.6)
      g.add(hit)
      this.hits.push({ mesh: hit, ref: { kind: 'station', id: s.id } })
      this.room.add(g)
      this.stations.set(s.id, { group: g, light, ring, item: null, itemKey: '', base: Math.max(0.8, box.max.y), hit })
    }
    shift.tables.forEach(t => {
      const g = new THREE.Group()
      g.position.set(t.x, 0, t.z)
      const m = this.model('decor/table', { width: t.seats === 4 ? 1.25 : 1.05 })
      if (m) g.add(m)
      else {
        const top = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.06, 28), new THREE.MeshStandardMaterial({ color: '#6b3f22' }))
        top.position.y = 0.75
        g.add(top)
      }
      const dirt = new THREE.Group()
      for (let i = 0; i < 2 + (t.seats === 4 ? 1 : 0); i++) {
        const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.06, 0.2, 14), new THREE.MeshStandardMaterial({ color: '#7ec7d2', transparent: true, opacity: 0.62, roughness: 0.18 }))
        const rim = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.012, 6, 14), new THREE.MeshStandardMaterial({ color: '#d9f8ff', metalness: 0.28, roughness: 0.18 }))
        rim.rotation.x = Math.PI / 2
        rim.position.y = 0.11
        plate.add(rim)
        const a = (i / 3) * Math.PI * 2
        plate.position.set(Math.cos(a) * 0.25, 0, Math.sin(a) * 0.22)
        dirt.add(plate)
      }
      g.add(dirt)
      const hit = this.hitCyl(0.8, 1.4)
      g.add(hit)
      this.hits.push({ mesh: hit, ref: { kind: 'table', id: t.id } })
      // A small tabletop brass diya keeps the guest area warm without hanging cords.
      const diyaBase = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 0.06, 12), new THREE.MeshStandardMaterial({ color: '#b88632', metalness: 0.72, roughness: 0.34 }))
      diyaBase.position.set(0, 0.83, 0)
      const diyaFlame = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), new THREE.MeshBasicMaterial({ color: '#ffd16b' }))
      diyaFlame.position.set(0, 0.9, 0)
      g.add(diyaBase, diyaFlame)
      this.room.add(g)
      this.tables.push({ group: g, dirt, hit })
    })
    // Door and bin pick targets.
    const doorHit = this.hitCyl(0.75, 2)
    doorHit.position.set(DOOR.x, 0, DOOR.z)
    this.room.add(doorHit)
    this.hits.push({ mesh: doorHit, ref: { kind: 'door' } })
    const binHit = this.hitCyl(0.5, 1)
    binHit.position.set(BIN.x, 0, BIN.z)
    this.room.add(binHit)
    this.hits.push({ mesh: binHit, ref: { kind: 'bin' } })
    this.decorate(ch)
    // Actors.
    const meiG = this.models.get('chars/mei_anim')!
    this.mei = new Actor(meiG, 1.5)
    this.mei.play('idle')
    this.dyn.add(this.mei.root)
    for (const s of shift.staff) {
      const tint = new THREE.Color(s.role === 'server' ? '#bfe8e0' : s.role === 'prepcook' ? '#ffd8a8' : s.role === 'bouncer' ? '#d38b75' : '#e2c8ff')
      const a = new Actor(this.models.get('chars/staff_anim')!, 1.42, tint)
      a.play('idle')
      this.dyn.add(a.root)
      this.staff.push(a)
    }
    this.fx.clear()
    this.resize()
  }

  private decorate(ch: ChapterDef): void {
    this.room.children.filter(c => c.userData.decor).forEach(c => this.room.remove(c))
    for (const d of ch.decor) {
      const m = this.model(`decor/${d.kind}`, d.kind === 'lamp' ? { height: 1.6 } : d.kind === 'plant' ? { height: 1.5 } : { height: 0.8 })
      if (!m) continue
      m.position.set(d.x, 0, d.z)
      m.userData.decor = true
      this.room.add(m)
    }
    // Bar stools along the bar's dining side.
    const bar = this.shift?.station('bar')
    if (bar) for (const dz of [-0.55, 0.55]) {
      const s = this.model('decor/stool', { height: 0.75 })
      if (!s) break
      s.position.set(bar.x + 0.95, 0, bar.z + dz)
      s.userData.decor = true
      this.room.add(s)
    }
  }

  private hitCyl(r: number, h: number): THREE.Mesh {
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, 12), new THREE.MeshBasicMaterial({ visible: false }))
    m.position.y = h / 2
    return m
  }

  private buildRoom(ch: ChapterDef): void {
    const style = ch.mapStyle
    const tile = canvasTex(256, 256, g => {
      const base = new THREE.Color(style === 'monsoon-road' ? '#784b35' : style === 'palm-shaap' ? '#5f5145' : style === 'backwater' ? '#3e4a49' : '#28272b')
      for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) {
        const c = base.clone().offsetHSL(0, 0, ((x * 7 + y * 11) % 5 - 2) * 0.025)
        g.fillStyle = '#' + c.getHexString()
        g.fillRect(x * 32, y * 32, 32, 32)
        g.strokeStyle = 'rgba(0,0,0,.2)'; g.lineWidth = 1
        g.strokeRect(x * 32, y * 32, 32, 32)
      }
      if (style === 'heritage-bar' || style === 'grand-opening') {
        g.strokeStyle = 'rgba(220,174,78,.34)'; g.lineWidth = 4
        g.strokeRect(10, 10, 236, 236)
      }
    }, [4, 5])
    const wood = canvasTex(256, 256, g => {
      const base = new THREE.Color(ch.floor)
      for (let i = 0; i < 8; i++) {
        const c = base.clone().offsetHSL(0, 0, (Math.sin(i * 7.3) * 0.5) * 0.07)
        g.fillStyle = '#' + c.getHexString(); g.fillRect(0, i * 32, 256, 32)
        g.fillStyle = 'rgba(0,0,0,.24)'; g.fillRect(0, i * 32, 256, 2)
        g.fillRect(((i * 97) % 200) + 20, i * 32, 2, 32)
      }
      if (style === 'heritage-bar' || style === 'grand-opening') {
        g.strokeStyle = 'rgba(245,195,92,.32)'; g.lineWidth = 3
        for (let y = 16; y < 256; y += 64) { g.beginPath(); g.moveTo(0, y); g.lineTo(256, y); g.stroke() }
      }
    }, [3, 4])
    const kFloor = new THREE.Mesh(new THREE.PlaneGeometry(7.9, 8.8), new THREE.MeshStandardMaterial({ map: tile, roughness: style === 'heritage-bar' ? 0.32 : 0.7, metalness: style === 'heritage-bar' ? 0.18 : 0.02 }))
    kFloor.rotation.x = -Math.PI / 2; kFloor.position.set(-3.05, 0, 0.2); kFloor.receiveShadow = true
    const dFloor = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 8.8), new THREE.MeshStandardMaterial({ map: wood, roughness: style === 'heritage-bar' ? 0.38 : 0.7 }))
    dFloor.rotation.x = -Math.PI / 2; dFloor.position.set(4.5, 0, 0.2); dFloor.receiveShadow = true
    const outer = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), new THREE.MeshStandardMaterial({ color: ch.light.fog }))
    outer.rotation.x = -Math.PI / 2; outer.position.y = -0.01
    const trimColor = style === 'palm-shaap' || style === 'backwater' || style === 'monsoon-road' ? '#9b6c36' : '#d4a63a'
    const trim = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.03, 8.8), new THREE.MeshStandardMaterial({ color: trimColor, metalness: 0.65, roughness: 0.4 }))
    trim.position.set(0.9, 0.015, 0.2)
    this.room.add(outer, kFloor, dFloor, trim)

    const wallTex = canvasTex(256, 128, g => {
      g.fillStyle = ch.wall; g.fillRect(0, 0, 256, 128)
      if (style === 'palm-shaap') {
        g.fillStyle = 'rgba(217,174,105,.42)'
        for (let y = 8; y < 128; y += 13) { g.fillRect(0, y, 256, 3); g.fillRect((y * 7) % 80, y + 4, 160, 2) }
      } else if (style === 'heritage-bar' || style === 'grand-opening') {
        g.strokeStyle = 'rgba(232,184,83,.5)'; g.lineWidth = 3
        for (let x = 12; x < 256; x += 42) { g.strokeRect(x, 12, 32, 90); g.fillStyle = 'rgba(234,184,79,.18)'; g.fillRect(x + 3, 15, 26, 84) }
      } else {
        g.fillStyle = 'rgba(255,255,255,.06)'
        for (let x = 0; x < 256; x += 16) g.fillRect(x, 0, 2, 128)
      }
      g.fillStyle = trimColor; g.fillRect(0, 100, 256, 5)
    }, [6, 1])
    const wallMat = new THREE.MeshStandardMaterial({ map: wallTex, roughness: style === 'heritage-bar' ? 0.42 : 0.9 })
    const back = new THREE.Mesh(new THREE.BoxGeometry(15.2, 3.2, 0.2), wallMat)
    back.position.set(0.1, 1.6, -4.3); back.receiveShadow = true
    const left = new THREE.Mesh(new THREE.BoxGeometry(0.2, 3.2, 9), wallMat)
    left.position.set(-7.15, 1.6, 0.2)
    this.room.add(back, left)

    // A hand-painted shaap sign anchors every level; each map adds its own distinct setting around it.
    const signTex = canvasTex(512, 160, g => {
      g.fillStyle = style === 'heritage-bar' || style === 'grand-opening' ? '#201914' : '#6a3b1f'
      g.fillRect(0, 0, 512, 160)
      g.strokeStyle = '#e0b45c'; g.lineWidth = 10; g.strokeRect(7, 7, 498, 146)
      g.fillStyle = '#fff1cd'; g.textAlign = 'center'; g.font = 'bold 48px Georgia'; g.fillText('ATLANTIS BAR', 256, 68)
      g.fillStyle = '#ffd25c'; g.font = 'bold 27px Arial'; g.fillText(style === 'heritage-bar' ? 'HERITAGE COCKTAIL LOUNGE' : 'COCKTAIL SERVICE', 256, 116)
    })
    const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.7, 0.84), new THREE.MeshBasicMaterial({ map: signTex }))
    sign.position.set(style === 'backwater' ? -2.2 : 2.6, 2.95, -4.16)
    this.room.add(sign)

    if (style === 'palm-shaap') {
      // Map 1: palm-thatch shelter, bamboo rail and warm roadside lamps.
      const bamboo = new THREE.MeshStandardMaterial({ color: '#8c6238', roughness: 0.88 })
      for (const x of [1.25, 7.2]) {
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.13, 3.2, 8), bamboo)
        post.position.set(x, 1.6, -0.1); post.castShadow = true; this.room.add(post)
      }
      const beam = new THREE.Mesh(new THREE.BoxGeometry(6.1, 0.16, 0.18), bamboo)
      beam.position.set(4.2, 3.1, -0.1); this.room.add(beam)
      for (let i = 0; i < 9; i++) {
        const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.42, 2.4, 3), new THREE.MeshStandardMaterial({ color: i % 2 ? '#536f37' : '#667d3a', roughness: 0.95 }))
        leaf.rotation.z = Math.PI / 2.3; leaf.rotation.y = i * 0.42; leaf.position.set(7.3 + Math.cos(i * 0.7) * 0.25, 2.0 + Math.sin(i * 0.7) * 0.25, -3.2 + i * 0.06); this.room.add(leaf)
      }
    } else if (style === 'backwater') {
      // Map 2: open water view, a small kettuvallam silhouette and jetty rails.
      const water = canvasTex(256, 128, g => {
        const gr = g.createLinearGradient(0, 0, 0, 128); gr.addColorStop(0, '#f5a565'); gr.addColorStop(0.36, '#477e85'); gr.addColorStop(1, '#153f4c')
        g.fillStyle = gr; g.fillRect(0, 0, 256, 128)
        g.fillStyle = 'rgba(245,225,177,.55)'
        for (let y = 40; y < 128; y += 18) for (let x = (y % 2) * 13; x < 256; x += 48) g.fillRect(x, y, 26, 2)
      })
      const glass = new THREE.MeshBasicMaterial({ map: water }); this.windowMat = glass
      for (const x of [2.3, 4.5, 6.5]) { const w = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 1.45), glass); w.position.set(x, 1.92, -4.17); this.room.add(w) }
      const hull = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.22, 1.5, 8), new THREE.MeshStandardMaterial({ color: '#51331f', roughness: 0.86 }))
      hull.rotation.z = Math.PI / 2; hull.position.set(4.3, 0.72, -4.05); this.room.add(hull)
      for (const x of [1.0, 7.2]) { const rail = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.72, 8.1), new THREE.MeshStandardMaterial({ color: '#8c6238' })); rail.position.set(x, 0.36, 0.2); this.room.add(rail) }
    } else if (style === 'monsoon-road') {
      // Map 3: rain streaks, a roadside bus silhouette and tarpaulin canopy.
      const rain = canvasTex(128, 256, g => {
        const gr = g.createLinearGradient(0, 0, 0, 256); gr.addColorStop(0, '#19334d'); gr.addColorStop(1, '#43626a')
        g.fillStyle = gr; g.fillRect(0, 0, 128, 256)
        for (let i = 0; i < 65; i++) { g.fillStyle = `rgba(205,228,255,${0.18 + (i % 5) * 0.05})`; g.fillRect((i * 37) % 128, (i * 61) % 256, 2, 12 + (i % 5) * 5) }
      })
      this.windowMat = new THREE.MeshBasicMaterial({ map: rain })
      for (const x of [2.1, 4.3, 6.5]) { const w = new THREE.Mesh(new THREE.PlaneGeometry(1.55, 1.55), this.windowMat); w.position.set(x, 1.8, -4.17); this.room.add(w) }
      const bus = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.72, 0.58), new THREE.MeshStandardMaterial({ color: '#cf6b36', roughness: 0.55 }))
      bus.position.set(4.6, 0.56, -4.0); this.room.add(bus)
      for (let i = 0; i < 5; i++) { const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.23, 0.34, 0.025), new THREE.MeshBasicMaterial({ color: '#b9e3ed' })); stripe.position.set(3.95 + i * 0.28, 0.63, -3.69); this.room.add(stripe) }
      const tarp = new THREE.Mesh(new THREE.BoxGeometry(7.0, 0.11, 1.3), new THREE.MeshStandardMaterial({ color: '#345d8b', roughness: 0.88, side: THREE.DoubleSide }))
      tarp.position.set(4.4, 3.35, 1.0); tarp.rotation.x = -0.08; this.room.add(tarp)
    } else if (style === 'heritage-bar') {
      // Map 4: premium brass-framed walls and a glowing bottle shelf.
      for (let i = 0; i < 7; i++) {
        const bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.55 + (i % 3) * 0.12, 10), new THREE.MeshStandardMaterial({ color: ['#bb7b24', '#7b3b22', '#d2b253'][i % 3], metalness: 0.25, roughness: 0.28 }))
        bottle.position.set(-5.8 + i * 0.42, 1.2 + (i % 2) * 0.15, -4.02); this.room.add(bottle)
      }
      for (const x of [1.5, 3.2, 4.9, 6.6]) { const arch = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.045, 8, 24, Math.PI), new THREE.MeshStandardMaterial({ color: '#d5a943', metalness: 0.7, roughness: 0.28 })); arch.position.set(x, 2.1, -4.04); this.room.add(arch) }
    } else {
      // Map 5: grand-opening version with a waterfront window and festive brass light garlands.
      const view = new THREE.Mesh(new THREE.PlaneGeometry(8.8, 1.7), new THREE.MeshBasicMaterial({ color: '#254957' }))
      view.position.set(3.8, 1.92, -4.17); this.room.add(view)
      const archMat = new THREE.MeshStandardMaterial({ color: '#d6a547', metalness: 0.62, roughness: 0.34 })
      for (const x of [1.4, 3.4, 5.4, 7.2]) { const post = new THREE.Mesh(new THREE.BoxGeometry(0.09, 2.8, 0.1), archMat); post.position.set(x, 1.4, -4.0); this.room.add(post) }
      for (let i = 0; i < 11; i++) { const diya = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 8), new THREE.MeshBasicMaterial({ color: i % 2 ? '#ffd16b' : '#ff9e44' })); diya.position.set(1.2 + i * 0.57, 3.0 - Math.sin(i / 10 * Math.PI) * 0.38, -0.1); this.room.add(diya) }
    }

    // Main door with warm spill light.
    const doorFrame = new THREE.Mesh(new THREE.TorusGeometry(0.65, 0.07, 8, 20, Math.PI), new THREE.MeshStandardMaterial({ color: trimColor, metalness: 0.7, roughness: 0.3 }))
    doorFrame.position.set(DOOR.x, 1.9, DOOR.z + 0.55)
    const posts = [-0.65, 0.65].map(dx => { const post = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.9, 0.12), doorFrame.material); post.position.set(DOOR.x + dx, 0.95, DOOR.z + 0.55); return post })
    const mat = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.8), new THREE.MeshStandardMaterial({ color: '#8a2f3a' }))
    mat.rotation.x = -Math.PI / 2; mat.position.set(DOOR.x, 0.012, DOOR.z + 0.1)
    const doorLight = new THREE.PointLight('#ffcf8a', 2.5, 4, 1.6); doorLight.position.set(DOOR.x, 2.2, DOOR.z)
    this.room.add(doorFrame, ...posts, mat, doorLight)
    const bin = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.2, 0.55, 16), new THREE.MeshStandardMaterial({ color: '#b58a2a', metalness: 0.65, roughness: 0.38 }))
    bin.position.set(BIN.x, 0.275, BIN.z); bin.castShadow = true
    const sink = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.85, 0.9), new THREE.MeshStandardMaterial({ color: '#b9c2c6', metalness: 0.55, roughness: 0.38 }))
    sink.position.set(SINK.x - 0.15, 0.425, SINK.z); sink.castShadow = true
    this.room.add(bin, sink)
    const accent = new THREE.PointLight(ch.light.accent, style === 'heritage-bar' ? 7 : 5, 9, 1.4); accent.position.set(-3, 2.4, -1.5)
    const warm = new THREE.PointLight(ch.light.key, style === 'grand-opening' ? 7 : 5, 10, 1.4); warm.position.set(4, 2.8, 0.5)
    this.room.add(accent, warm)
  }

  private clearDyn(): void {
    this.dyn.clear()
    this.guests.clear()
    this.staff = []
    this.flights.clear()
    this.shelf = []
    this.meiHeld = null
    this.meiHeldKey = ''
    this.mei = undefined
  }

  // ─── dish visuals ───────────────────────────────────────────────────────
  dishObject(dish: DishId, ready: boolean, scale = 0.42): THREE.Object3D {
    if (ready) {
      const m = this.model(`dishes/${dish}`, { width: scale })
      if (m) return m
    }
    const g = new THREE.Group()
    if (DISHES[dish].drink) {
      const glassMat = new THREE.MeshPhysicalMaterial({ color: '#e9f5f3', roughness: 0.18, metalness: 0.05, transparent: true, opacity: 0.42, transmission: 0.55 })
      const glass = new THREE.Mesh(new THREE.CylinderGeometry(scale * 0.25, scale * 0.2, scale * 0.6, 16, 1, true), glassMat)
      glass.position.y = scale * 0.31
      const liquid = new THREE.Mesh(new THREE.CylinderGeometry(scale * 0.19, scale * 0.17, scale * 0.34, 14), new THREE.MeshStandardMaterial({ color: DISHES[dish].color, roughness: 0.2, metalness: 0.02 }))
      liquid.position.y = scale * 0.24
      g.add(glass, liquid)
      if (dish === 'beer') {
        const foam = new THREE.Mesh(new THREE.SphereGeometry(scale * 0.19, 12, 8), new THREE.MeshStandardMaterial({ color: '#fff4d6', roughness: 0.6 }))
        foam.scale.y = 0.3; foam.position.y = scale * 0.55; g.add(foam)
      }
      return g
    }
    const bowl = new THREE.Mesh(new THREE.CylinderGeometry(scale * 0.42, scale * 0.3, scale * 0.25, 18, 1, true), new THREE.MeshStandardMaterial({ color: ready ? '#f5efe2' : '#c8922e', metalness: ready ? 0.1 : 0.7, roughness: 0.35, side: THREE.DoubleSide }))
    bowl.position.y = scale * 0.125
    const fill = new THREE.Mesh(new THREE.CircleGeometry(scale * 0.4, 18), new THREE.MeshStandardMaterial({ color: DISHES[dish].color, roughness: 0.6 }))
    fill.rotation.x = -Math.PI / 2
    fill.position.y = scale * 0.2
    g.add(bowl, fill)
    return g
  }
  private itemKey(i: Item | null): string { return i ? `${i.dish}:${i.ready ? 1 : 0}:${i.step}` : '' }

  // ─── per-frame sync ─────────────────────────────────────────────────────
  sync(s: Shift, dt: number): void {
    this.time += dt
    this.syncMei(s, dt)
    this.syncGuests(s, dt)
    this.syncStaff(s, dt)
    this.syncStations(s, dt)
    this.syncTables(s)
    this.syncFlights(s)
    this.syncShelf(s)
    this.syncAim(s)
    this.fx.update(dt)
    if (this.windowMat?.map) this.windowMat.map.offset.y = (this.time * 0.6) % 1
  }

  private syncMei(s: Shift, dt: number): void {
    const a = this.mei
    if (!a) return
    const m = s.mei
    a.root.position.set(m.x, 0, m.z)
    a.root.rotation.y = lerpAngle(a.root.rotation.y, m.face, Math.min(1, dt * 14))
    let clip = m.speed > 0.2 ? 'run' : 'idle'
    if (m.act === 'chop' || m.work?.kind === 'tap') clip = 'chop'
    if (m.aim) clip = 'idle'
    if (m.act === 'throw') clip = 'pitch_baseball'
    if (s.ended) clip = 'victory_celebration'
    if (clip === 'pitch_baseball' && this.lastMeiAct !== 'throw') a.play(clip, { once: true, fade: 0.06, speed: 2.2 })
    else if (clip !== 'pitch_baseball') a.play(clip, { speed: clip === 'run' ? 1.25 : clip === 'chop' ? 2.4 : 1 })
    this.lastMeiAct = m.act
    a.mixer.update(dt)
    const key = this.itemKey(m.hands)
    if (key !== this.meiHeldKey) {
      if (this.meiHeld) a.root.remove(this.meiHeld)
      this.meiHeld = m.hands ? this.dishObject(m.hands.dish, m.hands.ready, 0.46) : null
      if (this.meiHeld) a.root.add(this.meiHeld)
      this.meiHeldKey = key
    }
    if (this.meiHeld) {
      const bob = Math.sin(this.time * 9) * 0.03 * Math.min(1, m.speed)
      this.meiHeld.position.set(0, 1.05 + bob + (m.aim ? 0.35 : 0), 0.38)
      if (m.aim) this.meiHeld.rotation.y += dt * 6
      else this.meiHeld.rotation.y = 0
    }
  }

  private syncGuests(s: Shift, dt: number): void {
    const seen = new Set<number>()
    for (const p of s.parties) {
      if (p.state === 'gone') continue
      seen.add(p.id)
      let v = this.guests.get(p.id)
      if (!v) v = this.makeParty(p)
      this.placeParty(s, p, v, dt)
    }
    for (const [id, v] of this.guests) if (!seen.has(id)) { this.dyn.remove(v.group); this.guests.delete(id) }
  }

  private makeParty(p: Party): GuestVis {
    const group = new THREE.Group()
    const members: Actor[] = []
    const tints = ['#ffffff', '#ffd6c0', '#d8f0ff', '#f0ffd8', '#ffe0f0', '#e8e0ff']
    for (let i = 0; i < p.size; i++) {
      const woman = (p.look + i) % 2 === 0
      const g = this.models.get(woman ? 'chars/guest_woman_anim' : 'chars/guest_man_anim')!
      const a = new Actor(g, (p.type === 'family' && i >= 2 ? 1.05 : 1.38) + ((p.look >> i) % 3) * 0.03, new THREE.Color(tints[(p.look + i * 3) % tints.length]))
      if (p.type === 'family' && i >= 2) a.root.scale.setScalar(1)
      a.play('idle')
      a.mixer.setTime(Math.random() * 3)
      group.add(a.root)
      members.push(a)
    }
    const ringGeo = new THREE.RingGeometry(0.28, 0.36, 24)
    ringGeo.rotateX(-Math.PI / 2)
    const ring = new THREE.Mesh(ringGeo, new THREE.MeshBasicMaterial({ color: GUESTS[p.type].color, transparent: true, opacity: 0.9, depthWrite: false }))
    ring.position.y = 0.025
    group.add(ring)
    this.dyn.add(group)
    const v: GuestVis = { group, members, ring, state: '', dishes: [] }
    this.guests.set(p.id, v)
    return v
  }

  private placeParty(s: Shift, p: Party, v: GuestVis, dt: number): void {
    const seatedish = p.state === 'menu' || p.state === 'ordering' || p.state === 'waiting' || p.state === 'eating'
    const walking = p.state === 'walking' || p.state === 'leaving'
    const tb = p.table >= 0 ? s.tables[p.table] : null
    const low = p.patience / p.max < 0.3
    v.members.forEach((a, i) => {
      let tx = p.x, tz = p.z, face = 0
      if (seatedish && tb) {
        const ang = (i / p.size) * Math.PI * 2 + (p.size === 2 ? Math.PI / 2 : Math.PI / 4)
        const r = tb.seats === 4 ? 0.82 : 0.74
        tx = tb.x + Math.cos(ang) * r
        tz = tb.z + Math.sin(ang) * r
        face = Math.atan2(tb.x - tx, tb.z - tz)
      } else {
        const off = (i - (p.size - 1) / 2) * 0.42
        tx = p.x + off * 0.6
        tz = p.z + Math.abs(off) * 0.3
        face = p.state === 'leaving' ? Math.atan2(1, 0.6) : walking && tb ? Math.atan2(tb.x - p.x, tb.z - p.z) : Math.PI * 1.1
      }
      const cur = a.root.position
      const moving = Math.hypot(tx - cur.x, tz - cur.z) > 0.05
      cur.x += (tx - cur.x) * Math.min(1, dt * 6)
      cur.z += (tz - cur.z) * Math.min(1, dt * 6)
      a.root.rotation.y = lerpAngle(a.root.rotation.y, face, Math.min(1, dt * 8))
      let clip = 'idle'
      if (walking || (moving && p.state === 'queue')) clip = 'walk'
      else if (p.state === 'eating' && p.stylish > 0) clip = 'clap'
      else if (low && (p.state === 'waiting' || p.state === 'ordering' || p.state === 'queue')) clip = 'angry_01'
      else if (p.angry) clip = 'angry_01'
      if (clip === 'idle' && !a.has('idle')) clip = 'standing_relax'
      a.play(clip)
      a.mixer.update(dt)
    })
    const c = v.members.reduce((acc, a) => acc.add(a.root.position), new THREE.Vector3()).multiplyScalar(1 / v.members.length)
    v.ring.position.set(seatedish && tb ? tb.x : c.x, 0.025, seatedish && tb ? tb.z : c.z)
    v.ring.scale.setScalar(seatedish && tb ? 3.4 : 1.4)
    ;(v.ring.material as THREE.MeshBasicMaterial).opacity = low ? 0.5 + 0.5 * Math.sin(this.time * 12) : 0.7
    // Plates appear on the table while eating.
    const wantPlates = p.state === 'eating' && tb ? p.dishes : []
    if (v.dishes.length !== wantPlates.length) {
      v.dishes.forEach(d => this.dyn.remove(d))
      v.dishes = wantPlates.map((d, i) => {
        const o = this.dishObject(d, true, 0.4)
        const ang = (i / Math.max(1, wantPlates.length)) * Math.PI * 2
        o.position.set(tb!.x + Math.cos(ang) * 0.22 * (wantPlates.length > 1 ? 1 : 0), 0.78, tb!.z + Math.sin(ang) * 0.2 * (wantPlates.length > 1 ? 1 : 0))
        this.dyn.add(o)
        return o
      })
    }
  }

  private syncStaff(s: Shift, dt: number): void {
    while (this.staff.length < s.staff.length) {
      const st = s.staff[this.staff.length]
      const tint = new THREE.Color(st.job === 'bouncer' ? '#d38b75' : st.role === 'server' ? '#bfe8e0' : st.role === 'prepcook' ? '#ffd8a8' : '#e2c8ff')
      const actor = new Actor(this.models.get('chars/staff_anim')!, 1.42, tint)
      actor.play('idle'); this.dyn.add(actor.root); this.staff.push(actor)
    }
    s.staff.forEach((st, i) => {
      const a = this.staff[i]
      if (!a) return
      const prev = a.root.position.clone()
      a.root.position.set(st.x, 0, st.z)
      const sp = prev.distanceTo(a.root.position) / Math.max(dt, 1e-4)
      if (sp > 0.3) a.root.rotation.y = lerpAngle(a.root.rotation.y, st.face, Math.min(1, dt * 10))
      a.play(sp > 0.3 ? 'run' : 'idle')
      a.mixer.update(dt)
      const k = `staffcarry${i}`
      const has = a.root.getObjectByName(k)
      if (st.carry && !has) { const o = this.dishObject(st.carry.dish, true, 0.4); o.name = k; o.position.set(0, 1.1, 0.35); a.root.add(o) }
      if (!st.carry && has) a.root.remove(has)
    })
  }

  private syncStations(s: Shift, dt: number): void {
    let hot = 0
    for (const st of s.stations) {
      const v = this.stations.get(st.id)
      if (!v) continue
      const def = STATIONS[st.id]
      const ringMat = v.ring.material as THREE.MeshBasicMaterial
      let color = def.color
      let intensity = 0
      let pulse = 0
      if (st.burnt > 0) { color = '#ff2a2a'; intensity = 2; pulse = 1; if (Math.random() < dt * 20) this.fx.smoke(st.x, v.base, st.z, 1) }
      else if (st.item && def.kind === 'timed') {
        const f = st.t / s.cookTime(st)
        const w = s.windows(st.item)
        hot++
        intensity = 1.2 + f
        if (f >= w.pLo && f <= w.pHi) { color = '#ffd35c'; pulse = 1; intensity = 4 }
        else if (f > w.gHi) { color = '#ff3b30'; pulse = 1; intensity = 3; if (Math.random() < dt * 12) this.fx.smoke(st.x, v.base, st.z, 1) }
        else if (f >= READY) color = '#9be36d'
        const fl = this.reducedMotion ? 0.5 : 1
        if (st.id === 'grill' && Math.random() < dt * 30 * fl) this.fx.flame(st.x + rnd(0.3), v.base - 0.1, st.z + rnd(0.2), 1, '#ff5a1a')
        if (st.id === 'kadai' && Math.random() < dt * (f > 0.7 ? 40 : 12) * fl) this.fx.flame(st.x, v.base, st.z, 1, '#ff8a1a')
        if (st.id === 'tawa' && Math.random() < dt * 8 * fl) this.fx.sparks(st.x, v.base, st.z, 1, '#ffcf6a')
        if ((st.id === 'steamer' || st.id === 'uruli') && Math.random() < dt * 14 * fl) this.fx.steam(st.x, v.base, st.z, 1)
        if ((st.id === 'kadai' || st.id === 'tawa') && Math.random() < dt * 4 * fl) this.fx.steam(st.x, v.base, st.z, 1)
      } else if (st.item) { intensity = 1.5; color = def.color }
      ringMat.color.set(color)
      ringMat.opacity = 0.18 + (pulse ? 0.25 + 0.2 * Math.sin(this.time * 14) : st.item ? 0.12 : 0)
      v.light.color.set(color)
      v.light.intensity += ((intensity + (st.id === 'grill' && st.item ? Math.random() * 1.5 : 0)) - v.light.intensity) * Math.min(1, dt * 10)
      // Item marker on top of the station.
      const key = this.itemKey(st.item)
      if (key !== v.itemKey) {
        if (v.item) v.group.remove(v.item)
        v.item = st.item ? this.dishObject(st.item.dish, false, 0.38) : null
        if (v.item) { v.item.position.y = v.base + 0.02; v.group.add(v.item) }
        v.itemKey = key
      }
      if (v.item && def.kind === 'tap') v.item.position.y = v.base + 0.02 + Math.abs(Math.sin(this.time * 18)) * 0.03 * (s.mei.work?.kind === 'tap' ? 1 : 0)
    }
    this.hotLevel = hot
  }
  hotLevel = 0

  private syncTables(s: Shift): void {
    s.tables.forEach((t, i) => { const v = this.tables[i]; if (v) v.dirt.visible = t.dirty })
    void s
  }

  private syncFlights(s: Shift): void {
    const live = new Set<object>()
    for (const f of s.flights) {
      live.add(f)
      let o = this.flights.get(f)
      if (!o) { o = this.dishObject(f.item.dish, true, 0.46); this.dyn.add(o); this.flights.set(f, o) }
      const k = Math.min(1, f.t / f.dur)
      const miss = f.outcome === 'miss'
      const tx = f.to.x + (miss ? 0.5 : 0), tz = f.to.z + (miss ? 0.4 : 0)
      const x = f.from.x + (tx - f.from.x) * k
      const z = f.from.z + (tz - f.from.z) * k
      const dist = Math.hypot(tx - f.from.x, tz - f.from.z)
      const y = 1.15 + (0.8 - 1.15) * k + Math.sin(k * Math.PI) * (0.6 + dist * 0.18)
      o.position.set(x, y, z)
      o.rotation.y += f.spin * 0.016
      o.rotation.z = miss ? k * 2 : Math.sin(k * 6) * 0.1
      this.fx.trail(x, y + 0.08, z, f.outcome === 'perfect')
    }
    for (const [f, o] of this.flights) if (!live.has(f)) { this.dyn.remove(o); this.flights.delete(f) }
  }

  private syncShelf(s: Shift): void {
    const items = [...s.passShelf.map(i => ({ i, at: 'pass' as const })), ...s.barShelf.map(i => ({ i, at: 'bar' as const }))]
    const key = items.map(x => this.itemKey(x.i) + x.at).join('|')
    if ((this.shelf as unknown as { key?: string }).key === key) return
    this.shelf.forEach(o => this.dyn.remove(o))
    this.shelf = []
    const counts = { pass: 0, bar: 0 }
    for (const x of items) {
      const st = s.station(x.at)
      if (!st) continue
      const v = this.stations.get(x.at)!
      const o = this.dishObject(x.i.dish, x.i.ready, 0.36)
      o.position.set(st.x + 0.05, v.base + 0.02, st.z - 0.4 + counts[x.at]++ * 0.4)
      this.dyn.add(o)
      this.shelf.push(o)
    }
    ;(this.shelf as unknown as { key?: string }).key = key
  }

  private syncAim(s: Shift): void {
    const aim = s.mei.aim
    this.aimRing.visible = !!aim
    this.aimArc.visible = !!aim
    if (!aim) return
    const t = s.tables[aim.table]
    this.aimRing.position.set(t.x, 0.03, t.z)
    this.aimRing.scale.setScalar(1.05 + 0.08 * Math.sin(this.time * 10))
    const v = Math.abs(s.needle())
    const tw = s.throwWindows(Math.hypot(t.x - s.mei.x, t.z - s.mei.z))
    const col = v <= tw.perfect ? '#ffd35c' : v <= tw.good ? '#9be36d' : '#ff5f5f'
    ;(this.aimRing.material as THREE.MeshBasicMaterial).color.set(col)
    ;(this.aimArc.material as THREE.LineDashedMaterial).color.set(col)
    const pos = this.aimArc.geometry.getAttribute('position') as THREE.BufferAttribute
    const dist = Math.hypot(t.x - s.mei.x, t.z - s.mei.z)
    for (let i = 0; i < pos.count; i++) {
      const k = i / (pos.count - 1)
      pos.setXYZ(i, s.mei.x + (t.x - s.mei.x) * k, 1.15 + (0.8 - 1.15) * k + Math.sin(k * Math.PI) * (0.6 + dist * 0.18), s.mei.z + (t.z - s.mei.z) * k)
    }
    pos.needsUpdate = true
    this.aimArc.computeLineDistances()
  }

  // ─── events ─────────────────────────────────────────────────────────────
  fxEvent(kind: string, x: number, z: number, y = 1): void {
    switch (kind) {
      case 'steam': this.fx.steam(x, y, z, 12); break
      case 'sparks': this.fx.sparks(x, y, z, 16); break
      case 'smoke': this.fx.smoke(x, y, z, 18); break
      case 'confetti': this.fx.confetti(x, 1.6, z, 50); break
      case 'splash': this.fx.splash(x, y, z, 14); break
      case 'chop': this.fx.chop(x, y, z, 7); break
      case 'coins': this.fx.coins(x, 1.0, z, 16); break
      case 'shards': this.fx.shards(x, 0.3, z, 26); break
    }
  }
  addShake(a: number): void { if (this.shakeEnabled && !this.reducedMotion) this.shake = Math.min(0.6, this.shake + a) }

  // ─── picking & projection ───────────────────────────────────────────────
  pick(ndcX: number, ndcY: number): TargetRef | null {
    this.raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), this.camera)
    const hit = this.raycaster.intersectObjects(this.hits.map(h => h.mesh), false)[0]
    if (!hit) return null
    return this.hits.find(h => h.mesh === hit.object)?.ref ?? null
  }
  groundPoint(ndcX: number, ndcY: number): { x: number; z: number } | null {
    this.raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), this.camera)
    const p = new THREE.Vector3()
    return this.raycaster.ray.intersectPlane(this.ground, p) ? { x: p.x, z: p.z } : null
  }
  /** World → CSS pixel position (for DOM bubbles). */
  project(x: number, y: number, z: number): { x: number; y: number; on: boolean } {
    const v = new THREE.Vector3(x, y, z).project(this.camera)
    const el = this.renderer.canvas
    return { x: (v.x * 0.5 + 0.5) * el.clientWidth, y: (-v.y * 0.5 + 0.5) * el.clientHeight, on: v.z < 1 }
  }
  stationTop(id: StationId): number { return this.stations.get(id)?.base ?? 1 }
  setRing(which: 'hover' | 'focus', ref: TargetRef | null, s: Shift): void {
    const ring = which === 'hover' ? this.hover : this.focusRing
    if (!ref) { ring.visible = false; return }
    const p = s.targetPos(ref)
    ring.visible = true
    ring.position.set(p.x, 0.03, p.z)
    ring.scale.setScalar((p.r + 0.35) / 0.8)
  }

  // ─── camera & render ────────────────────────────────────────────────────
  resize(): void {
    const el = this.renderer.canvas
    const aspect = (el.clientWidth || innerWidth) / (el.clientHeight || innerHeight)
    this.camera.aspect = aspect
    // Fit the full room width on narrow screens; landscape phones get a slightly closer camera.
    this.camera.fov = aspect < 1.5 ? 48 : 40
    this.camera.updateProjectionMatrix()
    this.fx.setScale((el.clientHeight || innerHeight) * 0.9)
  }
  render(dt: number): void {
    const el = this.renderer.canvas
    const aspect = (el.clientWidth || innerWidth) / (el.clientHeight || innerHeight)
    const fitW = 15.4
    const vfov = (this.camera.fov * Math.PI) / 180
    const hfov = 2 * Math.atan(Math.tan(vfov / 2) * aspect)
    const dist = Math.max(12.2, (fitW / 2) / Math.tan(hfov / 2) * 1.02)
    const tilt = 0.93
    const base = this.titleMode
      ? new THREE.Vector3(3 + Math.sin(this.time * 0.1) * 2.5, 5.5, 8.5)
      : new THREE.Vector3(0, Math.sin(tilt) * dist, Math.cos(tilt) * dist + 0.4)
    this.shake = Math.max(0, this.shake - dt * 1.6)
    const sh = this.shake * this.shake
    this.camera.position.set(base.x + rnd(sh * 0.6), base.y + rnd(sh * 0.4), base.z + rnd(sh * 0.4))
    this.camera.lookAt(this.titleMode ? 1.5 : 0, this.titleMode ? 0.8 : 0, this.titleMode ? -0.5 : 0.35)
    this.renderer.render(this.scene, this.camera)
  }
}

const rnd = (s: number) => (Math.random() - 0.5) * 2 * s
function lerpAngle(a: number, b: number, t: number): number {
  let d = b - a
  while (d > Math.PI) d -= Math.PI * 2
  while (d < -Math.PI) d += Math.PI * 2
  return a + d * t
}
