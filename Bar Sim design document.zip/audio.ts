/**
 * Web Audio mixer with music and SFX buses. Recorded cues (all generated originals) are decoded
 * once; `play()` triggers them with slight pitch variety so repeated chops and clinks stay lively.
 * Browsers only allow audio after a user gesture, so `unlock()` runs on the first input.
 */
import { assetUrl } from '../game/assetTable'

export type Sfx = 'ui' | 'throw' | 'land' | 'sizzle' | 'bell' | 'chop' | 'applause' | 'tip' | 'smash' | 'steam' | 'shake' | 'huff' | 'confirm' | 'back'

const FILES: Partial<Record<Sfx, string>> = {
  throw: 'audio/throw.mp3', land: 'audio/land.mp3', sizzle: 'audio/sizzle.mp3', bell: 'audio/bell.mp3',
  chop: 'audio/chop.mp3', applause: 'audio/applause.mp3', tip: 'audio/tip.mp3', smash: 'audio/smash.mp3',
  steam: 'audio/steam.mp3', shake: 'audio/shake.mp3', huff: 'audio/huff.mp3',
}
const GAIN: Partial<Record<Sfx, number>> = { applause: 0.55, sizzle: 0.5, steam: 0.45, chop: 0.7, land: 0.8, huff: 0.7, bell: 0.6, shake: 0.6 }
const MIN_GAP: Partial<Record<Sfx, number>> = { land: 0.06, chop: 0.07, bell: 0.15, applause: 0.8, sizzle: 0.3, steam: 0.4, tip: 0.08, huff: 0.25 }

export class Audio {
  readonly ctx: AudioContext
  private master: GainNode
  private music: GainNode
  private sfx: GainNode
  private filter: BiquadFilterNode
  private buffers = new Map<string, AudioBuffer>()
  private lastAt = new Map<Sfx, number>()
  private bgm?: AudioBufferSourceNode
  private loopSrc?: AudioBufferSourceNode
  private loopGain?: GainNode
  private wantMusic = false

  constructor() {
    this.ctx = new AudioContext()
    this.master = this.ctx.createGain()
    this.music = this.ctx.createGain()
    this.sfx = this.ctx.createGain()
    this.filter = this.ctx.createBiquadFilter()
    this.filter.type = 'lowpass'
    this.filter.frequency.value = 20000
    this.music.connect(this.filter).connect(this.master)
    this.sfx.connect(this.master)
    this.master.connect(this.ctx.destination)
  }
  unlock(): void {
    if (this.ctx.state === 'suspended') void this.ctx.resume().then(() => { if (this.wantMusic) this.startMusic() })
  }
  setVolumes(music: number, sfx: number, muted = false): void {
    const t = this.ctx.currentTime
    this.music.gain.setTargetAtTime(muted ? 0 : music * 0.5, t, 0.05)
    this.sfx.gain.setTargetAtTime(muted ? 0 : sfx * 0.85, t, 0.05)
  }
  /** Muffle the music (pause/menus) or open it up (service). */
  setMuffled(on: boolean): void {
    this.filter.frequency.setTargetAtTime(on ? 900 : 20000, this.ctx.currentTime, 0.25)
  }
  async load(url: string): Promise<AudioBuffer> {
    const cached = this.buffers.get(url)
    if (cached) return cached
    const data = await (await fetch(url)).arrayBuffer()
    const buffer = await this.ctx.decodeAudioData(data)
    this.buffers.set(url, buffer)
    return buffer
  }
  /** Decode every cue; failures fall back to synthesized tones. */
  async preload(): Promise<void> {
    await Promise.all(Object.values(FILES).map(f => this.load(assetUrl(f!)).catch(() => undefined)))
  }
  async loadMusic(): Promise<void> {
    await this.load(assetUrl('audio/bgm_service.mp3')).catch(() => undefined)
    if (this.wantMusic) this.startMusic()
  }
  play(name: Sfx, opts: { rate?: number; gain?: number } = {}): void {
    if (this.ctx.state !== 'running') return
    const now = this.ctx.currentTime
    const gap = MIN_GAP[name] ?? 0.03
    if (now - (this.lastAt.get(name) ?? -9) < gap) return
    this.lastAt.set(name, now)
    const file = FILES[name]
    const buf = file ? this.buffers.get(assetUrl(file)) : undefined
    if (buf) {
      const src = this.ctx.createBufferSource()
      src.buffer = buf
      src.playbackRate.value = opts.rate ?? 0.94 + Math.random() * 0.12
      const g = this.ctx.createGain()
      g.gain.value = (GAIN[name] ?? 1) * (opts.gain ?? 1)
      src.connect(g).connect(this.sfx)
      src.start()
      return
    }
    const tone = (freq: number, end: number, dur: number, type: OscillatorType, vol: number, delay = 0) => {
      const o = this.ctx.createOscillator()
      const g = this.ctx.createGain()
      o.type = type
      o.frequency.setValueAtTime(freq, now + delay)
      o.frequency.exponentialRampToValueAtTime(Math.max(end, 20), now + delay + dur)
      g.gain.setValueAtTime(0.0001, now + delay)
      g.gain.exponentialRampToValueAtTime(vol, now + delay + 0.01)
      g.gain.exponentialRampToValueAtTime(0.0001, now + delay + dur)
      o.connect(g).connect(this.sfx)
      o.start(now + delay)
      o.stop(now + delay + dur + 0.05)
    }
    switch (name) {
      case 'ui': tone(740, 780, 0.05, 'triangle', 0.12); break
      case 'confirm': tone(660, 990, 0.09, 'triangle', 0.2); tone(990, 1320, 0.12, 'sine', 0.14, 0.05); break
      case 'back': tone(520, 330, 0.1, 'triangle', 0.15); break
      default: tone(400, 300, 0.1, 'sine', 0.15)
    }
  }
  /** Continuous bar-service ambience whose level follows active drink-preparation stations. */
  setSizzle(level: number): void {
    const buf = this.buffers.get(assetUrl('audio/sizzle.mp3'))
    if (!buf || this.ctx.state !== 'running') return
    if (!this.loopSrc) {
      this.loopSrc = this.ctx.createBufferSource()
      this.loopSrc.buffer = buf
      this.loopSrc.loop = true
      this.loopGain = this.ctx.createGain()
      this.loopGain.gain.value = 0
      this.loopSrc.connect(this.loopGain).connect(this.sfx)
      this.loopSrc.start()
    }
    this.loopGain!.gain.setTargetAtTime(Math.min(0.3, level * 0.11), this.ctx.currentTime, 0.2)
  }
  startMusic(): void {
    this.wantMusic = true
    if (this.bgm) return
    const buf = this.buffers.get(assetUrl('audio/bgm_service.mp3'))
    if (!buf || this.ctx.state !== 'running') return
    this.bgm = this.ctx.createBufferSource()
    this.bgm.buffer = buf
    this.bgm.loop = true
    this.bgm.connect(this.music)
    this.bgm.start()
  }
  stopMusic(): void {
    this.wantMusic = false
    try { this.bgm?.stop() } catch { /* already stopped */ }
    this.bgm = undefined
  }
}
