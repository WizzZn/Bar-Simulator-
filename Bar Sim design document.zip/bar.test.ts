import { describe, expect, it } from 'vitest'
import { CHAPTERS, DISHES, DISH_ORDER, STATIONS } from '../src/game/data'
import { emptyCommands, Shift } from '../src/game/sim'

describe('Atlantis Bar content model', () => {
  it('contains only alcoholic drink recipes with exact preparation fields', () => {
    expect(DISH_ORDER).toHaveLength(10)
    for (const id of DISH_ORDER) {
      const recipe = DISHES[id]
      expect(recipe.drink).toBe(true)
      expect(recipe.alcohol).toBe(true)
      expect(recipe.ingredients.length).toBeGreaterThan(0)
      expect(recipe.glass.length).toBeGreaterThan(0)
      expect(recipe.method).toMatch(/build|stir|shake/)
      expect(recipe.requiredActivities).toContain('glassIce')
      expect(recipe.requiredActivities).toContain('pourMeasure')
      expect(recipe.requiredActivities).toContain('garnishServe')
      expect(recipe.steps[0]).toBe('prep')
      expect(recipe.steps.at(-1)).toBe('pass')
    }
  })

  it('keeps the four core cocktail activities represented by live stations', () => {
    expect(STATIONS.prep.activity).toBe('glassIce')
    expect(STATIONS.bar.activity).toBe('pourMeasure')
    expect(STATIONS.grill.activity).toBe('mix')
    expect(STATIONS.pass.activity).toBe('garnishServe')
    expect(CHAPTERS).toHaveLength(5)
    expect(new Set(CHAPTERS.map(c => c.mapStyle)).size).toBe(5)
  })

  it('creates multiple drink tickets and consumes stock at preparation start', () => {
    const shift = new Shift(4, 'campaign', { upgrades: {}, staff: [], assist: false }, { seed: 4 })
    const party = shift.spawnParty('couple', ['monsoonMule', 'spiceOldFashioned'], 2)
    shift.interact({ kind: 'door' })
    for (let i = 0; i < 180; i++) shift.step(1 / 30, emptyCommands())
    shift.interact({ kind: 'table', id: party.table })
    expect(shift.tickets).toHaveLength(2)
    const before = shift.stock.vodka
    shift.interact({ kind: 'station', id: 'prep' })
    expect(shift.stock.vodka).toBeLessThan(before)
  })

  it('allows a bouncer to resolve an intoxicated rowdy guest incident', () => {
    const shift = new Shift(4, 'campaign', { upgrades: {}, staff: [{ role: 'bouncer', job: 'bouncer', name: 'Balan' }], assist: false }, { seed: 9 })
    const guest = shift.spawnParty('rowdy', ['beer'], 1)
    guest.intoxication = 0.8
    guest.trouble = 1
    guest.fighting = true
    for (let i = 0; i < 240; i++) shift.step(1 / 30, emptyCommands())
    expect(guest.fighting).toBe(false)
    expect(shift.events.some(e => e.t === 'msg' && e.text.toLowerCase().includes('broke up'))).toBe(true)
  })
})
