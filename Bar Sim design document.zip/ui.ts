import type { Audio } from '../engine/audio'
import type { Input, InputMethod } from '../engine/input'
import type { SaveData, SaveStore } from '../engine/save'
import { assetUrl } from '../game/assetTable'
import {
  CHALLENGES, CHAPTERS, CREDITS, DISHES, DISH_ORDER, GUESTS, SPEAKERS, STAFF, STATIONS, STORY, UNLOCK_STARS, UPGRADES,
  gradeFor, type Dir, type DishId, type Line, type StaffRole,
} from '../game/data'
import type { Game } from '../game/game'
import { READY, type Shift } from '../game/sim'
import type { View } from '../game/view'

export type Screen = 'boot' | 'title' | 'chapters' | 'office' | 'story' | 'briefing' | 'hud' | 'hire' | 'pause' | 'settings' | 'recipes' | 'results' | 'credits' | 'challenges'
export type UiActions = {
  startShift(chapter: number, mode: 'campaign' | 'endless' | 'throw'): void
  resume(): void
  restart(): void
  quit(): void
  settings(patch: Partial<SaveData>): void
  pause(): void
  crewChanged(): void
}
const ARROW: Record<Dir, string> = { up: '▲', down: '▼', left: '◀', right: '▶' }
const esc = (s: string) => s.replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!)
const money = (n: number) => '₹' + Math.round(n).toLocaleString('en-IN')
const starStr = (n: number, of = 3) => '★'.repeat(n) + '☆'.repeat(Math.max(0, of - n))

const TUTORIAL: Record<number, Record<'keyboard' | 'gamepad' | 'touch', string>> = {
  0: { keyboard: 'Move Mei with <kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd>, or click anything to run there.', gamepad: 'Move Mei with the <kbd class="pad">L</kbd> stick.', touch: 'Drag the left stick to move, or tap anything to run there.' },
  1: { keyboard: 'A guest is at the door. Click the door, press <kbd>Q</kbd>, or walk over and press <kbd>E</kbd> to seat them.', gamepad: 'A guest is at the door. Press <kbd class="pad y">Y</kbd> to run over and seat them.', touch: 'A guest is at the door. Tap the door (or DOOR) to seat them.' },
  2: { keyboard: 'They raised a hand. Go to their table and press <kbd>E</kbd> to take the order.', gamepad: 'Walk to their table and press <kbd class="pad a">A</kbd> to take the order.', touch: 'Tap their table to take the order.' },
  3: { keyboard: 'The ticket shows the route: <b>Prep → Tawa → Pass</b>. Go to the Prep Board (<kbd>1</kbd>) and tap <kbd>E</kbd> to chop.', gamepad: 'Route: <b>Prep → Tawa → Pass</b>. At the Prep Board, tap <kbd class="pad a">A</kbd> to chop. <kbd class="pad">LB</kbd>/<kbd class="pad">RB</kbd> run between stations.', touch: 'Route: <b>Prep → Tawa → Pass</b>. Tap the Prep Board, then tap ACT to chop.' },
  4: { keyboard: 'Take it to the Tawa (<kbd>5</kbd>). Press <kbd>E</kbd> to cook, then <kbd>E</kbd> again when the bar hits <b class="gold">GOLD</b>.', gamepad: 'Cook it on the Tawa. Press <kbd class="pad a">A</kbd> again when the bar hits <b class="gold">GOLD</b>.', touch: 'Cook it on the Tawa. Tap again when the bar hits <b class="gold">GOLD</b>.' },
  5: { keyboard: 'Finish it at Garnish + Serve (<kbd>8</kbd>): press the arrows shown, in order.', gamepad: 'At the Pass, press the shown directions on the <kbd class="pad">D-pad</kbd>.', touch: 'At the Pass, tap the arrows in order.' },
  6: { keyboard: 'Hold <kbd>F</kbd> or <b>right mouse</b> to aim, release in the <b class="gold">GOLD</b> for a stylish throw. Or walk it over and press <kbd>E</kbd>.', gamepad: 'Hold <kbd class="pad x">X</kbd> to aim (<kbd class="pad">R</kbd> stick picks a table), release in the <b class="gold">GOLD</b>.', touch: 'Hold SERVE and release in the <b class="gold">GOLD</b>. Or tap the table to walk it over.' },
  7: { keyboard: 'That is service! Chain fast, perfect finishes for tip multipliers. <kbd>R</kbd> opens recipe cards.', gamepad: 'That is service! Chain perfect finishes for tip multipliers. <kbd class="pad">View</kbd> opens recipes.', touch: 'That is service! Chain perfect finishes for tip multipliers.' },
}

export class Ui {
  screen: Screen = 'boot'
  private root: HTMLElement
  private layer: Record<string, HTMLElement> = {}
  private back: Screen[] = []
  private dialog: { lines: Line[]; i: number; done: () => void } | null = null
  private pendingChapter = 0
  private pendingMode: 'campaign' | 'endless' | 'throw' = 'campaign'
  private bubbles = new Map<string, HTMLElement>()
  private tickets = new Map<string, HTMLElement>()
  private bubbleSeen = new Set<string>()
  private cache = new Map<string, string>()
  private lastMethod: InputMethod | '' = ''
  private resultsShift?: Shift
  private navCool = 0
  private touchStick?: { id: number; ox: number; oy: number }

  constructor(private readonly save: SaveStore, private readonly audio: Audio, private readonly input: Input, private readonly actions: UiActions) {
    this.root = document.getElementById('ui')!
    this.root.innerHTML = `
      <div class="layer boot" data-l="boot"><div class="boot-card"><img class="boot-icon" src="./favicon.png" alt=""><div class="logo small">Atlantis <span>Bar</span></div><div class="bar"><i></i></div><p class="boot-msg">Opening Atlantis Bar…</p></div></div>
      <div class="layer hud" data-l="hud"></div>
      <div class="bubbles" data-l="bubbles"></div>
      <div class="pops" data-l="pops"></div>
      <div class="toasts" data-l="toasts"></div>
      <div class="touch" data-l="touch">
        <div class="stick"><i></i></div>
        <button class="tbtn act" data-touch="interact">ACT</button>
        <button class="tbtn throw" data-touch="throw">SERVE</button>
        <button class="tbtn door" data-touch="door">DOOR</button>
        <button class="tbtn bin" data-touch="bin">BIN</button>
      </div>
      <div class="layer menu" data-l="menu"></div>`
    this.root.querySelectorAll<HTMLElement>('[data-l]').forEach(el => (this.layer[el.dataset.l!] = el))
    this.root.addEventListener('click', e => this.onClick(e))
    this.root.addEventListener('input', e => this.onInput(e))
    window.addEventListener('keydown', e => this.onKey(e))
    this.setupTouch()
    this.applyAccess()
  }

  // ─── screens ────────────────────────────────────────────────────────────
  setBoot(p: number, msg?: string): void {
    const bar = this.layer.boot.querySelector<HTMLElement>('.bar i')!
    bar.style.width = `${Math.round(p * 100)}%`
    if (msg) this.layer.boot.querySelector('.boot-msg')!.textContent = msg
  }
  show(s: Screen, push = false): void {
    if (push) this.back.push(this.screen)
    else this.back = []
    this.screen = s
    this.layer.boot.classList.toggle('on', s === 'boot')
    const liveHud = s === 'hud'
    const showHud = liveHud || s === 'hire'
    this.layer.hud.classList.toggle('on', showHud || s === 'pause' || s === 'recipes' && this.back.includes('pause') || s === 'settings' && this.back.includes('pause'))
    this.layer.bubbles.classList.toggle('on', liveHud)
    this.layer.touch.classList.toggle('on', liveHud)
    const showMenu = !liveHud && s !== 'boot'
    this.layer.menu.classList.toggle('on', showMenu)
    this.layer.menu.className = `layer menu ${showMenu ? 'on' : ''} m-${s}`
    if (showMenu) this.layer.menu.innerHTML = this.render(s)
    if (liveHud) this.buildHud()
    this.audio.setMuffled(s !== 'hud' && s !== 'title' && s !== 'results')
    requestAnimationFrame(() => this.focusFirst())
  }
  private goBack(): void {
    this.audio.play('back')
    if (this.screen === 'story') { this.skipStory(); return }
    if (this.screen === 'hire') { this.back = []; this.actions.resume(); this.show('hud'); return }
    const prev = this.back.pop()
    if (prev === 'pause') { this.show('pause'); this.back = []; return }
    if (prev) { this.screen = prev; this.show(prev, false); return }
    if (this.screen === 'pause') { this.actions.resume(); return }
    if (this.screen === 'chapters' || this.screen === 'challenges' || this.screen === 'credits' || this.screen === 'settings' || this.screen === 'recipes') this.show('title')
    else if (this.screen === 'office' || this.screen === 'briefing') this.show('chapters')
  }
  private focusFirst(): void {
    const el = this.layer.menu.querySelector<HTMLElement>('[autofocus]') ?? this.layer.menu.querySelector<HTMLElement>('button:not([disabled]), input')
    el?.focus({ preventScroll: true })
  }

  private render(s: Screen): string {
    const d = this.save.data
    switch (s) {
      case 'title': return `
        <div class="title-bg title-art"></div>
        <div class="title-wrap"><div class="logo">Atlantis <span>Bar</span></div><p class="tag">A Kerala-inspired cocktail-service arcade game about clean pours, quick hands and a welcoming floor.</p></div>
        <div class="title-hotspots">
          <button class="title-hotspot" data-act="campaign" aria-label="Start Campaign" autofocus>Start Campaign</button>
          <button class="title-hotspot" data-act="challenges" aria-label="High-Score Challenges">High-Score Challenges</button>
          <button class="title-hotspot" data-act="recipes" aria-label="Cocktail Menu">Cocktail Menu</button>
          <button class="title-hotspot" data-act="settings" aria-label="Settings">Settings</button>
          <button class="title-hotspot" data-act="credits" aria-label="Credits">Credits</button>
        </div>
        <div class="title-hint">${this.glyphs('menu')}</div>
        <div class="title-mobile"><h1>Atlantis Bar</h1><p>Kerala Cocktail Service Edition</p><div class="col"><button class="btn primary" data-act="campaign">Start Campaign</button><button class="btn" data-act="challenges">High-Score Challenges</button><button class="btn" data-act="recipes">Cocktail Menu</button><button class="btn" data-act="settings">Settings</button><button class="btn ghost" data-act="credits">Credits</button></div></div>`
      case 'chapters': return this.chaptersHtml()
      case 'office': return this.officeHtml()
      case 'challenges': return `
        <div class="panel wide"><h2>High-Score Challenges</h2><p class="sub">Optional nights for bragging rights. Upgrades and staff apply.</p>
        <div class="cards">${CHALLENGES.map(c => {
          const locked = this.save.data.stars[0] === 0
          return `<div class="card chal ${locked ? 'locked' : ''}"><h3>${c.name}</h3><p>${c.blurb}</p><div class="meta">Room: ${CHAPTERS[c.chapter].name}<br>Best: <b>${money(d.challengeBest[c.id] ?? 0)}</b></div>
            <button class="btn primary" data-chal="${c.id}" ${locked ? 'disabled' : ''}>${locked ? 'Clear Chapter 1 first' : 'Play'}</button></div>`
        }).join('')}</div>
        <div class="row"><button class="btn ghost" data-act="back">Back</button></div></div>`
      case 'story': return this.storyHtml()
      case 'briefing': return this.briefingHtml()
      case 'hire': return this.hireHtml()
      case 'pause': return `
        <div class="panel narrow"><h2>Paused</h2><p class="sub">${esc(CHAPTERS[this.pendingChapter].name)}</p>
        <div class="col"><button class="btn primary" data-act="resume" autofocus>Resume</button>
        <button class="btn" data-act="recipes">Recipe Cards</button><button class="btn" data-act="settings">Settings</button>
        <button class="btn" data-act="restart">Restart Shift</button><button class="btn ghost" data-act="quit">Quit to Menu</button></div>
        <div class="controls-ref">${this.controlsRef()}</div></div>`
      case 'settings': return this.settingsHtml()
      case 'recipes': return this.recipesHtml()
      case 'credits': return `
        <div class="panel"><h2>Credits</h2><div class="credits">${CREDITS.map(c => `<div><span>${esc(c.role)}</span><b>${esc(c.names)}</b></div>`).join('')}</div>
        <p class="sub">The project reuses supplied artwork and models; the background soundtrack is original for this edition.</p>
        <div class="row"><button class="btn ghost" data-act="back" autofocus>Back</button></div></div>`
      case 'results': return this.resultsHtml()
      default: return ''
    }
  }

  private chaptersHtml(): string {
    const d = this.save.data
    const total = this.save.totalStars
    return `<div class="panel wide"><div class="head-row"><h2>The Road to Marine Drive</h2><div class="wallet">${starStr(Math.min(15, total), 15)} <b>${money(d.wallet)}</b></div></div>
      <div class="chapters">${CHAPTERS.map((c, i) => {
        const locked = total < UNLOCK_STARS[i]
        return `<div class="chapter ${locked ? 'locked' : ''}" style="--wall:${c.wall};--acc:${c.light.accent}">
          <div class="num">${i + 1}</div><div class="info"><img class="map-preview" src="${assetUrl(c.mapImage)}" alt="${esc(c.name)} map reference"><h3>${esc(c.name)}</h3><div class="place">${esc(c.place)}</div><p>${esc(c.theme)}</p>
          <div class="dishes">${c.dishes.map(id => `<img src="${assetUrl(`art/dish_${id}.jpg`)}" alt="${esc(DISHES[id].name)}" title="${esc(DISHES[id].name)}">`).join('')}</div></div>
          <div class="side"><div class="stars">${starStr(d.stars[i])}</div><div class="best">Best ${money(d.best[i])}</div><div class="target">Target ${money(c.target)}</div>
          <button class="btn ${locked ? '' : 'primary'}" data-chapter="${i}" ${locked ? 'disabled' : ''}>${locked ? `Need ${UNLOCK_STARS[i]}★` : 'Play'}</button></div></div>`
      }).join('')}</div>
      <div class="row"><button class="btn ghost" data-act="back">Back</button><button class="btn" data-act="office">Bar Office: Crew &amp; Upgrades</button></div></div>`
  }

  private officeHtml(): string {
    const d = this.save.data
    return `<div class="panel wide"><div class="head-row"><h2>Bar Crew &amp; Upgrades</h2><div class="wallet"><b>${money(d.wallet)}</b> to spend</div></div>
      <p class="sub">Hire your bar crew between shifts. Staff work on their own; Mei stays the star.</p>
      <div class="office">
        <div><h3>Staff</h3>${STAFF.map(s => {
          const job = d.staff[s.role]
          const canBuy = d.wallet >= s.cost
          return `<div class="item staff" style="--tint:${s.tint}"><div class="face">${s.name[0]}</div><div class="txt"><b>${s.name}</b> <span class="role">${s.title}</span>
            ${job ? `<div class="jobs">${s.jobs.map(j => `<button class="chip ${job === j.id ? 'on' : ''}" data-job="${s.role}:${j.id}" title="${esc(j.blurb)}">${j.name}</button>`).join('')}</div><small>${esc(s.jobs.find(j => j.id === job)!.blurb)}</small>`
              : `<small>${esc(s.jobs.map(j => `${j.name}: ${j.blurb}`).join(' / '))}</small>`}</div>
            ${job ? '<span class="owned">Hired</span>' : `<button class="btn small ${canBuy ? 'primary' : ''}" data-hire="${s.role}" ${canBuy ? '' : 'disabled'}>Hire ${money(s.cost)}</button>`}</div>`
        }).join('')}</div>
        <div><h3>Upgrades</h3>${UPGRADES.map(u => {
          const own = d.upgrades[u.id]
          const can = d.wallet >= u.cost
          return `<div class="item"><div class="txt"><b>${u.name}</b><small>${esc(u.blurb)}</small></div>${own ? '<span class="owned">Owned</span>' : `<button class="btn small ${can ? 'primary' : ''}" data-buy="${u.id}" ${can ? '' : 'disabled'}>${money(u.cost)}</button>`}</div>`
        }).join('')}</div>
      </div><div class="row"><button class="btn ghost" data-act="back" autofocus>Back</button></div></div>`
  }

  private hireHtml(): string {
    const d = this.save.data
    return `<div class="hire-shade"><div class="panel hire-panel"><div class="head-row"><h2>Hire the Crew</h2><div class="wallet"><b>${money(d.wallet)}</b> available</div></div>
      <p class="sub">Bring in help during the shift. A bouncer calms rowdy guests before the whole bar is disturbed.</p>
      <div class="hire-list">${STAFF.map(s => {
        const job = d.staff[s.role]
        const can = d.wallet >= s.cost
        return `<div class="hire-card" style="--tint:${s.tint}"><div class="face">${s.name[0]}</div><div class="txt"><b>${esc(s.name)} <span class="role">${esc(s.title)}</span></b><small>${esc(s.jobs[0].blurb)}</small></div>${job ? '<span class="owned">On shift</span>' : `<button class="btn small ${can ? 'primary' : ''}" data-hire="${s.role}" ${can ? '' : 'disabled'}>Hire ${money(s.cost)}</button>`}</div>`
      }).join('')}</div>
      <div class="row"><button class="btn primary" data-act="hire-close" autofocus>Back to Shift</button></div></div></div>`
  }

  private storyHtml(): string {
    const dl = this.dialog
    if (!dl) return ''
    const line = dl.lines[dl.i]
    const sp = SPEAKERS[line.who]
    const portrait = line.who === 'note' ? '' : `<img class="portrait ${line.who}" src="${assetUrl(`art/portrait_${line.who}.jpg`)}" alt="${sp.name}">`
    return `<div class="story ${line.who}">
      ${portrait}
      <div class="dialog" style="--sp:${sp.color}"><div class="who">${esc(sp.name)}</div><p class="${line.who === 'note' ? 'note' : ''}">${esc(line.text)}</p>
      <div class="row end"><span class="pager">${dl.i + 1}/${dl.lines.length}</span><button class="btn ghost small" data-act="skip">Skip</button><button class="btn primary small" data-act="next" autofocus>${dl.i + 1 < dl.lines.length ? 'Next' : 'Continue'}</button></div></div></div>`
  }

  private briefingHtml(): string {
    const ch = CHAPTERS[this.pendingChapter]
    const mode = this.pendingMode
    const chal = CHALLENGES.find(c => c.mode === mode)
    const prev = this.pendingChapter > 0 ? new Set(CHAPTERS[this.pendingChapter - 1].dishes) : new Set<DishId>()
    const d = this.save.data
    const staff = STAFF.filter(s => d.staff[s.role]).map(s => `${s.name} (${s.jobs.find(j => j.id === d.staff[s.role])!.name})`)
    return `<div class="panel wide"><div class="head-row"><h2>${chal ? esc(chal.name) : `Chapter ${ch.id + 1}: ${esc(ch.name)}`}</h2><div class="target">${mode === 'campaign' ? `Target <b>${money(ch.target)}</b>` : mode === 'endless' ? '3 walkouts ends the night' : '120 seconds · accuracy only'}</div></div>
      <p class="sub">${esc(chal?.blurb ?? ch.theme)}</p>
      <div class="brief-grid">${ch.dishes.map(id => this.recipeCard(id, mode === 'campaign' && !prev.has(id) && this.pendingChapter > 0)).join('')}</div>
      <div class="brief-foot"><div>Guests tonight: ${ch.guests.map(g => `<span class="gtag" style="--c:${GUESTS[g].color}">${GUESTS[g].icon} ${GUESTS[g].name}</span>`).join(' ')}</div>
      <div>On shift: ${staff.length ? esc(staff.join(', ')) : 'just Mei. Hire help in the Bar Office.'}</div></div>
      <div class="row"><button class="btn ghost" data-act="back">Back</button><button class="btn primary" data-act="begin" autofocus>Open the Doors</button></div></div>`
  }

  recipeCard(id: DishId, isNew = false): string {
    const d = DISHES[id]
    return `<div class="recipe ${isNew ? 'new' : ''}" style="--dc:${d.color}">
      <div class="pic" style="background-image:url(${assetUrl(`art/dish_${id}.jpg`)})">${isNew ? '<span class="badge">NEW</span>' : ''}</div>
      <div class="rbody"><h4>${esc(d.name)}</h4>
      <div class="route">${d.steps.map(s => `<span class="st" style="--c:${STATIONS[s].color}">${STATIONS[s].key} ${STATIONS[s].name.replace(/^(The |Toddy-Free |Charcoal |Kadai |Copper |Tawa |Brass )/, '')}</span>`).join('<i>→</i>')}</div>
      ${d.plating.length ? `<div class="plating">Garnish: ${d.plating.map(p => `<kbd>${ARROW[p]}</kbd>`).join('')}</div>` : '<div class="plating">No garnish sequence: straight to the guest</div>'}
      <p>${esc(d.card)}</p><div class="price">${money(d.price)}</div></div></div>`
  }

  private recipesHtml(): string {
    const stationRows = Object.values(STATIONS).map(s => `<div class="strow"><span class="st" style="--c:${s.color}">${s.key}</span><b>${s.name}</b><small>${esc(s.blurb)}${s.kind === 'timed' ? ` (${s.cook}s)` : ''}</small></div>`).join('')
    return `<div class="panel wide"><h2>Cocktail Menu</h2>
      <p class="sub">Every order is a drink. Prepare glass and ice, pour and measure, mix to the timing window, then garnish and serve.</p>
      <div class="brief-grid">${DISH_ORDER.map(id => this.recipeCard(id)).join('')}</div>
      <h3>Stations</h3><div class="stations-ref">${stationRows}</div>
      <div class="row"><button class="btn ghost" data-act="back" autofocus>Back</button></div></div>`
  }

  private settingsHtml(): string {
    const d = this.save.data
    const tog = (k: keyof SaveData, label: string, help: string) => `<label class="toggle-row"><span><b>${label}</b><small>${help}</small></span><button class="toggle ${d[k] ? 'on' : ''}" data-toggle="${k}" aria-pressed="${!!d[k]}"><i></i></button></label>`
    const slider = (k: 'musicVolume' | 'sfxVolume', label: string) => `<label class="slider-row"><b>${label}</b><input type="range" min="0" max="1" step="0.05" value="${d[k]}" data-range="${k}"><span>${Math.round(d[k] * 100)}%</span></label>`
    return `<div class="panel"><h2>Settings</h2>
      <div class="settings">
        <h3>Audio</h3>${slider('musicVolume', 'Music')}${slider('sfxVolume', 'Sound effects')}${tog('muted', 'Mute all', 'Silence music and effects')}
        <h3>Video</h3><div class="seg-row"><b>Quality</b><div class="seg">${(['low', 'medium', 'high'] as const).map(q => `<button class="${d.quality === q ? 'on' : ''}" data-quality="${q}">${q[0].toUpperCase() + q.slice(1)}</button>`).join('')}</div></div>
        <h3>Accessibility</h3>
        ${tog('assist', 'Relaxed service', 'Wider timing windows, slower patience; at the pass, Interact performs the next step')}
        ${tog('toggleThrow', 'Toggle throw', 'Press throw once to aim, again to release (no holding)')}
        ${tog('noShake', 'No screen shake', 'Keep the camera still')}
        ${tog('reducedMotion', 'Reduced motion', 'Fewer particles and calmer animation')}
        ${tog('bigText', 'Larger text', 'Bigger HUD, tickets and prompts')}
        ${tog('highContrast', 'High contrast', 'Solid backgrounds behind all labels')}
        <h3>Progress</h3><button class="btn danger small" data-act="reset">Reset campaign progress</button>
      </div>
      <div class="row"><button class="btn ghost" data-act="back" autofocus>Back</button></div></div>`
  }

  private resultsHtml(): string {
    const s = this.resultsShift
    if (!s) return ''
    const st = s.stats
    const mode = s.mode
    const g = gradeFor(st.revenue, s.ch.target, s.satisfaction)
    const r = this.lastReward
    const row = (k: string, v: string, cls = '') => `<div class="srow ${cls}"><span>${k}</span><b>${v}</b></div>`
    return `<div class="panel results"><div class="grade g-${g.grade}">${mode === 'campaign' ? g.grade : '★'}</div>
      <h2>${mode === 'campaign' ? (g.stars ? 'Service complete!' : 'Rough night…') : 'Challenge over!'}</h2>
      ${mode === 'campaign' ? `<div class="stars big">${starStr(g.stars)}</div>` : ''}
      <div class="stats">
        ${row('Revenue', `${money(st.revenue)}${mode === 'campaign' ? ` / ${money(s.ch.target)}` : ''}`, 'hl')}
        ${row('Tips earned', money(st.tips))}
        ${row('Guest satisfaction', `${Math.round(s.satisfaction * 100)}%`)}
        ${row('Parties served', `${st.served}`)}${row('Walkouts', `${st.walkouts}`, st.walkouts ? 'bad' : '')}
        ${row('Perfect cooks', `${st.perfectCooks}`)}${row('Stylish throws', `${st.stylish} / ${st.throws}`)}
        ${row('Incorrect deliveries', `${st.smashes}`, st.smashes ? 'bad' : '')}${row('Over-poured drinks', `${st.burns}`, st.burns ? 'bad' : '')}
        ${row('Best combo', `${st.maxCombo}`)}${row('Clutch saves · Doubles', `${st.saves} · ${st.doubles}`)}
        ${row('Reputation', `${st.rep >= 0 ? '+' : ''}${st.rep.toFixed(1)}`)}
      </div>
      ${r ? `<div class="reward">+${money(r.wallet)} to the tip jar${r.newBest ? ' · <b>New best!</b>' : ''}${r.unlocked ? ` · <b>Unlocked: ${esc(r.unlocked)}</b>` : ''}</div>` : ''}
      <p class="sub tipline">${esc(this.adviceFor(s))}</p>
      <div class="row"><button class="btn" data-act="restart">Retry</button><button class="btn primary" data-act="continue" autofocus>Continue</button></div></div>`
  }

  private adviceFor(s: Shift): string {
    const st = s.stats
    if (st.walkouts >= 3) return 'Tip: seat guests and take orders right away; both refill patience. Hire Ravi as Host in the Bar Office.'
    if (st.burns >= 3) return 'Tip: burns cost you. Start slow stations (steamer, grill) first, then work quick ones while they cook.'
    if (st.smashes >= 2) return 'Tip: release the throw while the needle is inside the green. Walking a finish over is always safe.'
    if (st.stylish < 3) return 'Tip: clean deliveries (needle in the gold) add big tips and keep the combo alive.'
    if (s.satisfaction < 0.75) return 'Tip: precise pours and clean garnish work raise satisfaction. Reviewers notice every detail.'
    if (s.mode === 'campaign' && gradeFor(st.revenue, s.ch.target, s.satisfaction).grade === 'S') return 'A flawless night. Kochi will be talking about this table for weeks.'
    return 'Lovely service. Try for an S: beat the target by 35% with 85% satisfaction.'
  }
  lastReward: { wallet: number; newBest: boolean; unlocked: string } | null = null

  // ─── story/briefing flow ────────────────────────────────────────────────
  playStory(lines: Line[], done: () => void): void {
    this.dialog = { lines, i: 0, done }
    this.show('story')
  }
  private nextLine(): void {
    if (!this.dialog) return
    this.audio.play('ui')
    this.dialog.i++
    if (this.dialog.i >= this.dialog.lines.length) { const d = this.dialog.done; this.dialog = null; d(); return }
    this.layer.menu.innerHTML = this.storyHtml()
    this.focusFirst()
  }
  private skipStory(): void {
    if (!this.dialog) return
    const d = this.dialog.done
    this.dialog = null
    d()
  }
  openChapter(i: number, mode: 'campaign' | 'endless' | 'throw' = 'campaign'): void {
    this.pendingChapter = i
    this.pendingMode = mode
    const brief = () => this.show('briefing')
    if (mode === 'campaign' && !this.save.data.seenIntro.includes(i)) {
      this.save.update({ seenIntro: [...this.save.data.seenIntro, i] })
      this.playStory(STORY[i].intro, brief)
    } else brief()
  }
  get chapterPending(): number { return this.pendingChapter }

  showResults(s: Shift, reward: { wallet: number; newBest: boolean; unlocked: string }): void {
    this.resultsShift = s
    this.lastReward = reward
    this.show('results')
    this.audio.play(reward.wallet > 0 ? 'applause' : 'huff')
  }

  // ─── events ─────────────────────────────────────────────────────────────
  private onClick(e: Event): void {
    const t = (e.target as HTMLElement).closest<HTMLElement>('button, [data-dir]')
    if (!t) return
    const ds = t.dataset
    const d = this.save.data
    if (ds.dir) { this.input.press(ds.dir as Dir); return }
    if (ds.touch) return
    this.audio.unlock()
    this.audio.play('confirm')
    if (ds.act) {
      switch (ds.act) {
        case 'hire-panel': this.actions.pause(); this.show('hire', true); break
        case 'hire-close': this.back = []; this.actions.resume(); this.show('hud'); break
        case 'campaign': {
          if (!d.tutorialDone && !d.shifts) { this.openChapter(0); break }
          this.show('chapters'); break
        }
        case 'challenges': this.show('challenges'); break
        case 'recipes': this.show('recipes', true); break
        case 'settings': this.show('settings', true); break
        case 'credits': this.show('credits'); break
        case 'office': this.show('office', true); break
        case 'back': this.goBack(); break
        case 'next': this.nextLine(); break
        case 'skip': this.skipStory(); break
        case 'begin': this.actions.startShift(this.pendingChapter, this.pendingMode); break
        case 'resume': this.actions.resume(); break
        case 'restart': this.actions.restart(); break
        case 'quit': this.actions.quit(); break
        case 'pause': this.actions.pause(); break
        case 'continue': this.afterResults(); break
        case 'reset': if (confirm('Reset all campaign progress, tips, staff and upgrades?')) { this.save.reset(); this.show('settings') } break
      }
      return
    }
    if (ds.chapter) { this.openChapter(Number(ds.chapter)); return }
    if (ds.chal) { const c = CHALLENGES.find(x => x.id === ds.chal)!; this.openChapter(c.chapter, c.mode); return }
    if (ds.buy) {
      const u = UPGRADES.find(x => x.id === ds.buy)!
      if (d.wallet >= u.cost) { this.save.update({ wallet: d.wallet - u.cost, upgrades: { ...d.upgrades, [u.id]: true } }); this.audio.play('tip') }
      this.rerender(); return
    }
    if (ds.hire) {
      const s = STAFF.find(x => x.role === ds.hire)!
      if (d.wallet >= s.cost && !d.staff[s.role]) { this.save.update({ wallet: d.wallet - s.cost, staff: { ...d.staff, [s.role]: s.jobs[0].id } }); this.actions.crewChanged(); this.audio.play('tip') }
      this.rerender(); return
    }
    if (ds.job) {
      const [role, job] = ds.job.split(':')
      this.save.update({ staff: { ...d.staff, [role as StaffRole]: job } as SaveData['staff'] })
      this.rerender(); return
    }
    if (ds.toggle) {
      const k = ds.toggle as keyof SaveData
      this.actions.settings({ [k]: !d[k] } as Partial<SaveData>)
      this.applyAccess()
      this.rerender(); return
    }
    if (ds.quality) { this.actions.settings({ quality: ds.quality as SaveData['quality'] }); this.rerender() }
  }
  private rerender(): void {
    const focused = document.activeElement as HTMLElement | null
    const sel = focused ? this.selectorFor(focused) : ''
    this.layer.menu.innerHTML = this.render(this.screen)
    const again = sel ? this.layer.menu.querySelector<HTMLElement>(sel) : null
    if (again && !(again as HTMLButtonElement).disabled) again.focus({ preventScroll: true })
    else this.focusFirst()
  }
  private selectorFor(el: HTMLElement): string {
    for (const k of ['act', 'buy', 'hire', 'job', 'toggle', 'quality', 'chapter', 'chal', 'range']) {
      const v = el.dataset[k]
      if (v) return `[data-${k}="${v}"]`
    }
    return ''
  }
  private onInput(e: Event): void {
    const t = e.target as HTMLInputElement
    if (t.dataset.range) {
      this.actions.settings({ [t.dataset.range]: Number(t.value) } as Partial<SaveData>)
      const span = t.nextElementSibling
      if (span) span.textContent = `${Math.round(Number(t.value) * 100)}%`
    }
  }
  private afterResults(): void {
    const s = this.resultsShift
    const i = s?.ch.id ?? 0
    const ok = s && s.mode === 'campaign' && gradeFor(s.stats.revenue, s.ch.target, s.satisfaction).stars > 0
    if (ok && !this.save.data.seenOutro.includes(i)) {
      this.save.update({ seenOutro: [...this.save.data.seenOutro, i] })
      this.playStory(STORY[i].outro, () => { this.actions.quit(); this.show(i === CHAPTERS.length - 1 ? 'credits' : 'chapters') })
      return
    }
    this.actions.quit()
    this.show(s?.mode === 'campaign' ? 'chapters' : 'challenges')
  }
  private onKey(e: KeyboardEvent): void {
    if (this.screen === 'hud' || this.screen === 'boot') return
    const typing = (e.target as HTMLElement)?.matches?.('input[type=text]')
    if (typing) return
    if (e.code === 'Escape' || e.code === 'Backspace') {
      if (this.screen === 'title') return
      if (this.screen === 'pause') { this.actions.resume(); return }
      e.preventDefault()
      this.goBack()
      return
    }
    if (this.screen === 'story' && (e.code === 'Space' || e.code === 'Enter') && !(e.target as HTMLElement).matches('button')) { e.preventDefault(); this.nextLine(); return }
    const nav = { ArrowUp: -1, ArrowLeft: -1, KeyW: -1, KeyA: -1, ArrowDown: 1, ArrowRight: 1, KeyS: 1, KeyD: 1 }[e.code]
    if (nav) {
      const active = document.activeElement as HTMLElement | null
      if (active?.matches('input[type=range]') && (e.code === 'ArrowLeft' || e.code === 'ArrowRight')) return
      e.preventDefault()
      this.moveFocus(nav)
    }
  }
  private moveFocus(dir: number): void {
    const items = [...this.layer.menu.querySelectorAll<HTMLElement>('button:not([disabled]), input')]
    if (!items.length) return
    const i = items.indexOf(document.activeElement as HTMLElement)
    const next = items[(i + dir + items.length) % items.length]
    next.focus()
    next.scrollIntoView({ block: 'nearest' })
    this.audio.play('ui')
  }

  /** Gamepad menu navigation (keyboard uses DOM events). */
  frame(dt: number): void {
    this.navCool -= dt
    const m = this.input.method
    if (m !== this.lastMethod) {
      this.lastMethod = m
      document.body.dataset.input = m
      if (this.screen === 'hud') this.buildHud()
      if (this.screen === 'title') this.layer.menu.querySelector('.title-hint')!.innerHTML = this.glyphs('menu')
    }
    if (this.screen === 'hud' || this.screen === 'boot' || m !== 'gamepad') return
    const inp = this.input
    if (inp.pressed('up') || inp.pressed('left')) this.moveFocus(-1)
    if (inp.pressed('down') || inp.pressed('right')) this.moveFocus(1)
    if (inp.pressed('confirm')) {
      const el = document.activeElement as HTMLElement | null
      if (this.screen === 'story' && !el?.matches('button')) this.nextLine()
      else if (el?.matches('input[type=range]')) { /* adjust with bumpers */ }
      else el?.click()
    }
    if (inp.pressed('back') && this.screen !== 'title') this.goBack()
    const el = document.activeElement as HTMLInputElement | null
    if (el?.matches('input[type=range]') && (inp.pressed('next') || inp.pressed('prev'))) {
      el.value = String(Math.min(1, Math.max(0, Number(el.value) + (inp.pressed('next') ? 0.1 : -0.1))))
      el.dispatchEvent(new Event('input', { bubbles: true }))
    }
  }

  applyAccess(): void {
    const d = this.save.data
    document.body.classList.toggle('big-text', d.bigText)
    document.body.classList.toggle('high-contrast', d.highContrast)
    document.body.classList.toggle('reduced-motion', d.reducedMotion)
  }

  // ─── glyphs ─────────────────────────────────────────────────────────────
  private k(action: 'interact' | 'throw' | 'door' | 'bin' | 'pause' | 'recipes'): string {
    const m = this.input.method
    if (m === 'gamepad') return { interact: '<kbd class="pad a">A</kbd>', throw: '<kbd class="pad x">X</kbd>', door: '<kbd class="pad y">Y</kbd>', bin: '<kbd class="pad b">B</kbd>', pause: '<kbd class="pad">Start</kbd>', recipes: '<kbd class="pad">View</kbd>' }[action]
    if (m === 'touch') return { interact: '<kbd>ACT</kbd>', throw: '<kbd>THROW</kbd>', door: '<kbd>DOOR</kbd>', bin: '<kbd>BIN</kbd>', pause: '<kbd>II</kbd>', recipes: '' }[action]
    return { interact: '<kbd>E</kbd>', throw: '<kbd>F</kbd>', door: '<kbd>Q</kbd>', bin: '<kbd>X</kbd>', pause: '<kbd>Esc</kbd>', recipes: '<kbd>R</kbd>' }[action]
  }
  private glyphs(where: 'menu'): string {
    void where
    const m = this.input.method
    if (m === 'gamepad') return '<kbd class="pad">D-pad</kbd> navigate · <kbd class="pad a">A</kbd> select · <kbd class="pad b">B</kbd> back'
    if (m === 'touch') return 'Tap to select'
    return '<kbd>↑</kbd><kbd>↓</kbd> navigate · <kbd>Enter</kbd> select · <kbd>Esc</kbd> back · mouse works too'
  }
  private controlsRef(): string {
    const m = this.input.method
    if (m === 'gamepad') return `<div><kbd class="pad">L</kbd> move</div><div><kbd class="pad a">A</kbd> interact / tap</div><div><kbd class="pad x">X</kbd>/<kbd class="pad">RT</kbd> hold to aim, release to throw · <kbd class="pad">R</kbd> pick table</div><div><kbd class="pad y">Y</kbd> run to door</div><div><kbd class="pad b">B</kbd> run to bin</div><div><kbd class="pad">LB</kbd>/<kbd class="pad">RB</kbd> run to prev/next station</div><div><kbd class="pad">D-pad</kbd> plating</div>`
    return `<div><kbd>WASD</kbd>/<kbd>Arrows</kbd> move</div><div><kbd>E</kbd>/<kbd>Space</kbd> interact / tap</div><div><b>Click</b> any station, table or door to run there</div><div><kbd>F</kbd>/<b>Right mouse</b> hold to aim, release to throw</div><div><kbd>1</kbd>–<kbd>8</kbd> run to station</div><div><kbd>Q</kbd> door · <kbd>X</kbd> bin · <kbd>R</kbd> recipes</div><div><kbd>Arrows</kbd>/<kbd>WASD</kbd> plating</div>`
  }

  // ─── HUD ────────────────────────────────────────────────────────────────
  private buildHud(): void {
    this.layer.hud.innerHTML = `
      <div class="hud-top">
        <div class="hud-left"><div class="clock"><span class="phase"></span><b class="time"></b><div class="pbar"><i></i></div></div></div>
        <div class="rail"></div>
        <div class="hud-right"><div class="money"><b class="rev"></b><small class="target"></small><div class="tbar"><i></i></div></div>
          <div class="meters"><span class="sat"></span><span class="combo"></span></div></div>
        <button class="crew-btn" data-act="hire-panel" aria-label="Hire staff or bouncer">＋ Crew</button>
        <button class="pause-btn" data-act="pause" aria-label="Pause">II</button>
      </div>
      <div class="hand"></div>
      <div class="prompt"></div>
      <div class="coach"></div>
      <div class="throwmeter"><div class="zone good"></div><div class="zone perfect"></div><i class="needle"></i><span>RELEASE IN GOLD</span></div>
      <div class="plating-ui"></div>
      <div class="phase-banner"></div>`
    this.cache.clear()
    this.tickets.clear()
  }
  private set(sel: string, html: string): HTMLElement | null {
    const el = this.layer.hud.querySelector<HTMLElement>(sel)
    if (!el) return null
    if (this.cache.get(sel) !== html) { el.innerHTML = html; this.cache.set(sel, html) }
    return el
  }

  updateHud(s: Shift, game: Game, view: View): void {
    if (this.screen !== 'hud' && this.screen !== 'pause' && this.screen !== 'hire') return
    const t = s.mode === 'endless' ? s.clock : s.timeLeft
    const phaseName = { tutorial: 'Training', intro: 'Opening', service: 'Service', peak: 'Dinner Rush', lastcall: 'Last Orders', overtime: 'Closing', done: 'Closed' }[s.phase]
    this.set('.phase', phaseName)
    this.set('.time', s.tutorial && s.tutorial.step < 7 ? '--:--' : `${Math.floor(t / 60)}:${String(Math.floor(t % 60)).padStart(2, '0')}`)
    const pb = this.layer.hud.querySelector<HTMLElement>('.pbar i')
    if (pb) pb.style.width = s.mode === 'endless' ? `${Math.min(100, s.stats.walkouts * 33.4)}%` : `${Math.min(100, (s.clock / s.duration) * 100)}%`
    this.layer.hud.querySelector('.clock')?.classList.toggle('rush', s.phase === 'peak')
    this.set('.rev', money(s.stats.revenue))
    this.set('.target', s.mode === 'campaign' ? `target ${money(s.ch.target)}` : s.mode === 'endless' ? `walkouts ${s.stats.walkouts}/3` : 'styled service only')
    const tb = this.layer.hud.querySelector<HTMLElement>('.tbar i')
    if (tb) tb.style.width = `${Math.min(100, (s.stats.revenue / s.ch.target) * 100)}%`
    const sat = Math.round(s.satisfaction * 100)
    this.set('.sat', `<i class="face ${sat >= 80 ? 'happy' : sat >= 55 ? 'ok' : 'sad'}"></i>${sat}%`)
    this.set('.combo', s.combo > 0 ? `<b>×${s.comboMult.toFixed(2)}</b> combo ${s.combo}<i style="width:${Math.max(0, (s.comboTimer / 12) * 100)}%"></i>` : '<small>combo ×1.00</small>')
    this.layer.hud.querySelector('.combo')?.classList.toggle('hot', s.combo >= 5)
    // Ticket rail: most urgent first.
    const items = s.allItems()
    const live = s.tickets.filter(x => x.state === 'queued' || x.state === 'cooking').sort((a, b) => s.urgency(a) - s.urgency(b)).slice(0, 9)
    const rail = this.layer.hud.querySelector<HTMLElement>('.rail')
    if (rail) {
      const seen = new Set<string>()
      live.forEach((tk, idx) => {
        const p = s.party(tk.party)
        const d = DISHES[tk.dish]
        const it = items.find(i => i.ticket === tk.id)
        const step = it ? (it.ready ? d.steps.length : it.step) : 0
        const pf = p ? p.patience / p.max : 0
        const id = String(tk.id)
        seen.add(id)
        let el = this.tickets.get(id)
        if (!el) { el = document.createElement('div'); this.tickets.set(id, el) }
        const tag = tk.spicy ? '<em class="spicy">SPICY ▼</em>' : tk.crispy ? '<em class="crispy">CRISPY</em>' : ''
        const body = `<div class="tpic" style="background-image:url(${assetUrl(`art/dish_${tk.dish}.jpg`)})"><span>T${(p?.table ?? 0) + 1}</span></div>
        <div class="tname">${d.short}${tag}</div>
        <div class="troute">${d.steps.map((st, i) => `<span class="${i < step ? 'done' : i === step ? 'now' : ''}" style="--c:${STATIONS[st].color}">${STATIONS[st].key}</span>`).join('')}</div>
        <div class="tpat"><i></i></div>`
        if (el.dataset.body !== body) { el.innerHTML = body; el.dataset.body = body }
        const cls = `ticket ${pf < 0.3 ? 'urgent' : ''} ${it?.ready ? 'ready' : ''}`
        if (el.className !== cls) el.className = cls
        const bar = el.querySelector<HTMLElement>('.tpat i')!
        bar.style.width = `${(pf * 100).toFixed(1)}%`
        bar.style.background = pf < 0.3 ? 'var(--red)' : pf < 0.6 ? 'var(--gold)' : 'var(--green)'
        if (rail.children[idx] !== el) rail.insertBefore(el, rail.children[idx] ?? null)
      })
      for (const [k, el] of this.tickets) if (!seen.has(k)) { el.remove(); this.tickets.delete(k) }
      let empty = rail.querySelector<HTMLElement>('.rail-empty')
      if (!live.length && !empty) { empty = document.createElement('div'); empty.className = 'rail-empty'; empty.textContent = 'No tickets yet. Seat guests and take orders.'; rail.appendChild(empty) }
      if (live.length && empty) empty.remove()
    }
    // Hand.
    const h = s.mei.hands
    this.set('.hand', h ? `<img src="${assetUrl(`art/dish_${h.dish}.jpg`)}" alt=""><div><small>Holding</small><b>${DISHES[h.dish].short}</b><span>${h.ready ? 'READY: serve or throw' : `next: ${STATIONS[DISHES[h.dish].steps[h.step]].name}`}</span></div>` : '')
    this.layer.hud.querySelector('.hand')?.classList.toggle('on', !!h)
    // Prompt.
    const pr = game.prompt()
    const key = pr ? (pr.key === 'interact' ? this.k('interact') : pr.key === 'throw' ? this.k('throw') : pr.key === 'release' ? `release ${this.k('throw')}` : pr.key === 'bin' ? this.k('bin') : pr.key === 'dirs' ? (this.input.method === 'gamepad' ? '<kbd class="pad">D-pad</kbd>' : '<kbd>↑↓←→</kbd>') : '') : ''
    this.set('.prompt', pr ? `${key} <span>${esc(pr.text)}</span>` : '')
    this.layer.hud.querySelector('.prompt')?.classList.toggle('on', !!pr)
    // Tutorial coach.
    const tut = s.tutorial
    const coach = tut && tut.step <= 7 ? TUTORIAL[tut.step][this.input.method] : ''
    this.set('.coach', coach ? `<img src="${assetUrl('art/portrait_mei.jpg')}" alt=""><div><small>Training · ${Math.min(7, tut!.step + 1)}/8</small><p>${coach}</p></div>` : '')
    this.layer.hud.querySelector('.coach')?.classList.toggle('on', !!coach)
    this.throwMeter(s, view)
    this.platingUi(s, view)
    this.updateBubbles(s, view)
  }

  private throwMeter(s: Shift, view: View): void {
    const el = this.layer.hud.querySelector<HTMLElement>('.throwmeter')
    if (!el) return
    const aim = s.mei.aim
    el.classList.toggle('on', !!aim)
    if (!aim) return
    const t = s.tables[aim.table]
    const w = s.throwWindows(Math.hypot(t.x - s.mei.x, t.z - s.mei.z))
    const p = view.project(s.mei.x, 2.4, s.mei.z)
    el.style.transform = `translate(${p.x}px, ${p.y}px)`
    ;(el.querySelector('.good') as HTMLElement).style.cssText = `left:${50 - w.good * 50}%;width:${w.good * 100}%`
    ;(el.querySelector('.perfect') as HTMLElement).style.cssText = `left:${50 - w.perfect * 50}%;width:${w.perfect * 100}%`
    const n = s.needle()
    ;(el.querySelector('.needle') as HTMLElement).style.left = `${50 + n * 50}%`
  }

  private platingUi(s: Shift, view: View): void {
    const w = s.mei.work
    const el = this.layer.hud.querySelector<HTMLElement>('.plating-ui')
    if (!el) return
    if (!w || w.kind !== 'plate' || !s.mei.hands) { el.classList.remove('on'); this.cache.delete('.plating-ui'); return }
    const d = DISHES[s.mei.hands.dish]
    const labels = [...d.garnish, ...(s.mei.hands.spicy ? ['Chili (spicy)'] : [])]
    const html = `<div class="pl-title">Plating <b>${d.name}</b></div><div class="pl-seq">${w.seq.map((dir, i) => `<button class="pl-step ${i < w.idx ? 'done' : i === w.idx ? 'now' : ''}" data-dir="${dir}"><b>${ARROW[dir]}</b><small>${esc(labels[i] ?? '')}</small></button>`).join('')}</div>${w.miss ? `<div class="pl-miss">${w.miss} slip${w.miss > 1 ? 's' : ''}</div>` : ''}`
    this.set('.plating-ui', html)
    el.classList.add('on')
    const p = view.project(s.station('pass')!.x, 2.2, s.station('pass')!.z)
    el.style.transform = `translate(${p.x}px, ${p.y}px)`
  }

  private bubble(key: string, html: string, x: number, y: number, cls = ''): void {
    this.bubbleSeen.add(key)
    let el = this.bubbles.get(key)
    if (!el) { el = document.createElement('div'); el.className = 'bubble'; this.layer.bubbles.appendChild(el); this.bubbles.set(key, el) }
    if (el.dataset.html !== html) { el.innerHTML = html; el.dataset.html = html }
    const c = `bubble ${cls}`
    if (el.className !== c) el.className = c
    el.style.transform = `translate(${x.toFixed(1)}px, ${y.toFixed(1)}px)`
  }

  private ring(pf: number): string {
    const col = pf < 0.3 ? 'var(--red)' : pf < 0.6 ? 'var(--gold)' : 'var(--green)'
    return `<i class="pat" style="--p:${(pf * 100).toFixed(0)}%;--c:${col}"></i>`
  }

  private updateBubbles(s: Shift, view: View): void {
    this.bubbleSeen.clear()
    const live = this.screen === 'hud'
    if (live) {
      for (const t of s.tables) {
        const p = t.party >= 0 ? s.party(t.party) : undefined
        const pos = view.project(t.x, 2.15, t.z)
        const label = `<span class="tn">T${t.id + 1}</span>`
        if (!p) {
          if (t.dirty) this.bubble(`t${t.id}`, `${label}<b class="ico">🧽</b><small>Clear</small>`, pos.x, pos.y, 'dirty')
          else this.bubble(`t${t.id}`, `${label}<small>${t.seats} seats</small>`, pos.x, pos.y + 18, 'empty')
          continue
        }
        const g = GUESTS[p.type]
        const pf = p.patience / p.max
        const gt = `<span class="gt ${GUESTS[p.type].rowdy ? 'rowdy' : ''}" style="--c:${g.color}" title="${g.name}">${g.icon}${p.trouble > 0.6 ? '!' : ''}</span>`
        if (p.state === 'walking' || p.state === 'leaving') { this.bubble(`t${t.id}`, `${label}`, pos.x, pos.y + 18, 'empty'); continue }
        if (p.state === 'menu') this.bubble(`t${t.id}`, `${label}${gt}<small>Reading menu…</small>`, pos.x, pos.y, 'menu')
        else if (p.state === 'ordering') this.bubble(`t${t.id}`, `${label}${gt}${this.ring(pf)}<b class="ico">✋</b><small>Take order</small>`, pos.x, pos.y, `order ${pf < 0.3 ? 'urgent' : ''}`)
        else if (p.state === 'waiting') {
          const need = s.needs(p)
          this.bubble(`t${t.id}`, `${label}${gt}${this.ring(pf)}<span class="needs">${need.map(d => `<img src="${assetUrl(`art/dish_${d}.jpg`)}" title="${DISHES[d].name}" alt="${DISHES[d].short}">`).join('')}</span>`, pos.x, pos.y, `wait ${pf < 0.3 ? 'urgent' : ''} ${s.mei.hands?.ready && need.includes(s.mei.hands.dish) ? 'match' : ''}`)
        } else if (p.state === 'eating') this.bubble(`t${t.id}`, `${label}<b class="ico">♪</b><small>${p.stylish ? 'Wow!' : 'Mmm…'}</small>`, pos.x, pos.y, 'eat')
      }
      // Door queue.
      const q = s.queue
      if (q.length) {
        const pos = view.project(6.0, 2.3, 4.1)
        const pf = q[0].patience / q[0].max
        this.bubble('door', `<span class="tn">Door</span>${this.ring(pf)}<span class="qs">${q.map(p => `<span class="gt" style="--c:${GUESTS[p.type].color}">${GUESTS[p.type].icon}${p.size}</span>`).join('')}</span>`, pos.x, pos.y, `door ${pf < 0.3 ? 'urgent' : ''}`)
      }
      // Stations.
      for (const st of s.stations) {
        const def = STATIONS[st.id]
        const pos = view.project(st.x, view.stationTop(st.id) + 0.55, st.z)
        const tag = `<span class="sk" style="--c:${def.color}">${def.key}</span>`
        if (st.burnt > 0) { this.bubble(`s${st.id}`, `${tag}<b class="ico">🔥</b><small>Scrape!</small>`, pos.x, pos.y, 'station burnt'); continue }
        if (st.item && def.kind === 'timed') {
          const f = st.t / s.cookTime(st)
          const w = s.windows(st.item)
          const max = 1.9
          const pct = (v: number) => `${Math.min(100, (v / max) * 100).toFixed(1)}%`
          const state = f >= w.pLo && f <= w.pHi ? 'gold' : f > w.gHi ? 'over' : f >= READY ? 'ok' : ''
          this.bubble(`s${st.id}`, `${tag}<span class="cook"><span class="z ok" style="left:${pct(READY)};width:calc(${pct(w.gHi)} - ${pct(READY)})"></span><span class="z gold" style="left:${pct(w.pLo)};width:calc(${pct(w.pHi)} - ${pct(w.pLo)})"></span><i style="left:${pct(f)}"></i></span><small>${DISHES[st.item.dish].short}${st.item.crispy ? ' · crispy' : ''}</small>`, pos.x, pos.y, `station cooking ${state}`)
        } else if (st.item && def.kind === 'tap') {
          const need = st.id === 'prep' && s.hasJob('prep') ? 1 : def.taps
          this.bubble(`s${st.id}`, `${tag}<span class="taps">${Array.from({ length: need }, (_, i) => `<i class="${i < st.taps ? 'on' : ''}"></i>`).join('')}</span><small>${DISHES[st.item.dish].short}</small>`, pos.x, pos.y, 'station tapping')
        } else this.bubble(`s${st.id}`, `${tag}<small>${def.name.replace(/^(The |Toddy-Free )/, '')}</small>`, pos.x, pos.y + 14, `station idle ${this.stationWanted(s, st.id) ? 'wanted' : ''}`)
      }
    }
    for (const [k, el] of this.bubbles) if (!this.bubbleSeen.has(k)) { el.remove(); this.bubbles.delete(k) }
  }
  private stationWanted(s: Shift, id: string): boolean {
    const h = s.mei.hands
    if (h && !h.ready) return DISHES[h.dish].steps[h.step] === id
    if (!h) return s.tickets.some(t => t.state === 'queued' && DISHES[t.dish].steps[0] === id)
    return false
  }

  popup(text: string, x: number, y: number, kind: string, view: View): void {
    const p = view.project(x, y, 0)
    void p
    const el = document.createElement('div')
    el.className = `pop ${kind}`
    el.textContent = text
    const pos = view.project(x, y, 0)
    el.style.left = `${pos.x}px`
    el.style.top = `${pos.y}px`
    this.layer.pops.appendChild(el)
    while (this.layer.pops.childElementCount > 14) this.layer.pops.firstElementChild!.remove()
    window.setTimeout(() => el.remove(), 1300)
  }
  popupAt(text: string, x: number, y: number, z: number, kind: string, view: View): void {
    const el = document.createElement('div')
    el.className = `pop ${kind}`
    el.textContent = text
    const pos = view.project(x, y, z)
    el.style.left = `${pos.x}px`
    el.style.top = `${pos.y}px`
    this.layer.pops.appendChild(el)
    while (this.layer.pops.childElementCount > 14) this.layer.pops.firstElementChild!.remove()
    window.setTimeout(() => el.remove(), 1300)
  }
  toast(text: string): void {
    const big = /rush|closed|Last orders/i.test(text)
    if (big) {
      const b = this.layer.hud.querySelector<HTMLElement>('.phase-banner')
      if (b) { b.textContent = text; b.classList.remove('on'); void b.offsetWidth; b.classList.add('on') }
      return
    }
    const el = document.createElement('div')
    el.className = 'toast'
    el.textContent = text
    this.layer.toasts.appendChild(el)
    while (this.layer.toasts.childElementCount > 3) this.layer.toasts.firstElementChild!.remove()
    window.setTimeout(() => el.remove(), 4200)
  }
  clearTransient(): void {
    this.layer.pops.innerHTML = ''
    this.layer.toasts.innerHTML = ''
    for (const el of this.bubbles.values()) el.remove()
    this.bubbles.clear()
  }

  // ─── touch ──────────────────────────────────────────────────────────────
  private setupTouch(): void {
    const layer = this.layer.touch
    const stick = layer.querySelector<HTMLElement>('.stick')!
    const knob = stick.querySelector('i')!
    const R = 50
    if (matchMedia('(pointer: coarse)').matches) document.body.classList.add('has-touch')
    window.addEventListener('touchstart', () => document.body.classList.add('has-touch'), { once: true, passive: true })
    stick.addEventListener('pointerdown', e => {
      stick.setPointerCapture(e.pointerId)
      const r = stick.getBoundingClientRect()
      this.touchStick = { id: e.pointerId, ox: r.left + r.width / 2, oy: r.top + r.height / 2 }
      this.moveStick(e, knob, R)
    })
    stick.addEventListener('pointermove', e => { if (this.touchStick?.id === e.pointerId) this.moveStick(e, knob, R) })
    const end = (e: PointerEvent) => {
      if (this.touchStick?.id !== e.pointerId) return
      this.touchStick = undefined
      knob.style.transform = ''
      this.input.setTouchMove(0, 0)
    }
    stick.addEventListener('pointerup', end)
    stick.addEventListener('pointercancel', end)
    layer.querySelectorAll<HTMLElement>('[data-touch]').forEach(b => {
      const a = b.dataset.touch as 'interact'
      b.addEventListener('pointerdown', e => { e.preventDefault(); b.setPointerCapture(e.pointerId); this.audio.unlock(); this.input.setTouchButton(a, true); b.classList.add('down') })
      const up = () => { this.input.setTouchButton(a, false); b.classList.remove('down') }
      b.addEventListener('pointerup', up)
      b.addEventListener('pointercancel', up)
    })
  }
  private moveStick(e: PointerEvent, knob: HTMLElement, R: number): void {
    const s = this.touchStick!
    let dx = e.clientX - s.ox, dy = e.clientY - s.oy
    const l = Math.hypot(dx, dy)
    if (l > R) { dx = (dx / l) * R; dy = (dy / l) * R }
    knob.style.transform = `translate(${dx}px, ${dy}px)`
    this.input.setTouchMove(dx / R, -dy / R)
  }
}
