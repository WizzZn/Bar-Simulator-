/** Local browser URL resolver for the self-contained distribution. */
const ROOT = '/assets/'
export function assetUrl(path: string): string {
  const clean = path.replace(/^\.\//, '').replace(/^\//, '')
  if (clean.startsWith('maps/')) return `/${clean}`
  const flatModel = clean.replace(/^models\/(?:chars|stations|dishes|decor)\//, 'models/')
  const art = flatModel.replace('art/portrait_', 'art/portrait-').replace('art/dish_', 'art/dish-')
  if (art === 'art/title_bg.jpg') return `${ROOT}art/title-screen.png`
  return `${ROOT}${art}`
}
