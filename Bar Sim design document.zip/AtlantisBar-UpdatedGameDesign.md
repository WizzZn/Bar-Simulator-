# Atlantis Bar

A fast-paced, arcade-style 3D bar-management and cocktail-making game built with Three.js, TypeScript and Vite.

## Game vision

Transform the former restaurant-management concept into a **full bar game with a hectic, Overcooked-like time-management feel**. The player works behind a busy bar, receives several drink orders at once, moves between compact preparation stations, makes cocktails through quick physical interactions, and serves customers before their patience runs out.

The inspiration is the fast, readable, station-based teamwork and escalating time pressure of Overcooked: busy order queues, short preparation tasks, movement between stations, mistakes, bottlenecks, rush periods, combos and shift ratings. Use an original bar setting, original characters, UI, environments and visual identity.

**The game is bar-only. Remove all restaurant and food-making gameplay.** There are no meals, snacks, cooking, food ingredients, kitchen appliances or restaurant service activities. The gameplay focuses on alcoholic drinks, cocktails, bar tools, glassware, ice, garnishes, customers and bar operations.

## Run locally

1. Install Node.js 20 or later.
2. In this folder, run `npm install`.
3. Run `npm run dev` and open the local URL printed by Vite.
4. For a static production build, run `npm run build`; the output is written to `dist/`.
5. For the included browser playtest, install Chromium (`npx playwright install chromium` if a system Chromium is unavailable), run the Vite server, then run `npm run playtest`.

## Core gameplay loop

1. Start a shift and open the bar.
2. Customers arrive and submit drink orders. Several orders can be active simultaneously.
3. Read the order tickets and identify the required drink, glass, ice, ingredients and finishing steps.
4. Move between the bar's four cocktail-making activities to prepare each order.
5. Deliver the finished drink to the correct customer before the order timer expires.
6. Earn money, tips, customer satisfaction and combo bonuses for accurate, fast service.
7. Manage limited stock, dirty glassware, station congestion and customer patience while new orders arrive.
8. Handle occasional customer arguments and fights: only the player or a hired bouncer can intervene.
9. Complete the shift target to earn a star rating, rewards and progression unlocks.

## The four cocktail-making activities

Cocktail preparation is organized into **four clear, repeatable activities**. These are the main hands-on gameplay tasks and should be easy to understand at a glance.

### Activity 1 — Glass and ice

- Read the order ticket and collect the required clean glass from the glass rack.
- Choose the correct glass type specified by the recipe.
- Collect the required ice type: none, cubes or crushed ice.
- Place the glass at the preparation counter.
- Wrong glass or ice should reduce accuracy; recipes can require an exact match.
- Used glasses become dirty after serving and must be washed before they can be reused.

### Activity 2 — Pour and measure

- Select the correct spirit and mixer bottles from the back bar.
- Pour ingredients into the glass or mixing container in the recipe's specified order.
- Each ingredient has a required quantity; the player must stop the pour near the target amount.
- Show a clear liquid-level or measurement indicator while pouring.
- Track ingredient identity and quantity, not just the number of button presses.
- Wrong ingredients, missing ingredients, under-pouring and over-pouring reduce drink quality.
- Every pour consumes inventory. Discarding a failed drink also consumes its ingredients.

### Activity 3 — Mix the cocktail

The recipe chooses one preparation method:

- **Build:** Add ingredients directly to the serving glass in the specified order.
- **Shake:** Put ingredients into a shaker, close it, shake for the target duration, then strain into the required glass.
- **Stir:** Put ingredients into a mixing glass, stir for the target duration, then transfer to the serving glass when required.

The player performs a short timing or interaction challenge. Correct method and timing improve quality; the wrong method or stopping too early/late reduces the result. Do not allow a different method to count as a perfect recipe.

### Activity 4 — Garnish and serve

- Collect the recipe's required garnish, if any.
- Add the garnish and complete the final presentation.
- Check the finished drink against the order ticket.
- Pick up the completed drink and deliver it to the correct customer or serving point.
- Serving the wrong customer, an incomplete drink or an incorrect recipe should fail or reduce the order result.
- On successful delivery, collect payment and calculate tips based on speed, accuracy and customer satisfaction.

Each recipe should use only the activities it needs. For example, a simple pour may skip mixing and garnish, while a complex cocktail may require all four activities. The order ticket should clearly show which steps are required.

## Bar-only scope and visual direction

- The whole environment is a bar: back bar, bottle shelves, counter, glass racks, ice wells, mixing stations, lounge/bar seating, stools, lighting, signs and security area.
- Use a lively, colorful, readable, slightly exaggerated arcade-game art direction.
- Make the bar feel busy and playful, with expressive customers, clear order tickets, satisfying drink animations, splashes, bubbles, ice effects and strong feedback.
- Use compact layouts with purposeful paths between stations. The player should have to move quickly without the layout becoming confusing.
- Later levels can introduce split counters, narrow passages, moving service points, extra stations or other original bar-themed layout challenges.
- Do not include food orders, snacks, meals, cooking, food preparation, restaurant menus, sarbath or soft-drink service.
- Do not retain restaurant kitchen layouts, ovens, stoves, food bins, cooking stations or food-related UI.

## Drinks and recipe data

The core alcoholic drink categories are:

- **Kallu**
- **Beer**
- **Brandy**
- **Whisky**
- **Vodka**
- **Scotch**

Cocktails are made from configured alcoholic bases and mixers. The recipe book is data-driven: every recipe defines the ingredients, quantities, glass, ice, preparation method, timing and garnish. Do not invent recipe combinations at runtime.

Example recipe structure:

```ts
type PreparationMethod = "build" | "stir" | "shake";

interface CocktailRecipe {
  id: string;
  displayName: string;
  ingredients: Array<{
    itemId: string;
    amount: number;
    unit: "ml" | "dash" | "piece";
  }>;
  glassId: string;
  ice: "none" | "cubes" | "crushed";
  method: PreparationMethod;
  mixDuration?: number;
  garnish?: string;
  basePrice: number;
  requiredActivities: Array<"glassIce" | "pourMeasure" | "mix" | "garnishServe">;
}
```

Keep the initial menu manageable and introduce more recipes as the player progresses. Recipes should be visually distinct and easy to identify on small order tickets.

## Orders and customer patience

Order states:

`Queued → Active → Preparing → Ready → Served`

An order can also become `Expired`, `Cancelled` or `Failed`.

- Customers request a specific unlocked drink or cocktail.
- Each order stores customer ID, recipe ID, price, patience timer, status and quality result.
- New orders enter a visible queue while the player is preparing existing orders.
- Order tickets show the drink icon/name and concise step indicators for the four activities.
- Customers have visible patience feedback. Patience decreases while waiting.
- Correct, fast service improves tips and customer satisfaction.
- Expired orders reduce the shift score and may cause the customer to leave.
- The player must deliver each drink to the customer who placed that order.
- Do not let a drink count as served until its recipe validation is complete.

## Overcooked-like time-management structure

The moment-to-moment experience should be hectic but fair.

- Multiple orders arrive close together, creating prioritization decisions.
- Every cocktail requires a short sequence of station interactions.
- The player must choose which order to prepare first and avoid letting all timers expire.
- Station placement should create meaningful movement and route planning.
- Keep interactions quick and tactile: grab, place, pour, shake, stir, garnish and serve.
- Provide strong visual and audio feedback for a correct step, wrong ingredient, finished drink, expired order and combo.
- Rush periods increase order frequency or customer count for a limited time.
- A short grace period or clear warning should precede major difficulty spikes.
- Avoid random difficulty that makes success impossible; balance order rate, preparation time, travel distance and available stations.
- The challenge comes from prioritization, movement and execution—not from obscure recipes or unreadable UI.

### Combos and shift scoring

- Consecutive successful orders build a service combo.
- Fast, accurate orders increase the combo multiplier.
- Wrong or expired orders break or reduce the combo.
- Score is based on completed orders, drink quality, service speed, tips, customer satisfaction and security incidents.
- At the end of a shift, show a clear score summary and a one-to-three-star rating.
- Shift objectives can include serving a target number of drinks, achieving a quality threshold, maintaining a combo or completing a rush without expired orders.

## Bar stations

Stations should map directly to the four cocktail-making activities:

- **Order board / POS:** Shows queued and active customer orders.
- **Glass rack:** Supplies clean glasses for Activity 1.
- **Ice well:** Supplies cubes or crushed ice for Activity 1.
- **Back bar / bottle shelf:** Supplies spirits and configured mixers for Activity 2.
- **Pouring counter:** Holds the active glass or mixing container for Activity 2.
- **Shaker station:** Supports shake recipes for Activity 3.
- **Stir station:** Supports stir recipes for Activity 3.
- **Build counter:** Supports build recipes for Activity 3.
- **Garnish station:** Supplies configured garnishes for Activity 4.
- **Serving counter / pickup point:** Completes Activity 4 and routes drinks to customers.
- **Glass washer:** Cleans used glassware so it can return to the rack.
- **Stock storage:** Holds replacement bottles, mixers, ice, glassware and garnishes.

Each station needs a clear interaction prompt, occupied/available state, and visual indicator for the current task. Do not create food stations or cooking interactions.

## Customer behaviour

Suggested customer states:

`Entering → Queueing / FindingSeat → Ordering → WaitingForDrink → Drinking → Leaving`

Additional states:

`Impatient`, `Intoxicated`, `Arguing`, `Fighting`, `Removed`.

- Customers enter, queue at the counter or take a bar seat.
- Customers order from the unlocked drink and cocktail menu.
- Each customer has patience, spending limit, drink preference and intoxication values.
- Customers become more intoxicated as they consume alcoholic drinks.
- Intoxication can affect movement, speech, patience and decision-making.
- Some intoxicated customers may argue or occasionally start a fight.
- Fights are occasional side events; they should add pressure without constantly interrupting cocktail service.
- Use readable animations, icons and state changes to communicate customer needs.

## Random fights and security

**Only the player character or a hired bouncer can intervene in and resolve a fight.**

- Eligible intoxicated customers can occasionally start an argument that escalates into a fight.
- Show a clear alert and identify the incident location.
- The player can move to the fight and perform an intervention interaction.
- A hired bouncer can detect the fight, move to it, break it up and escort disruptive customers out.
- Bartenders and barbacks must never resolve fights.
- A fight may cause lost sales, damage, complaints or a reputation penalty.
- Do not pause the entire shift automatically unless a specific game mode requires it.

### Bouncer behaviour

- Wait at an assigned security point.
- Detect eligible fights within a configurable range.
- Navigate to the incident and play approach/intervention animations.
- Separate participants and end the fight.
- Escort disruptive customers to the exit when required.
- Return to the assigned post.
- Upgrades can improve response speed, intervention effectiveness and coverage range.
- If no bouncer is hired, the player must handle fights personally.

## Staff and crew

The **＋ Crew** panel lets the player hire or assign staff. Staff help reduce workload but should not remove the core time-management challenge.

- **Bartender:** Can prepare selected drinks or complete configured bar-service tasks.
- **Barback:** Restocks bottles, mixers, ice, clean glasses and garnishes; can collect dirty glassware.
- **Bouncer:** Handles fights and escorts disruptive customers.

Staff need clear task priorities, movement destinations, work states and upgradeable efficiency. Staff must not cook, prepare food or perform restaurant tasks.

## Inventory and restocking

Track stock for:

- Kallu, beer, brandy, whisky, vodka and Scotch.
- Recipe-configured spirits and mixers.
- Ice cubes and crushed ice.
- Glass types.
- Shakers and reusable bar tools.
- Recipe-configured garnishes.

Rules:

- Each preparation consumes the configured ingredient quantities.
- Insufficient stock prevents the relevant step and shows a clear warning.
- The player or barback can restock from storage.
- Restocking costs money and takes time or an interaction.
- Upgrades can increase storage capacity, reduce restocking time or reduce waste.
- No food inventory, snack stock or kitchen supplies.

## Economy and progression

- Each shift has a duration, sales target and optional objectives.
- Revenue comes only from alcoholic drinks and cocktails.
- Tips depend on recipe quality, speed, customer satisfaction and upgrades.
- Operating costs include ingredients, staff wages, broken glassware and venue upgrades.
- Saved earnings fund upgrades, staff hires and new venues.
- Unlock recipes, glassware, bar equipment, station layouts and bar locations through campaign progression.
- Venue ratings reflect sales, service quality, customer satisfaction and security incidents.
- No food revenue, food objectives or restaurant service rewards.

## Upgrades

- **Bar equipment:** Faster pours, better shaker/stir interactions and extra preparation capacity.
- **Inventory:** More bottle, mixer, ice, glass and garnish capacity.
- **Service:** More simultaneous active orders, longer customer patience or faster serving.
- **Bartender:** Faster and more accurate drink preparation.
- **Barback:** Faster restocking and glass collection.
- **Bouncer:** Faster response, stronger intervention and wider security coverage.
- **Venue:** More bar seats, improved décor, lighting, reputation and station layout.

Upgrades must change real gameplay values and behaviours, not just visual labels.

## Campaign and level design

Run a five-stage campaign through distinct bar venues. Each level should introduce one new challenge at a time while keeping the four cocktail-making activities consistent.

Possible progression:

1. **Small Local Bar:** Teach the four activities with a small menu, few customers and short paths between stations.
2. **Busy Town Bar:** Introduce more simultaneous orders, additional glass types and tighter timing.
3. **Premium Cocktail Lounge:** Introduce more complex recipes, multiple mixing methods and garnish requirements.
4. **Crowded Night Bar:** Add rush periods, higher customer volume and occasional security incidents.
5. **Atlantis Signature Bar:** Combine advanced recipes, busy order queues, more stations and challenging shift objectives.

These are example level roles; retain the project's established venue names and art assets where appropriate. Every level remains a bar, and difficulty should come from the bar workflow rather than adding restaurant mechanics.

## Controls and feedback

Keep keyboard, gamepad and touch support. Update prompts to match the four activities.

- Movement: WASD / arrow keys; gamepad stick; touch movement control.
- Interact / pick up / place: E or Space; gamepad action button; touch action.
- Context action: pour, shake, stir, garnish, serve or intervene depending on the active station.
- Number keys may select mapped bar stations if this fits the existing control scheme.
- Keep existing menu and pause controls where appropriate.
- Remove controls for food stations, cooking actions and food bins.

Use context-sensitive prompts and clear progress indicators for glass/ice, pouring, mixing, garnish and serving. The player should always understand what to do next.

## Technical architecture

Keep systems modular and data-driven.

- `GameManager`: Campaign, venue, shift state and game flow.
- `OrderManager`: Order queue, timers, prioritization and order states.
- `RecipeDatabase`: Cocktail recipe definitions and unlocks.
- `CocktailPreparationController`: Tracks the four activities and validates the completed recipe.
- `BarStation`: Shared interaction base for bar stations.
- `InventoryManager`: Spirits, mixers, ice, glassware, tools and garnishes.
- `CustomerManager`: Spawning, queueing, seating and customer lifecycle.
- `CustomerAI`: Customer state machine, ordering, drinking and leaving.
- `IntoxicationSystem`: Alcohol consumption and behaviour effects.
- `FightManager`: Fight events, participants, escalation and resolution.
- `BouncerAI`: Security patrol, detection, intervention and escort.
- `StaffManager`: Hiring, assignment and task scheduling.
- `EconomyManager`: Sales, tips, expenses, wages and upgrades.
- `ScoreManager`: Combos, shift score, objectives and star rating.
- `ProgressionManager`: Campaign stages, venue and recipe unlocks.
- `UIManager`: HUD, order tickets, activity prompts, crew panel, inventory and alerts.
- `SaveManager`: Persistent campaign, upgrades, recipes and settings.

Use explicit state machines for orders, cocktail preparation, customers, staff and fights. Keep recipes, timings, stock amounts, customer patience and difficulty curves in data assets/configuration rather than hardcoding them into interaction scripts.

## Definition of done

- The entire game reads visually and mechanically as a bar, not a restaurant.
- All food-making, meal, snack, kitchen and restaurant systems are removed.
- Cocktail preparation is built around four clear activities: glass/ice, pour/measure, mix, garnish/serve.
- Recipes define exact ingredients, quantities, glass, ice, method, timing and garnish.
- Multiple order tickets can be active and must be prioritized under time pressure.
- Correct, incorrect, incomplete and expired orders produce clear outcomes.
- Combos, shift scores, objectives and one-to-three-star ratings work.
- Stock is consumed and restocked correctly.
- Customers can become intoxicated and occasional fights can occur.
- Only the player or hired bouncer can resolve fights.
- Staff perform bar-focused tasks only.
- The five-stage campaign, upgrades, economy and progression work with the new bar loop.
- The visual direction feels like a lively, hectic arcade time-management game while retaining Atlantis Bar's own identity.

The design and ongoing feature history are maintained in [`GOD_LOG.md`](GOD_LOG.md).
