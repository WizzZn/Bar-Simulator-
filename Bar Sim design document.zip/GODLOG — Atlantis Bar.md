# GODLOG — Atlantis Bar

This is the living design record for Atlantis Bar. Update it after every gameplay, content, controls, balance, or presentation change.

## Current direction
Atlantis Bar is a bar-only, arcade time-management game built with Three.js, TypeScript, and Vite. The player runs a compact cocktail bar through five increasingly hectic venues. There are no meals, snacks, kitchen appliances, food ingredients, cooking stations, restaurant menus, or food-service rewards.

## Implementation plan
- Refactor the supplied toddy-shop prototype into an alcoholic-drinks-only workflow.
- Make recipes data-driven with exact ingredients, quantities, glass, ice, preparation method, mix timing, garnish, price, and required activities.
- Use multiple active drink tickets, patience timers, combos, stock consumption, dirty glassware, restocking, customer intoxication, occasional fights, player/bouncer intervention, crew hiring, upgrades, economy, and five-stage progression.
- Preserve the existing Three.js renderer, input abstraction, save key, supplied character/decor assets, five venue map references, and supplied BGM where useful.

## Change log
### 2026-11-25 — Atlantis Bar conversion started
- Created the managed Three.js Atlantis Bar project from the approved bar-only Blueprint.
- Migrated the supplied working prototype runtime as the base so the playable 3D scene, input, save, customer, crew, and campaign systems remain intact during the refactor.
- Removed food and kitchen assets from the active runtime asset set; cocktail art, bar/decor models, character models, map references, and BGM remain available.
- Enabled TypeScript, JavaScript, JSON, CSS, and HTML post-edit diagnostics.

### 2026-11-25 — Bar-only conversion complete and verified
- Converted the runtime from the restaurant/toddy-shop prototype to an Atlantis Bar-only arcade time-management game: 10 alcoholic cocktail recipes, exact ingredients and quantities, glassware, ice, preparation method, mix timing, garnish, price, and required service activities.
- Implemented the four core cocktail activities: Glass + Ice, Pour + Measure, Mix, and Garnish + Serve, with multiple active drink tickets, patience timers, correct/incorrect/incomplete/expired outcomes, combos, shift scoring, and one-to-three-star results.
- Added bar inventory consumption and stock-storage restocking, dirty glassware and washing, customer intoxication, rowdy guests, occasional fights, and player-or-hired-bouncer-only fight resolution.
- Kept staff behavior bar-focused and wired five campaign venues, progression, economy, hires, upgrades, guests, targets, maps, and challenges into the bar loop.
- Replaced active station GLB rendering with procedural labeled bar counters and replaced restaurant-table rendering with procedural tables and glassware-like tabletop props; removed active food/kitchen station and restaurant-service content.
- Rebranded the title screen, boot screen, in-world signage, menus, metadata, recipe art paths, and title artwork to Atlantis Bar with a procedural neon cocktail-glass treatment.
- Verification: `pnpm run build` passes; `pnpm test -- --run` passes with 4 focused bar tests; `node scripts/bar-smoke.mjs` passes with no Chromium console errors; final source scan found no active food or “Toddler Life Sim” branding. Final screenshots: `shots/atlantis-title.png` and `shots/atlantis-hud.png`.

### 2026-11-25 — Managed sharing metadata verified
- Added `game-sharing.json` for Atlantis Bar with the existing game-specific favicon, concise share captions, and no generated OG cover; added `app.config.ts` with the durable project logo URL.
- Prepared the managed Three.js sharing build and verified that the production output contains Atlantis Bar title/social metadata and `dist/favicon.png`.
- Re-ran final checks after preparation: `pnpm run build` passes, `pnpm test -- --run` passes all 4 focused tests, `node scripts/bar-smoke.mjs` passes with `ok: true`, and `git diff --check` is clean.

## Verification record
- `pnpm run build`: passed, including TypeScript, Vite, size checks, and managed sharing metadata injection.
- `pnpm test -- --run`: passed, 4 focused bar tests.
- `node scripts/bar-smoke.mjs`: passed, Atlantis Bar title, five chapters/maps, drink art, HUD boot, hire panel, bouncer visibility, and no console errors.
- Final source scan: no active food/kitchen/restaurant-service content or “Toddler Life Sim” branding.
- Final screenshots: `shots/atlantis-title.png` and `shots/atlantis-hud.png`.
