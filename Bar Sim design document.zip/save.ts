/**
 * Versioned local save: settings plus campaign profile (stars, wallet, upgrades, staff, records).
 * Corrupt or foreign data falls back to defaults instead of crashing.
 */
import type { StaffJob, StaffRole, UpgradeId } from '../game/data'

export type Quality = 'low' | 'medium' | 'high'
export type SaveData = {
  version: 2
  musicVolume: number
  sfxVolume: number
  muted: boolean
  quality: Quality
  reducedMotion: boolean
  noShake: boolean
  assist: boolean
  toggleThrow: boolean
  bigText: boolean
  highContrast: boolean
  tutorialDone: boolean
  stars: number[]
  best: number[]
  wallet: number
  lifetime: number
  upgrades: Partial<Record<UpgradeId, boolean>>
  staff: Partial<Record<StaffRole, StaffJob>>
  seenIntro: number[]
  seenOutro: number[]
  challengeBest: Record<string, number>
  shifts: number
}
export const SAVE_KEY = 'meis-monsoon-table.save'

export function defaultSave(): SaveData {
  return {
    version: 2, musicVolume: 0.6, sfxVolume: 0.85, muted: false, quality: 'high', reducedMotion: false, noShake: false,
    assist: false, toggleThrow: false, bigText: false, highContrast: false, tutorialDone: false,
    stars: [0, 0, 0, 0, 0], best: [0, 0, 0, 0, 0], wallet: 0, lifetime: 0, upgrades: {}, staff: {}, seenIntro: [], seenOutro: [],
    challengeBest: {}, shifts: 0,
  }
}
const num = (v: unknown, f: number, lo = -Infinity, hi = Infinity) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : f)
const bool = (v: unknown, f: boolean) => (typeof v === 'boolean' ? v : f)
const arr = (v: unknown, n: number, lo: number, hi: number) => Array.from({ length: n }, (_, i) => num(Array.isArray(v) ? v[i] : 0, 0, lo, hi))
const ints = (v: unknown) => (Array.isArray(v) ? v.filter((x): x is number => Number.isInteger(x)).slice(0, 10) : [])

export function parseSave(raw: string | null): SaveData {
  const b = defaultSave()
  if (!raw) return b
  let d: Record<string, unknown>
  try {
    const p = JSON.parse(raw)
    if (!p || typeof p !== 'object' || Array.isArray(p)) return b
    d = p
  } catch { return b }
  if (d.version !== 2) return b
  const ups: SaveData['upgrades'] = {}
  if (d.upgrades && typeof d.upgrades === 'object') for (const k of ['pans', 'sneakers', 'bell', 'gloves', 'decor', 'stools', 'neon', 'shaker'] as UpgradeId[]) if ((d.upgrades as Record<string, unknown>)[k] === true) ups[k] = true
  const staff: SaveData['staff'] = {}
  const jobs: Record<StaffRole, StaffJob[]> = { server: ['host', 'runner'], prepcook: ['prep', 'bar'], dishwasher: ['bus', 'scrub'], bouncer: ['bouncer'] }
  if (d.staff && typeof d.staff === 'object') for (const r of Object.keys(jobs) as StaffRole[]) {
    const j = (d.staff as Record<string, unknown>)[r]
    if (typeof j === 'string' && jobs[r].includes(j as StaffJob)) staff[r] = j as StaffJob
  }
  const cb: Record<string, number> = {}
  if (d.challengeBest && typeof d.challengeBest === 'object') for (const [k, v] of Object.entries(d.challengeBest)) if (typeof v === 'number' && Number.isFinite(v)) cb[k.slice(0, 20)] = v
  const q = d.quality
  return {
    version: 2,
    musicVolume: num(d.musicVolume, b.musicVolume, 0, 1), sfxVolume: num(d.sfxVolume, b.sfxVolume, 0, 1), muted: bool(d.muted, false),
    quality: q === 'low' || q === 'medium' || q === 'high' ? q : b.quality,
    reducedMotion: bool(d.reducedMotion, false), noShake: bool(d.noShake, false), assist: bool(d.assist, false), toggleThrow: bool(d.toggleThrow, false),
    bigText: bool(d.bigText, false), highContrast: bool(d.highContrast, false), tutorialDone: bool(d.tutorialDone, false),
    stars: arr(d.stars, 5, 0, 3), best: arr(d.best, 5, 0, 1e9), wallet: num(d.wallet, 0, 0, 1e9), lifetime: num(d.lifetime, 0, 0, 1e10),
    upgrades: ups, staff, seenIntro: ints(d.seenIntro), seenOutro: ints(d.seenOutro), challengeBest: cb, shifts: num(d.shifts, 0, 0, 1e6),
  }
}

export class SaveStore {
  data: SaveData
  constructor(private readonly storage: Pick<Storage, 'getItem' | 'setItem'> | undefined = globalThis.localStorage) {
    let raw: string | null = null
    try { raw = this.storage?.getItem(SAVE_KEY) ?? null } catch { raw = null }
    this.data = parseSave(raw)
  }
  update(patch: Partial<SaveData>): void {
    this.data = { ...this.data, ...patch }
    try { this.storage?.setItem(SAVE_KEY, JSON.stringify(this.data)) } catch { /* in-memory only */ }
  }
  reset(): void {
    const keep = this.data
    this.update({ ...defaultSave(), musicVolume: keep.musicVolume, sfxVolume: keep.sfxVolume, muted: keep.muted, quality: keep.quality })
  }
  get totalStars(): number { return this.data.stars.reduce((a, b) => a + b, 0) }
}
